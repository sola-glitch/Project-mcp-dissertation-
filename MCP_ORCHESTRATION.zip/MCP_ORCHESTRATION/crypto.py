"""
crypto.py
-----------
Real encryption (Fernet: AES-128-CBC + HMAC-SHA256, from the `cryptography`
package) for secrets the hub stores: saved credentials, saved sessions and
saved AI chats.

Where the key comes from:
  1. VAULT_KEY in the environment / .env  (best: keeps the key out of the folder)
  2. a .vault_key file in the data folder (created on first use, owner-only)

What this protects: someone who gets only mcp_data.db (a backup, an
accidental commit). What it does NOT protect: someone who gets both the
database and the key file, or who can run code as you. Use VAULT_KEY if you
want the key kept somewhere else.

Generate your own key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

from __future__ import annotations

import os
import time
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

import config

KEY_FILE = config.data_dir() / ".vault_key"
PREFIX = "enc:v1:"


class CryptoError(Exception):
    """The stored data could not be decrypted (wrong or missing key)."""


def _read_or_create_key_file(path: Path) -> bytes:
    for _ in range(50):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            data = path.read_bytes().strip()
            if data:
                return data
            time.sleep(0.1)   # another process is still writing it
            continue
        key = Fernet.generate_key()
        with os.fdopen(fd, "wb") as f:
            f.write(key)
        return key
    raise CryptoError(f"Could not read the key file {path}.")


def _fernet() -> Fernet:
    env_key = os.environ.get("VAULT_KEY", "").strip()
    key = env_key.encode() if env_key else _read_or_create_key_file(KEY_FILE)
    try:
        return Fernet(key)
    except (ValueError, TypeError) as e:
        raise CryptoError("VAULT_KEY (or the .vault_key file) is not a valid Fernet key.") from e


def is_encrypted(blob: str) -> bool:
    return isinstance(blob, str) and blob.startswith(PREFIX)


def encrypt(plaintext: str) -> str:
    return PREFIX + _fernet().encrypt(plaintext.encode()).decode()


def decrypt(blob: str) -> str:
    if not is_encrypted(blob):
        raise CryptoError("That value is not encrypted data.")
    try:
        return _fernet().decrypt(blob[len(PREFIX):].encode()).decode()
    except InvalidToken as e:
        raise CryptoError(
            "Could not decrypt stored data: the key is wrong or missing. "
            "Restore your VAULT_KEY / .vault_key, or delete the affected rows to start fresh."
        ) from e
