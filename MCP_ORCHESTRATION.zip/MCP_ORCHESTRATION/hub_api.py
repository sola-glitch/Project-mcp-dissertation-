"""
hub_api.py
------------
The hub itself (hub.py) is a plain Python class meant to be driven from
agent.py in a terminal. A browser can't import Python directly, so this
file wraps a single shared Hub instance in a small FastAPI app and also
serves the web UI (web/index.html) as static files.

Every /api/* request needs the hub access token (see auth.py):
    Authorization: Bearer <token>
The static web page itself is public (it contains no data); run_all.py opens
it already carrying the token.

Run:
    uvicorn hub_api:app --port 8000
"""

from __future__ import annotations

import json
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import config
import auth
import ai_agent
import chat_store
from hub import Hub, SPOKE_REGISTRY

config.load_env()

hub = Hub()
ai_config = ai_agent.AIConfig.from_env()
chats: dict[str, ai_agent.Chat] = {}
MAX_CHATS = 20

WEB_DIR = Path(__file__).resolve().parent / "web"


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.token = auth.get_or_create_token()
    print(f"[hub_api] API token required for /api/*  (see HUB_API_TOKEN or {auth.TOKEN_FILE.name})")
    hub.discover()
    if not hub.session_id:
        hub.start_session()
    yield


app = FastAPI(title="MCP Orchestration — Hub API", lifespan=lifespan)
app.state.token = None  # set at startup; None means every /api request is refused


@app.middleware("http")
async def require_token(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        header = request.headers.get("authorization", "")
        provided = header[7:].strip() if header.lower().startswith("bearer ") else None
        if not auth.token_matches(provided, app.state.token):
            return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    return await call_next(request)


class CallRequest(BaseModel):
    spoke: str
    tool: str
    params: dict = {}


class ResumeRequest(BaseModel):
    session_id: str


class MakeToolRequest(BaseModel):
    name: str
    purpose: str
    port: int


class AIConfigRequest(BaseModel):
    provider: str
    model: str = ""
    api_key: str = ""     # blank = keep the current key
    base_url: str = ""


class ChatRequest(BaseModel):
    message: str
    chat_id: str | None = None


class ApproveRequest(BaseModel):
    chat_id: str
    decisions: dict[str, bool]


@app.get("/api/status")
def status():
    reachable = {}
    for name, base_url in SPOKE_REGISTRY.items():
        try:
            httpx.get(f"{base_url}/health", timeout=1.5).raise_for_status()
            reachable[name] = True
        except httpx.HTTPError:
            reachable[name] = False
    return {"session_id": hub.session_id, "spokes": reachable}


@app.post("/api/discover")
def discover():
    catalog = hub.discover()
    return {"tool_count": len(catalog), "catalog": catalog}


@app.get("/api/tools")
def tools():
    return hub.catalog


@app.get("/api/sessions")
def sessions():
    import session_manager
    return session_manager.list_sessions()


@app.post("/api/session/new")
def session_new():
    return {"session_id": hub.start_session()}


@app.post("/api/session/resume")
def session_resume(req: ResumeRequest):
    return {"session_id": hub.start_session(resume=req.session_id)}


@app.post("/api/call")
def call(req: CallRequest):
    try:
        result = hub.call(req.spoke, req.tool, req.params)
        return {"ok": True, "result": result}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@app.post("/api/route")
def route(req: CallRequest):
    try:
        result = hub.route(req.tool, req.params)
        return {"ok": True, "result": result}
    except LookupError as e:
        return {"ok": False, "no_tool": True, "error": str(e)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@app.post("/api/maketool")
def maketool(req: MakeToolRequest):
    try:
        result = hub.offer_to_create_tool(req.name, req.purpose, req.port, confirmed=True)
        return {"ok": True, "result": result}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@app.get("/api/audit")
def audit(limit: int = 50):
    import hub as hub_module
    log_path = hub_module.AUDIT_LOG_PATH
    if not log_path.exists():
        return []
    lines = log_path.read_text().strip().splitlines()[-limit:]
    return [json.loads(l) for l in lines if l.strip()]


# ---------------------------------------------------------------------------
# AI assistant (bring your own provider, model and key)
# ---------------------------------------------------------------------------

@app.get("/api/ai/config")
def ai_get_config():
    return ai_config.public()


@app.post("/api/ai/config")
def ai_set_config(req: AIConfigRequest):
    provider = req.provider.strip().lower()
    if provider not in ai_agent.DEFAULT_BASE_URLS:
        return {"ok": False, "error": "Provider must be 'anthropic' or 'openai'."}
    ai_config.provider = provider
    ai_config.model = req.model.strip()
    ai_config.base_url = req.base_url.strip()
    if req.api_key.strip():
        ai_config.api_key = req.api_key.strip()   # kept in memory only, never written to disk
    return {"ok": True, "config": ai_config.public()}


@app.post("/api/ai/models")
def ai_models():
    try:
        return {"ok": True, "models": ai_agent.list_models(ai_config)}
    except ai_agent.AIError as e:
        return {"ok": False, "error": str(e)}


def _get_chat(chat_id: str | None) -> tuple[str, ai_agent.Chat]:
    """Find a chat in memory, then on disk (so chats survive a restart), else start a new one."""
    if chat_id:
        chat = chats.get(chat_id) or chat_store.load_chat(chat_id)
        if chat is not None:
            chats[chat_id] = chat
            return chat_id, chat
    new_id = uuid.uuid4().hex
    chats[new_id] = ai_agent.Chat()
    while len(chats) > MAX_CHATS:
        chats.pop(next(iter(chats)))
    return new_id, chats[new_id]


def _save(chat_id: str, chat: ai_agent.Chat) -> None:
    try:
        chat_store.save_chat(chat_id, chat)
    except Exception as e:     # never lose a reply just because saving failed
        print(f"[hub_api] could not save chat: {type(e).__name__}: {e}")


def _ai_response(chat_id: str, chat: ai_agent.Chat, result: dict) -> dict:
    _save(chat_id, chat)
    return {"ok": True, "chat_id": chat_id, **result}


def _stream_events(chat_id: str, chat: ai_agent.Chat, events):
    """Turn agent events into newline-delimited JSON, always saving the chat at the end."""
    try:
        yield json.dumps({"type": "chat", "chat_id": chat_id}) + "\n"
        for ev in events:
            yield json.dumps(ev) + "\n"
    except ai_agent.AIError as e:
        yield json.dumps({"type": "error", "error": str(e)}) + "\n"
    except Exception as e:
        yield json.dumps({"type": "error", "error": f"{type(e).__name__}: {e}"}) + "\n"
    finally:
        _save(chat_id, chat)


def _ndjson(generator):
    return StreamingResponse(generator, media_type="application/x-ndjson",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/ai/chat")
def ai_chat(req: ChatRequest):
    chat_id, chat = _get_chat(req.chat_id)
    try:
        return _ai_response(chat_id, chat, ai_agent.Agent(hub, ai_config).send(chat, req.message))
    except ai_agent.AIError as e:
        return {"ok": False, "chat_id": chat_id, "error": str(e)}


@app.post("/api/ai/approve")
def ai_approve(req: ApproveRequest):
    chat_id, chat = _get_chat(req.chat_id)
    try:
        return _ai_response(chat_id, chat, ai_agent.Agent(hub, ai_config).resume(chat, req.decisions))
    except ai_agent.AIError as e:
        return {"ok": False, "chat_id": chat_id, "error": str(e)}


@app.post("/api/ai/chat/stream")
def ai_chat_stream(req: ChatRequest):
    chat_id, chat = _get_chat(req.chat_id)
    return _ndjson(_stream_events(chat_id, chat, ai_agent.Agent(hub, ai_config).send_stream(chat, req.message)))


@app.post("/api/ai/approve/stream")
def ai_approve_stream(req: ApproveRequest):
    chat_id, chat = _get_chat(req.chat_id)
    return _ndjson(_stream_events(chat_id, chat, ai_agent.Agent(hub, ai_config).resume_stream(chat, req.decisions)))


@app.get("/api/ai/chats")
def ai_list_chats():
    return chat_store.list_chats()


@app.get("/api/ai/chats/{chat_id}")
def ai_open_chat(chat_id: str):
    chat = chats.get(chat_id) or chat_store.load_chat(chat_id)
    if chat is None:
        return {"ok": False, "error": "Unknown chat."}
    chats[chat_id] = chat
    return {"ok": True, "chat_id": chat_id, "transcript": chat.transcript(), "pending": chat.awaiting()}


@app.delete("/api/ai/chats/{chat_id}")
def ai_delete_chat(chat_id: str):
    chats.pop(chat_id, None)
    chat_store.delete_chat(chat_id)
    return {"ok": True}


# Serve the web UI itself. Mounted last so /api/* routes above take priority.
if WEB_DIR.exists():
    app.mount("/", StaticFiles(directory=str(WEB_DIR), html=True), name="web")
