"""
session_manager.py
---------------------
Lets a task's state (history, cwd, active spoke, whatever hub.py wants
to remember) be saved and resumed later, instead of always starting
fresh. Session state (which includes tool results) is encrypted at rest (see crypto.py).
Persists to the 'sessions' table in mcp_data.db (created by
tools/database_server.py) via direct SQLAlchemy access, since the hub
process and the database spoke share the same file.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from sqlalchemy import create_engine, text, MetaData, Table, Column, String, Text

import config
import crypto

DB_PATH = config.data_dir() / "mcp_data.db"
engine = create_engine(f"sqlite:///{DB_PATH}", future=True)

# Created here too (not just in tools/database_server.py) so this module
# works standalone regardless of which spokes have been started/imported.
_metadata = MetaData()
_sessions_table = Table(
    "sessions", _metadata,
    Column("session_id", String, primary_key=True),
    Column("state_json", Text),
    Column("updated_at", String),
)
_metadata.create_all(engine)


def new_session() -> str:
    """Start a brand-new session and return its id."""
    session_id = str(uuid.uuid4())
    save_session(session_id, {"history": [], "cwd": None})
    return session_id


def save_session(session_id: str, state: dict) -> None:
    now = datetime.now(timezone.utc).isoformat()
    with engine.begin() as conn:
        conn.execute(
            text("""
                INSERT INTO sessions (session_id, state_json, updated_at)
                VALUES (:sid, :state, :now)
                ON CONFLICT(session_id) DO UPDATE SET state_json=:state, updated_at=:now
            """),
            {"sid": session_id, "state": crypto.encrypt(json.dumps(state)), "now": now},
        )


def load_session(session_id: str) -> dict | None:
    with engine.connect() as conn:
        row = conn.execute(
            text("SELECT state_json FROM sessions WHERE session_id = :sid"),
            {"sid": session_id},
        ).fetchone()
    if not row:
        return None
    raw = crypto.decrypt(row[0]) if crypto.is_encrypted(row[0]) else row[0]  # older rows were plain JSON
    return json.loads(raw)


def list_sessions() -> list[dict]:
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT session_id, updated_at FROM sessions ORDER BY updated_at DESC")).fetchall()
    return [{"session_id": r[0], "updated_at": r[1]} for r in rows]


def append_history(session_id: str, entry: dict) -> None:
    state = load_session(session_id) or {"history": [], "cwd": None}
    state["history"].append(entry)
    save_session(session_id, state)
