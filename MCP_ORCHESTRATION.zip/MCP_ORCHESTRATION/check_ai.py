"""
check_ai.py
-------------
Checks that YOUR provider, model and API key work with this project, in about
half a minute, before you rely on the AI assistant.

    python check_ai.py

It reads AI_PROVIDER, AI_API_KEY, AI_MODEL and AI_BASE_URL from .env (or the
environment), then tests, in order:
  1. your settings are complete
  2. the key can list models (a warning only: some services do not offer this)
  3. a plain reply
  4. a streamed reply
  5. a tool call: the model must use a tiny built-in "add_numbers" tool correctly

Nothing here touches your files or runs commands, and your key is never printed.
A few cents of usage at most. Exit code 0 means everything passed.
"""

from __future__ import annotations

import sys

import config

config.load_env()

import ai_agent
from ai_agent import Agent, AIConfig, AIError, Chat

_ADD_SCHEMA = {
    "type": "object",
    "properties": {"a": {"type": "integer", "description": "first number"},
                   "b": {"type": "integer", "description": "second number"}},
    "required": ["a", "b"],
}


class _TinyHub:
    """Just enough of a Hub for the assistant: one harmless tool."""

    def __init__(self):
        self.catalog = {"add_numbers": {"spoke": "check", "description": "Add two whole numbers and return the sum.",
                                        "input_schema": _ADD_SCHEMA}}

    def discover(self):
        return self.catalog

    def route(self, tool, params, source=None):
        if tool != "add_numbers":
            raise LookupError(tool)
        return {"status": "ok", "result": int(params["a"]) + int(params["b"])}


def run_checks(cfg: AIConfig, out=print) -> bool:
    results: list[tuple[str, str]] = []

    def record(name: str, status: str, detail: str = ""):
        results.append((name, status))
        out(f"  [{status}] {name}" + (f": {detail}" if detail else ""))

    out(f"Provider: {cfg.provider or '(not set)'}   Model: {cfg.model or '(not set)'}   "
        f"Base URL: {cfg.effective_base_url() or '(default)'}   Key: {'set' if cfg.api_key else 'not set'}")

    problem = cfg.problem()
    if problem:
        record("settings complete", "FAIL", problem + "  (set AI_PROVIDER, AI_API_KEY and AI_MODEL in .env)")
        return False
    record("settings complete", "PASS")

    try:
        models = ai_agent.list_models(cfg)
        note = "" if cfg.model in models else f"  (your model '{cfg.model}' is not in the list: check the spelling)"
        record("list models", "PASS" if not note else "WARN", f"{len(models)} found{note}")
    except AIError as e:
        record("list models", "WARN", f"{e}  (some services do not support this; continuing)")

    provider = ai_agent.make_provider(cfg)
    ok_so_far = True

    try:
        turn = provider.complete("You are a test.", [{"role": "user", "content": "Reply with the single word: ok"}], [])
        record("plain reply", "PASS", repr(turn.text[:40]))
    except AIError as e:
        record("plain reply", "FAIL", str(e))
        return False

    try:
        pieces, final = 0, None
        for kind, value in provider.stream("You are a test.", [{"role": "user", "content": "Count from 1 to 5."}], []):
            if kind == "text":
                pieces += 1
            else:
                final = value
        record("streamed reply", "PASS" if pieces else "WARN",
               f"{pieces} chunks" if pieces else "reply arrived but not as a stream; replies will appear all at once")
    except AIError as e:
        record("streamed reply", "FAIL", str(e))
        ok_so_far = False

    try:
        result = Agent(_TinyHub(), cfg).send(
            Chat(), "Use the add_numbers tool to add 17 and 25, then tell me the sum.")
        used = any(s["tool"] == "add_numbers" and s["status"] == "ok" for s in result["steps"])
        right = "42" in result.get("reply", "")
        if used and right:
            record("tool call", "PASS", "the model called the tool and reported 42")
        elif used:
            record("tool call", "WARN", "the tool ran but the answer did not mention 42: " + repr(result.get("reply", "")[:60]))
        else:
            record("tool call", "FAIL", "the model did not call the tool. This model or service may not support tool use; "
                                        "try another model")
            ok_so_far = False
    except AIError as e:
        record("tool call", "FAIL", str(e))
        ok_so_far = False

    return ok_so_far and not any(status == "FAIL" for _, status in results)


def main() -> int:
    out = print
    out("Checking your AI settings...\n")
    ok = run_checks(AIConfig.from_env(), out)
    out("\nAll good: the AI assistant should work." if ok else "\nSomething failed: fix the item marked FAIL above and run this again.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
