"""
run_all.py
-----------
One command to start everything instead of ten terminals.

    python run_all.py                 # spokes + web UI (opens your browser)
    python run_all.py --spokes-only   # just the spokes (for agent.py or mcp_server.py)

Starts every spoke listed in hub.SPOKE_REGISTRY (any spoke whose
tools/<name>_server.py exists), waits until each answers /health, then
starts the web UI at http://127.0.0.1:8000 and opens it in your browser,
already signed in with your hub access token (see auth.py).
Press Ctrl+C to stop everything.
"""

import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import httpx

ROOT = Path(__file__).resolve().parent

import config
config.load_env()

import auth
from hub import SPOKE_REGISTRY

procs = []


def start(module: str, port: int, host: str = "127.0.0.1"):
    procs.append(subprocess.Popen(
        [sys.executable, "-m", "uvicorn", module, "--host", host, "--port", str(port), "--log-level", "warning"],
        cwd=ROOT,
    ))


def wait_healthy(port: int, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            httpx.get(f"http://127.0.0.1:{port}/health", timeout=1).raise_for_status()
            return True
        except httpx.HTTPError:
            time.sleep(0.3)
    return False


def wait_healthy_url(url: str, timeout: float = 20.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            httpx.get(url, timeout=1).raise_for_status()
            return True
        except httpx.HTTPError:
            time.sleep(0.3)
    return False


def main():
    auth.get_or_create_spoke_secret()   # create it once, before ten processes start and all ask for it
    started = []
    for name, url in SPOKE_REGISTRY.items():
        if not (ROOT / "tools" / f"{name}_server.py").exists():
            print(f"[run_all] skipping '{name}' (no tools/{name}_server.py)")
            continue
        port = urlparse(url).port
        start(f"tools.{name}_server:app", port)
        started.append((name, port))

    for name, port in started:
        print(f"[run_all] {name:12s} :{port}  {'up' if wait_healthy(port) else 'FAILED to start (see error above)'}")

    if "--spokes-only" in sys.argv:
        print("[run_all] Spokes running. Use agent.py or mcp_server.py now. (Ctrl+C to stop)")
        while True:
            time.sleep(1)

    # HUB_HOST is only changed in Docker (0.0.0.0 inside the container; compose publishes it on 127.0.0.1).
    # The spokes always stay on 127.0.0.1.
    start("hub_api:app", 8000, os.environ.get("HUB_HOST", "").strip() or "127.0.0.1")
    print(f"[run_all] hub_api      :8000  {'up' if wait_healthy_url('http://127.0.0.1:8000/') else 'FAILED to start'}")
    print("[run_all] Web UI ready: http://127.0.0.1:8000  (Ctrl+C to stop)")
    print(f"[run_all] Access token is in HUB_API_TOKEN or the {auth.TOKEN_FILE.name} file. Keep it private.")
    if not os.environ.get("HUB_NO_BROWSER"):
        try:
            import webbrowser
            webbrowser.open(f"http://127.0.0.1:8000/#token={auth.get_or_create_token()}")
        except Exception:
            pass
    while True:
        time.sleep(1)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    try:
        main()
    except KeyboardInterrupt:
        pass
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
