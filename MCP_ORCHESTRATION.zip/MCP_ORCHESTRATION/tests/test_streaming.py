"""Streaming replies: provider parsing, agent events, the HTTP stream and the real-key self-check."""

import json

import httpx
import pytest
from fastapi.testclient import TestClient

import ai_agent
import check_ai
import hub_api
from ai_agent import Agent, AIConfig, AIError, Chat
from hub import Hub
from sse_helpers import (anthropic_text, anthropic_tool, openai_text, openai_tool, sse_response)

TOKEN = "stream-token"
AUTH = {"Authorization": f"Bearer {TOKEN}"}


def fake_provider(monkeypatch, handler):
    monkeypatch.setattr(ai_agent, "_client", lambda: httpx.Client(transport=httpx.MockTransport(handler)))


def scripted(*responses):
    """Serve responses in order; remember each request body."""
    sent, it = [], iter(responses)

    def handler(req):
        sent.append(json.loads(req.content))
        return next(it)

    return handler, sent


ANTHROPIC = AIConfig(provider="anthropic", api_key="k", model="m")
OPENAI = AIConfig(provider="openai", api_key="k", model="m")


def agent(cfg):
    h = Hub()
    h.discover()
    return Agent(h, cfg)


# ---------------- provider-level parsing ----------------

def test_anthropic_text_streams_in_pieces(monkeypatch):
    handler, sent = scripted(sse_response(anthropic_text("Hel", "lo ", "world")))
    fake_provider(monkeypatch, handler)
    items = list(ai_agent.make_provider(ANTHROPIC).stream("sys", [{"role": "user", "content": "hi"}], []))
    assert [v for k, v in items if k == "text"] == ["Hel", "lo ", "world"]
    turn = items[-1][1]
    assert turn.text == "Hello world" and turn.tool_calls == []
    assert sent[0]["stream"] is True


def test_anthropic_tool_arguments_are_assembled_from_fragments(monkeypatch):
    handler, _ = scripted(sse_response(anthropic_tool("run_command", ['{"comm', 'and": "ec', 'ho hi"}'], lead="On it.")))
    fake_provider(monkeypatch, handler)
    items = list(ai_agent.make_provider(ANTHROPIC).stream("sys", [{"role": "user", "content": "x"}], []))
    turn = items[-1][1]
    assert turn.text == "On it."
    assert turn.tool_calls[0].name == "run_command" and turn.tool_calls[0].args == {"command": "echo hi"}
    stored = turn.message["content"]
    assert stored[0] == {"type": "text", "text": "On it."} and stored[1]["input"] == {"command": "echo hi"}


def test_anthropic_tool_with_no_arguments_gets_empty_object(monkeypatch):
    handler, _ = scripted(sse_response(anthropic_tool("list_dir", [])))
    fake_provider(monkeypatch, handler)
    turn = list(ai_agent.make_provider(ANTHROPIC).stream("s", [{"role": "user", "content": "x"}], []))[-1][1]
    assert turn.tool_calls[0].args == {} and turn.tool_calls[0].error is None


def test_anthropic_broken_argument_json_is_flagged(monkeypatch):
    handler, _ = scripted(sse_response(anthropic_tool("run_command", ['{"command": '])))
    fake_provider(monkeypatch, handler)
    turn = list(ai_agent.make_provider(ANTHROPIC).stream("s", [{"role": "user", "content": "x"}], []))[-1][1]
    assert turn.tool_calls[0].error


def test_anthropic_empty_reply_is_stored_as_a_valid_non_empty_block(monkeypatch):
    handler, _ = scripted(sse_response(anthropic_text()))
    fake_provider(monkeypatch, handler)
    turn = list(ai_agent.make_provider(ANTHROPIC).stream("s", [{"role": "user", "content": "x"}], []))[-1][1]
    assert turn.message["content"] == [{"type": "text", "text": ai_agent.NO_RESPONSE}]    # the API rejects empty text blocks


def test_anthropic_stream_error_event_becomes_ai_error(monkeypatch):
    body = b'event: error\ndata: {"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}}\n\n'
    handler, _ = scripted(sse_response(body))
    fake_provider(monkeypatch, handler)
    with pytest.raises(AIError, match="Overloaded"):
        list(ai_agent.make_provider(ANTHROPIC).stream("s", [{"role": "user", "content": "x"}], []))


def test_openai_text_streams_in_pieces(monkeypatch):
    handler, sent = scripted(sse_response(openai_text("Ab", "cd")))
    fake_provider(monkeypatch, handler)
    items = list(ai_agent.make_provider(OPENAI).stream("sys", [{"role": "user", "content": "hi"}], []))
    assert [v for k, v in items if k == "text"] == ["Ab", "cd"]
    assert items[-1][1].text == "Abcd" and sent[0]["stream"] is True


def test_openai_tool_call_assembled_from_fragments(monkeypatch):
    handler, _ = scripted(sse_response(openai_tool("run_python", ['{"co', 'de": "print(1)"}'])))
    fake_provider(monkeypatch, handler)
    turn = list(ai_agent.make_provider(OPENAI).stream("s", [{"role": "user", "content": "x"}], []))[-1][1]
    call = turn.tool_calls[0]
    assert (call.id, call.name, call.args) == ("call_1", "run_python", {"code": "print(1)"})
    assert turn.message["tool_calls"][0]["function"]["arguments"] == '{"code": "print(1)"}'


def test_stream_http_error_is_a_helpful_ai_error(monkeypatch):
    fake_provider(monkeypatch, lambda req: httpx.Response(401, json={"error": {"message": "bad key"}}))
    for cfg in (ANTHROPIC, OPENAI):
        with pytest.raises(AIError, match="check your API key"):
            list(ai_agent.make_provider(cfg).stream("s", [{"role": "user", "content": "x"}], []))


def test_unreachable_provider_is_a_clean_error(monkeypatch):
    def handler(req):
        raise httpx.ConnectError("refused")

    fake_provider(monkeypatch, handler)
    with pytest.raises(AIError, match="Could not reach"):
        list(ai_agent.make_provider(ANTHROPIC).stream("s", [{"role": "user", "content": "x"}], []))


# ---------------- agent events ----------------

def test_agent_stream_events_for_a_tool_round(spokes, monkeypatch):
    handler, sent = scripted(
        sse_response(anthropic_tool("list_dir", [], lead="Looking.")),
        sse_response(anthropic_text("You have ", "files.")))
    fake_provider(monkeypatch, handler)
    events = list(agent(ANTHROPIC).send_stream(Chat(), "what files?"))
    kinds = [e["type"] for e in events]
    assert kinds == ["text", "step", "text", "text", "done"]
    assert events[0]["delta"] == "Looking."
    assert events[1]["tool"] == "list_dir" and events[1]["status"] == "ok"
    assert events[-1]["reply"] == "You have files."
    assert sent[1]["messages"][-1]["content"][0]["type"] == "tool_result"


def test_agent_stream_waits_for_approval_then_continues(spokes, monkeypatch):
    handler, sent = scripted(
        sse_response(anthropic_tool("run_command", ['{"command": "echo streamed-ok"}'])),
        sse_response(anthropic_text("It printed streamed-ok.")))
    fake_provider(monkeypatch, handler)
    ag, chat = agent(ANTHROPIC), Chat()
    first = list(ag.send_stream(chat, "run it"))
    assert first[-1]["type"] == "needs_approval" and first[-1]["pending"][0]["tool"] == "run_command"
    assert not any(e["type"] == "step" for e in first)             # nothing ran yet
    assert chat.awaiting()[0]["tool"] == "run_command"
    second = list(ag.resume_stream(chat, {"tu_1": True}))
    assert second[0]["type"] == "step" and second[0]["status"] == "ok"
    assert second[-1] == {"type": "done", "reply": "It printed streamed-ok."}
    assert chat.awaiting() == []


def test_openai_agent_stream_round_trip(spokes, monkeypatch):
    handler, sent = scripted(sse_response(openai_tool("list_dir", [])), sse_response(openai_text("done ", "now")))
    fake_provider(monkeypatch, handler)
    events = list(agent(OPENAI).send_stream(Chat(), "list"))
    assert events[-1] == {"type": "done", "reply": "done now"}
    assert sent[1]["messages"][-1]["role"] == "tool"


def test_failed_first_call_does_not_leave_a_duplicate_user_message(spokes, monkeypatch):
    calls = {"n": 0}

    def handler(req):
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(500, json={"error": {"message": "temporary"}})
        return sse_response(anthropic_text("fine"))

    fake_provider(monkeypatch, handler)
    ag, chat = agent(ANTHROPIC), Chat()
    with pytest.raises(AIError):
        list(ag.send_stream(chat, "hello"))
    assert chat.messages == []                                  # rolled back
    list(ag.send_stream(chat, "hello"))                         # the retry works
    assert [m["content"] for m in chat.messages if m["role"] == "user"] == ["hello"]


def test_non_streaming_send_still_returns_the_old_shape(spokes, monkeypatch):
    fake_provider(monkeypatch, lambda req: httpx.Response(200, json={"content": [{"type": "text", "text": "hi"}]}))
    result = agent(ANTHROPIC).send(Chat(), "yo")
    assert result == {"status": "done", "steps": [], "reply": "hi"}


# ---------------- the HTTP stream ----------------

@pytest.fixture
def client(spokes, monkeypatch):
    hub_api.app.state.token = TOKEN
    hub_api.hub.discover()
    hub_api.chats.clear()
    monkeypatch.setattr(hub_api, "ai_config", AIConfig(provider="anthropic", api_key="k", model="m"))
    return TestClient(hub_api.app)


def read_events(response):
    return [json.loads(line) for line in response.text.splitlines() if line.strip()]


def test_http_stream_is_newline_delimited_json(client, monkeypatch):
    handler, _ = scripted(sse_response(anthropic_text("Hi ", "there")))
    fake_provider(monkeypatch, handler)
    resp = client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "hello"})
    assert resp.headers["content-type"].startswith("application/x-ndjson")
    events = read_events(resp)
    assert events[0]["type"] == "chat" and events[0]["chat_id"]
    assert [e["delta"] for e in events if e["type"] == "text"] == ["Hi ", "there"]
    assert events[-1] == {"type": "done", "reply": "Hi there"}


def test_http_stream_requires_the_token(client):
    assert client.post("/api/ai/chat/stream", json={"message": "x"}).status_code == 401
    assert client.post("/api/ai/approve/stream", json={"chat_id": "x", "decisions": {}}).status_code == 401


def test_http_stream_reports_errors_as_events(client, monkeypatch):
    fake_provider(monkeypatch, lambda req: httpx.Response(401, json={"error": {"message": "bad key"}}))
    events = read_events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "hello"}))
    assert events[-1]["type"] == "error" and "API key" in events[-1]["error"]


def test_http_stream_without_config_reports_what_is_missing(client, monkeypatch):
    monkeypatch.setattr(hub_api, "ai_config", AIConfig())
    events = read_events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "hello"}))
    assert events[-1]["type"] == "error" and "not configured" in events[-1]["error"]


def test_http_stream_approval_flow(client, monkeypatch):
    handler, _ = scripted(
        sse_response(anthropic_tool("run_command", ['{"command": "echo over-stream"}'])),
        sse_response(anthropic_text("All done.")))
    fake_provider(monkeypatch, handler)
    first = read_events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "run"}))
    assert first[-1]["type"] == "needs_approval"
    chat_id = first[0]["chat_id"]
    second = read_events(client.post("/api/ai/approve/stream", headers=AUTH,
                                     json={"chat_id": chat_id, "decisions": {"tu_1": True}}))
    assert [e["type"] for e in second if e["type"] in ("step", "done")] == ["step", "done"]


# ---------------- check_ai.py (the real-key self-test) ----------------

def full_provider(monkeypatch, tool_works=True, stream_works=True, sum_text="The sum is 42."):
    def handler(req):
        if req.method == "GET":
            return httpx.Response(200, json={"data": [{"id": "m"}]})
        body = json.loads(req.content)
        if body.get("stream"):
            if not stream_works:
                return httpx.Response(200, json={"content": [{"type": "text", "text": "1 2 3 4 5"}]})
            return sse_response(anthropic_text("1 ", "2 3"))
        last = body["messages"][-1]
        if isinstance(last["content"], list):
            return httpx.Response(200, json={"content": [{"type": "text", "text": sum_text}]})
        if body.get("tools") and tool_works and "add_numbers" in str(last["content"]):
            return httpx.Response(200, json={"content": [{"type": "tool_use", "id": "t1", "name": "add_numbers",
                                                          "input": {"a": 17, "b": 25}}]})
        return httpx.Response(200, json={"content": [{"type": "text", "text": "ok"}]})

    fake_provider(monkeypatch, handler)


def test_check_ai_passes_for_a_healthy_provider(monkeypatch):
    full_provider(monkeypatch)
    lines = []
    assert check_ai.run_checks(AIConfig(provider="anthropic", api_key="secret-key", model="m"), lines.append) is True
    text = "\n".join(lines)
    assert "[PASS] tool call" in text and "[PASS] streamed reply" in text
    assert "secret-key" not in text                                    # the key is never printed


def test_check_ai_fails_when_settings_are_missing():
    lines = []
    assert check_ai.run_checks(AIConfig(provider="anthropic"), lines.append) is False
    assert "[FAIL] settings complete" in "\n".join(lines)


def test_check_ai_fails_when_the_model_will_not_use_tools(monkeypatch):
    full_provider(monkeypatch, tool_works=False)
    lines = []
    assert check_ai.run_checks(AIConfig(provider="anthropic", api_key="k", model="m"), lines.append) is False
    assert "[FAIL] tool call" in "\n".join(lines)


def test_check_ai_fails_clearly_on_a_bad_key(monkeypatch):
    fake_provider(monkeypatch, lambda req: httpx.Response(401, json={"error": {"message": "invalid x-api-key"}}))
    lines = []
    assert check_ai.run_checks(AIConfig(provider="anthropic", api_key="bad", model="m"), lines.append) is False
    assert "check your API key" in "\n".join(lines)


def test_check_ai_warns_if_streaming_is_not_supported(monkeypatch):
    full_provider(monkeypatch, stream_works=False)
    lines = []
    check_ai.run_checks(AIConfig(provider="anthropic", api_key="k", model="m"), lines.append)
    assert "[WARN] streamed reply" in "\n".join(lines)
