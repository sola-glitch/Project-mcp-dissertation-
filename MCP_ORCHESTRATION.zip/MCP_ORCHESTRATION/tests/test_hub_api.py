"""The HTTP API behind the web UI: login token, endpoints, AI endpoints."""

import json

import httpx
import pytest
from fastapi.testclient import TestClient

import ai_agent
import hub_api

TOKEN = "test-token-123"
AUTH = {"Authorization": f"Bearer {TOKEN}"}


@pytest.fixture
def client(spokes, monkeypatch):
    hub_api.app.state.token = TOKEN
    hub_api.hub.discover()
    hub_api.chats.clear()
    monkeypatch.setattr(hub_api, "ai_config", ai_agent.AIConfig())
    return TestClient(hub_api.app)


def test_api_requires_a_token(client):
    for path in ("/api/status", "/api/tools", "/api/audit", "/api/ai/config"):
        assert client.get(path).status_code == 401
    assert client.get("/api/tools", headers={"Authorization": "Bearer wrong"}).status_code == 401
    assert client.get("/api/tools", headers={"Authorization": TOKEN}).status_code == 401   # missing "Bearer"
    assert client.post("/api/call", json={"spoke": "shell", "tool": "run_command", "params": {"command": "echo hi"}}).status_code == 401


def test_api_refuses_everything_before_startup_sets_a_token(spokes):
    hub_api.app.state.token = None
    assert TestClient(hub_api.app).get("/api/tools", headers=AUTH).status_code == 401


def test_web_page_is_public_but_data_is_not(client):
    page = client.get("/")
    assert page.status_code == 200 and "Hub Control" in page.text


def test_tools_and_call_work_with_token(client):
    tools = client.get("/api/tools", headers=AUTH).json()
    assert "run_command" in tools
    res = client.post("/api/call", headers=AUTH,
                      json={"spoke": "shell", "tool": "run_command", "params": {"command": "echo hello-api"}}).json()
    assert res["ok"] and "hello-api" in json.dumps(res["result"])


def test_route_reports_missing_tool(client):
    res = client.post("/api/route", headers=AUTH, json={"spoke": "", "tool": "nope", "params": {}}).json()
    assert res["ok"] is False and res["no_tool"] is True


def test_audit_endpoint_returns_entries(client):
    client.post("/api/call", headers=AUTH, json={"spoke": "filesystem", "tool": "list_dir", "params": {}})
    entries = client.get("/api/audit?limit=5", headers=AUTH).json()
    assert entries and entries[-1]["tool"] == "list_dir"


def test_status_lists_every_spoke(client):
    status = client.get("/api/status", headers=AUTH).json()
    assert set(status["spokes"]) >= {"shell", "filesystem", "database"}
    assert status["spokes"]["database"] is False          # not running in this test
    assert status["session_id"] is None or isinstance(status["session_id"], str)


# ---------------- AI endpoints ----------------

def test_ai_config_roundtrip_never_returns_the_key(client):
    res = client.post("/api/ai/config", headers=AUTH, json={
        "provider": "anthropic", "model": "m1", "api_key": "sk-secret-value"}).json()
    assert res["ok"] and res["config"]["configured"] is True
    shown = client.get("/api/ai/config", headers=AUTH).text
    assert "sk-secret-value" not in shown and '"has_key":true' in shown.replace(" ", "")


def test_ai_config_blank_key_keeps_existing_key(client):
    client.post("/api/ai/config", headers=AUTH, json={"provider": "openai", "model": "a", "api_key": "k1"})
    client.post("/api/ai/config", headers=AUTH, json={"provider": "openai", "model": "b", "api_key": ""})
    cfg = client.get("/api/ai/config", headers=AUTH).json()
    assert cfg["has_key"] is True and cfg["model"] == "b"


def test_ai_config_rejects_unknown_provider(client):
    res = client.post("/api/ai/config", headers=AUTH, json={"provider": "nope"}).json()
    assert res["ok"] is False


def test_ai_chat_without_config_explains_what_is_missing(client):
    res = client.post("/api/ai/chat", headers=AUTH, json={"message": "hi"}).json()
    assert res["ok"] is False and "not configured" in res["error"]


def test_ai_models_endpoint(client, monkeypatch):
    monkeypatch.setattr(ai_agent, "_client", lambda: httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, json={"data": [{"id": "m-1"}]}))))
    client.post("/api/ai/config", headers=AUTH, json={"provider": "openai", "api_key": "k"})
    res = client.post("/api/ai/models", headers=AUTH).json()
    assert res == {"ok": True, "models": ["m-1"]}


def test_ai_chat_and_approval_flow_over_http(client, monkeypatch):
    responses = iter([
        {"content": [{"type": "tool_use", "id": "t1", "name": "run_command", "input": {"command": "echo via-http"}}]},
        {"content": [{"type": "text", "text": "All done."}]},
    ])
    monkeypatch.setattr(ai_agent, "_client", lambda: httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, json=next(responses)))))
    client.post("/api/ai/config", headers=AUTH, json={"provider": "anthropic", "model": "m", "api_key": "k"})

    first = client.post("/api/ai/chat", headers=AUTH, json={"message": "run echo"}).json()
    assert first["ok"] and first["status"] == "needs_approval"
    final = client.post("/api/ai/approve", headers=AUTH,
                        json={"chat_id": first["chat_id"], "decisions": {"t1": True}}).json()
    assert final["status"] == "done" and final["reply"] == "All done."
    assert final["steps"][0]["tool"] == "run_command"


def test_approve_unknown_chat(client):
    res = client.post("/api/ai/approve", headers=AUTH, json={"chat_id": "nope", "decisions": {}}).json()
    assert res["ok"] is False
