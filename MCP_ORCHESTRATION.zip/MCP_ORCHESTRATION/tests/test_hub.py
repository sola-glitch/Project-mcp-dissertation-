import json

import pytest

import hub as hub_module
from hub import DANGEROUS_TOOLS, Hub


def test_discover_finds_tools_and_skips_dead_spokes(spokes):
    h = Hub()
    catalog = h.discover()
    for tool in ("run_command", "run_python", "list_dir", "create_file"):
        assert tool in catalog
    assert "http_request" not in catalog          # rest_api spoke is "switched off"
    assert catalog["run_command"]["spoke"] == "shell"


def test_discover_includes_json_schema(spokes):
    h = Hub()
    h.discover()
    schema = h.catalog["run_command"]["input_schema"]
    assert schema["type"] == "object"
    assert schema["required"] == ["command"]
    assert schema["properties"]["command"]["type"] == "string"


def test_route_runs_the_right_tool(spokes):
    h = Hub()
    h.discover()
    result = h.route("run_python", {"code": "print(6*7)"})
    assert result["status"] == "ok"
    assert "42" in json.dumps(result)


def test_route_unknown_tool_raises_lookup_error(spokes):
    h = Hub()
    h.discover()
    with pytest.raises(LookupError):
        h.route("definitely_not_a_tool", {})


def test_spoke_errors_are_passed_through(spokes):
    h = Hub()
    h.discover()
    result = h.route("read_file", {"path": "/etc/definitely/outside/allowed/roots"})
    assert result["status"] == "error"


def test_every_call_is_audited_with_source(spokes):
    h = Hub()
    h.discover()
    h.route("list_dir", {})
    h.route("list_dir", {}, source="ai")
    lines = [json.loads(l) for l in hub_module.AUDIT_LOG_PATH.read_text().splitlines()]
    assert len(lines) == 2
    assert lines[0]["tool"] == "list_dir" and "source" not in lines[0]
    assert lines[1]["source"] == "ai"


def test_session_history_is_recorded_and_resumable(spokes):
    import session_manager
    h = Hub()
    h.discover()
    sid = h.start_session()
    h.route("list_dir", {})
    saved = session_manager.load_session(sid)
    assert len(saved["history"]) >= 1
    h2 = Hub()
    h2.start_session(resume=sid)
    assert h2.session_id == sid


def test_dangerous_tools_cover_the_risky_ones():
    for tool in ("run_command", "run_python", "create_file", "update_file", "delete_file", "http_request"):
        assert tool in DANGEROUS_TOOLS
    assert "list_dir" not in DANGEROUS_TOOLS and "read_file" not in DANGEROUS_TOOLS
