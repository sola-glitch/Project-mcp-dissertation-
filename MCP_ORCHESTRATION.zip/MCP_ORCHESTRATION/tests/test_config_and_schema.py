"""Settings helpers, and the JSON Schema every spoke tool publishes."""

import inspect
import os

import pytest

import config
from tools._base import _json_type, build_input_schema


def test_data_dir_defaults_to_env_setting(tmp_path, monkeypatch):
    monkeypatch.setenv("HUB_DATA_DIR", str(tmp_path / "data"))
    assert config.data_dir() == tmp_path / "data" and (tmp_path / "data").is_dir()


def test_data_dir_falls_back_to_project_folder(monkeypatch):
    monkeypatch.setenv("HUB_DATA_DIR", "")
    assert config.data_dir() == config.ROOT


def test_allowed_roots_from_env(monkeypatch, tmp_path):
    monkeypatch.setenv("HUB_ALLOWED_ROOTS", os.pathsep.join([str(tmp_path / "a"), str(tmp_path / "b")]))
    assert config.allowed_roots() == [str(tmp_path / "a"), str(tmp_path / "b")]


def test_allowed_roots_default_is_home(monkeypatch):
    from pathlib import Path
    monkeypatch.setenv("HUB_ALLOWED_ROOTS", "")
    assert config.allowed_roots() == [str(Path.home())]


@pytest.mark.parametrize("annotation,expected", [
    ("str", "string"), ("int", "integer"), ("float", "number"), ("bool", "boolean"),
    ("dict", "object"), ("dict | None", "object"), ("list[str]", "array"), ("Optional[str]", "string"),
    ("SomethingOdd", "string"), (int, "integer"), (dict, "object"),
])
def test_json_type_mapping(annotation, expected):
    assert _json_type(annotation) == expected


def test_schema_marks_required_and_optional():
    def tool(a: str, b: int, c: dict | None = None):
        ...
    schema = build_input_schema(tool, {"a": "first"})
    assert schema["required"] == ["a", "b"]
    assert schema["properties"]["c"]["type"] == "object"
    assert schema["properties"]["a"]["description"] == "first"


def all_spoke_modules():
    from tools import (code_exec_server, crud_files_server, cursor_server, database_server, filesystem_server,
                       github_server, rest_api_server, shell_server, toolmaker_server)
    return [code_exec_server, crud_files_server, cursor_server, database_server, filesystem_server,
            github_server, rest_api_server, shell_server, toolmaker_server]


def test_every_tool_of_every_spoke_publishes_a_correct_schema():
    seen = 0
    for module in all_spoke_modules():
        for tool in module.spoke.manifest().tools:
            fn = module.spoke._handlers[tool.name]
            schema = tool.input_schema
            assert list(schema["properties"]) == list(inspect.signature(fn).parameters), f"{module.__name__}.{tool.name}"
            required = [n for n, p in inspect.signature(fn).parameters.items() if p.default is inspect.Parameter.empty]
            assert schema.get("required", []) == required
            assert schema and schema["type"] == "object", f"{module.__name__}.{tool.name}"
            for name, prop in schema["properties"].items():
                assert prop["type"] in {"string", "integer", "number", "boolean", "object", "array"}
            assert set(schema.get("required", [])) <= set(schema["properties"])
            seen += 1
    assert seen >= 20
