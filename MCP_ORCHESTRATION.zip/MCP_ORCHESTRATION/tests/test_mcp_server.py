"""The MCP adapter: protocol behaviour, safe mode, and a real stdio round trip."""

import io
import json
import subprocess
import sys
from pathlib import Path

import pytest

import mcp_server
from hub import Hub

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def hub(spokes):
    h = Hub()
    h.discover()
    return h


def rpc(hub, method, params=None, id=1, safe=False):
    msg = {"jsonrpc": "2.0", "method": method}
    if id is not None:
        msg["id"] = id
    if params is not None:
        msg["params"] = params
    return mcp_server.handle(msg, hub, safe)


def test_initialize_negotiates_version(hub):
    r = rpc(hub, "initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "t", "version": "1"}})
    assert r["result"]["protocolVersion"] == "2024-11-05"
    assert "tools" in r["result"]["capabilities"] and r["result"]["serverInfo"]["name"]


def test_initialize_falls_back_to_a_supported_version(hub):
    r = rpc(hub, "initialize", {"protocolVersion": "1999-01-01"})
    assert r["result"]["protocolVersion"] == mcp_server.SUPPORTED_VERSIONS[0]


def test_notifications_get_no_reply(hub):
    assert rpc(hub, "notifications/initialized", id=None) is None


def test_ping(hub):
    assert rpc(hub, "ping")["result"] == {}


def test_tools_list_has_schemas_and_destructive_hints(hub):
    tools = {t["name"]: t for t in rpc(hub, "tools/list")["result"]["tools"]}
    assert tools["run_command"]["inputSchema"]["required"] == ["command"]
    assert tools["run_command"]["annotations"]["destructiveHint"] is True
    assert "annotations" not in tools["list_dir"]


def test_safe_mode_hides_and_blocks_dangerous_tools(hub):
    names = [t["name"] for t in rpc(hub, "tools/list", safe=True)["result"]["tools"]]
    assert "list_dir" in names and "run_command" not in names
    r = rpc(hub, "tools/call", {"name": "run_command", "arguments": {"command": "echo x"}}, safe=True)
    assert r["error"]["code"] == -32602


def test_tools_call_runs_a_tool(hub):
    r = rpc(hub, "tools/call", {"name": "run_command", "arguments": {"command": "echo from-mcp"}})
    assert r["result"]["isError"] is False
    assert "from-mcp" in r["result"]["content"][0]["text"]


def test_tools_call_reports_tool_errors(hub):
    r = rpc(hub, "tools/call", {"name": "read_file", "arguments": {"path": "/definitely/outside"}})
    assert r["result"]["isError"] is True


def test_tools_call_unknown_tool_is_a_protocol_error(hub):
    assert rpc(hub, "tools/call", {"name": "nope", "arguments": {}})["error"]["code"] == -32602


def test_unknown_method_and_bad_requests(hub):
    assert rpc(hub, "does/not/exist")["error"]["code"] == -32601
    assert mcp_server.handle({"id": 5}, hub)["error"]["code"] == -32600
    assert mcp_server.handle("junk", hub)["error"]["code"] == -32600


def test_serve_reads_lines_and_writes_json_lines(hub):
    stdin = io.StringIO("\n".join([
        json.dumps({"jsonrpc": "2.0", "id": 1, "method": "ping"}),
        "this is not json",
        json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}),
        "",
    ]) + "\n")
    stdout = io.StringIO()
    mcp_server.serve(hub, stdin, stdout)
    replies = [json.loads(l) for l in stdout.getvalue().splitlines()]
    assert replies[0]["id"] == 1 and replies[1]["error"]["code"] == -32700
    assert len(replies) == 2          # the notification got no reply


def test_real_stdio_process_keeps_stdout_clean():
    """Spawn the server as an MCP client would. No spokes are running, so the tool list is empty,
    but stdout must contain nothing except protocol messages."""
    msgs = "\n".join([
        json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                    "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "t", "version": "1"}}}),
        json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}),
        json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/list"}),
    ]) + "\n"
    proc = subprocess.run([sys.executable, str(ROOT / "mcp_server.py")], input=msgs, capture_output=True,
                          text=True, timeout=60, cwd=ROOT)
    lines = [l for l in proc.stdout.splitlines() if l.strip()]
    parsed = [json.loads(l) for l in lines]        # every stdout line must be valid JSON
    assert [p["id"] for p in parsed] == [1, 2]
    assert parsed[0]["result"]["serverInfo"]["name"]
    assert isinstance(parsed[1]["result"]["tools"], list)
