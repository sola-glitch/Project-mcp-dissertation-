"""The code runner: hardened-process mode (real subprocesses) and Docker mode (command checked, Docker faked)."""

import os
import time

import pytest

from tools import code_exec_server as ce

posix_only = pytest.mark.skipif(os.name != "posix", reason="resource limits and process groups are POSIX features")


def run(code):
    return ce.run_python(code)


def is_alive(pid: int) -> bool:
    """True if the process is really running. A killed process nobody has cleaned up yet
    (a 'zombie', state Z) is dead for our purposes."""
    import subprocess
    state = subprocess.run(["ps", "-o", "stat=", "-p", str(pid)], capture_output=True, text=True).stdout.strip()
    return bool(state) and not state.startswith("Z")


def test_runs_code_and_returns_output():
    res = run("print('hello'); import sys; print('oops', file=sys.stderr)")
    assert res["stdout"].strip() == "hello" and "oops" in res["stderr"]
    assert res["exit_code"] == 0 and res["sandbox"] == "process"


def test_nonzero_exit_and_traceback_are_reported():
    res = run("raise ValueError('boom')")
    assert res["exit_code"] != 0 and "ValueError: boom" in res["stderr"]


def test_secrets_in_the_environment_are_not_passed_to_the_snippet(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_super_secret")
    monkeypatch.setenv("AI_API_KEY", "sk-super-secret")
    monkeypatch.setenv("VAULT_KEY", "vault-super-secret")
    res = run("import os; print(sorted(os.environ))")
    assert "super-secret" not in res["stdout"]
    for name in ("GITHUB_TOKEN", "AI_API_KEY", "VAULT_KEY", "SPOKE_SECRET", "HUB_API_TOKEN"):
        assert name not in res["stdout"]


def test_snippet_runs_in_its_own_empty_folder_not_the_project():
    res = run("import os; print(os.getcwd()); print(sorted(os.listdir('.')))")
    cwd, listing = res["stdout"].strip().splitlines()
    assert "sandbox-work-" in cwd
    assert listing == "['snippet.py']"
    assert "hub.py" not in listing


def test_project_modules_cannot_be_imported():
    res = run("import hub")
    assert res["exit_code"] != 0 and "ModuleNotFoundError" in res["stderr"]


def test_timeout_stops_runaway_code(monkeypatch):
    monkeypatch.setattr(ce, "TIMEOUT_SECONDS", 1)
    started = time.time()
    res = run("while True: pass")
    assert time.time() - started < 8
    assert res["exit_code"] == -1 and "Timed out after 1s" in res["stderr"]


@posix_only
def test_timeout_also_kills_child_processes(monkeypatch):
    monkeypatch.setattr(ce, "TIMEOUT_SECONDS", 1)
    res = run("import subprocess, sys, time\n"
              "p = subprocess.Popen(['sleep', '60'])\n"
              "print(p.pid, flush=True)\n"
              "time.sleep(60)")
    pid = int(res["stdout"].split()[0])
    time.sleep(0.5)
    assert not is_alive(pid)                    # the grandchild is gone too


@posix_only
def test_children_left_running_after_normal_exit_are_cleaned_up():
    res = run("import subprocess\np = subprocess.Popen(['sleep', '60'])\nprint(p.pid, flush=True)")
    pid = int(res["stdout"].split()[0])
    time.sleep(0.5)
    assert not is_alive(pid)


@posix_only
def test_memory_bomb_is_stopped():
    res = run("x = bytearray(3 * 1024 ** 3)")
    assert res["exit_code"] != 0 and "MemoryError" in res["stderr"]


@posix_only
def test_huge_file_write_is_stopped():
    res = run("open('big.bin', 'wb').write(b'x' * (60 * 1024 * 1024))")
    assert res["exit_code"] != 0


def test_huge_output_is_cut_to_the_last_5000_characters():
    res = run("print('a' * 3_000_000); print('THE-END')")
    assert len(res["stdout"]) <= ce.MAX_OUTPUT_CHARS and "THE-END" in res["stdout"]


def test_unknown_sandbox_mode_is_refused(monkeypatch):
    monkeypatch.setenv("CODE_EXEC_SANDBOX", "magic")
    res = run("print(1)")
    assert res["exit_code"] == -1 and "Unknown CODE_EXEC_SANDBOX" in res["stderr"]


# ---------------- docker mode (docker itself is faked) ----------------

def test_docker_mode_without_docker_fails_loudly_and_never_falls_back(monkeypatch):
    monkeypatch.setenv("CODE_EXEC_SANDBOX", "docker")
    monkeypatch.setattr(ce.shutil, "which", lambda name: None)
    res = run("print('this must NOT run on the host')")
    assert res["exit_code"] == -1 and res["sandbox"] == "docker"
    assert "docker" in res["stderr"].lower() and res["stdout"] == ""


def test_docker_command_is_locked_down():
    cmd = ce._docker_command("/usr/bin/docker", "name1", "python:3.12-slim")
    joined = " ".join(cmd)
    for flag in ("--network none", "--read-only", "--cap-drop ALL", "--security-opt no-new-privileges",
                 "--pids-limit 64", "--memory 256m", "--user 65534:65534", "--rm"):
        assert flag in joined, flag
    assert cmd[-3:] == ["python", "-I", "-"] and cmd[-4] == "python:3.12-slim"
    assert "-v" not in cmd and "--volume" not in cmd and "--privileged" not in cmd    # nothing from the host is mounted


def test_docker_mode_sends_code_on_stdin_and_returns_output(monkeypatch):
    monkeypatch.setenv("CODE_EXEC_SANDBOX", "docker")
    monkeypatch.setenv("CODE_EXEC_DOCKER_IMAGE", "my/image:1")
    monkeypatch.setattr(ce.shutil, "which", lambda name: "/usr/bin/docker")
    captured = {}

    import io

    class FakeProc:
        def __init__(self, cmd, **kw):
            captured["cmd"] = cmd
            self.stdin = io.BytesIO()
            captured["stdin"] = self.stdin
            self.stdout, self.stderr = io.BytesIO(b"from container\n"), io.BytesIO(b"")
            self.returncode = 0

        def wait(self, timeout=None):
            captured["timeout"] = timeout

        def kill(self):
            pass

    class Closable(io.BytesIO):
        def close(self):                       # keep the buffer readable after the code closes stdin
            captured["code"] = self.getvalue()
            super().close()

    def fake_popen(cmd, **kw):
        proc = FakeProc(cmd, **kw)
        proc.stdin = Closable()
        return proc

    monkeypatch.setattr(ce.subprocess, "Popen", fake_popen)
    res = run("print('hi')")
    assert res == {"stdout": "from container\n", "stderr": "", "exit_code": 0, "sandbox": "docker"}
    assert captured["code"] == b"print('hi')" and "my/image:1" in captured["cmd"]
    assert captured["timeout"] == ce.TIMEOUT_SECONDS + ce.DOCKER_START_GRACE_SECONDS


def test_docker_timeout_kills_the_container(monkeypatch):
    monkeypatch.setenv("CODE_EXEC_SANDBOX", "docker")
    monkeypatch.setattr(ce.shutil, "which", lambda name: "/usr/bin/docker")
    import io, subprocess
    killed = []

    class FakeProc:
        def __init__(self, cmd, **kw):
            self.stdin, self.stdout, self.stderr = io.BytesIO(), io.BytesIO(), io.BytesIO()
            self.returncode = -9
            self.waits = 0

        def wait(self, timeout=None):
            self.waits += 1
            if self.waits == 1:
                raise subprocess.TimeoutExpired("docker", timeout)

        def kill(self):
            killed.append("proc")

    monkeypatch.setattr(ce.subprocess, "Popen", lambda cmd, **kw: FakeProc(cmd))
    monkeypatch.setattr(ce.subprocess, "run", lambda cmd, **kw: killed.append(cmd[:2]))
    res = run("while True: pass")
    assert res["exit_code"] == -1 and "Timed out" in res["stderr"]
    assert ["/usr/bin/docker", "kill"] in killed and "proc" in killed
