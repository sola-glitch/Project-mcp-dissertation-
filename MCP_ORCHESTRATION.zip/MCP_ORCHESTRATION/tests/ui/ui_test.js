// Drives the real web UI (web/index.html) in a simulated browser (jsdom) against a running hub.
// Started by tests/test_ui.py, which sets UI_BASE and UI_TOKEN. Exit code 0 = everything passed.
const { JSDOM } = require('jsdom');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const BASE = process.env.UI_BASE || 'http://127.0.0.1:8000/';
const TOKEN = process.env.UI_TOKEN;
let failures = 0;
const check = (name, ok, extra = '') => {
  console.log((ok ? 'PASS' : 'FAIL') + '  ' + name + (extra ? '  ' + extra : ''));
  if (!ok) failures++;
};

async function open(url, prompt) {
  return JSDOM.fromURL(url, {
    runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(w) {
      w.fetch = (u, o) => fetch(new URL(u, url), o);
      w.TextDecoder = TextDecoder;
      w.prompt = prompt || (() => null);
    },
  });
}

async function waitFor(fn, ms = 8000) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (fn()) return true; await sleep(100); }
  return false;
}

(async () => {
  // 1) opened like run_all.py does: token in the URL hash
  let dom = await open(BASE + '#token=' + TOKEN);
  let d = dom.window.document;
  const $ = id => d.getElementById(id);
  await waitFor(() => d.querySelectorAll('.tool-row').length >= 15);
  check('token taken from the URL and removed from the address bar', dom.window.location.hash === '');
  check('session id shown', $('session-id').textContent.length >= 6);
  check('tool catalog rendered', d.querySelectorAll('.tool-row').length >= 15, d.querySelectorAll('.tool-row').length + ' tools');
  check('spoke wheel drawn', d.querySelectorAll('.spoke-node').length === 9);

  // Sending is disabled while a reply is streaming, so wait for the button like a person would.
  const send = async text => {
    await waitFor(() => !$('ai-send-btn').disabled);
    $('ai-input').value = text;
    $('ai-send-btn').click();
  };

  // 2) AI settings
  $('ai-provider').value = 'anthropic';
  $('ai-key').value = 'my-own-key';
  $('ai-model').value = 'fake-model-1';
  $('ai-base').value = process.env.UI_FAKE_AI || 'http://127.0.0.1:9911';
  $('ai-save-btn').click();
  await waitFor(() => $('ai-config-msg').textContent.startsWith('Saved. Ready'));
  check('save shows ready', $('ai-config-msg').textContent.startsWith('Saved. Ready'), $('ai-config-msg').textContent);
  check('key box cleared after save', $('ai-key').value === '');
  $('ai-models-btn').click();
  await waitFor(() => d.querySelectorAll('#ai-model-list option').length === 2);
  check('models loaded into the picker', d.querySelectorAll('#ai-model-list option').length === 2);

  // 3) streaming: text must appear piece by piece, not all at once
  await send('tell me hello');
  const seen = new Set();
  const finalText = 'Hello world, streaming works.';
  const end = Date.now() + 8000;
  while (Date.now() < end) {
    const msgs = [...d.querySelectorAll('#ai-log .ai-msg.assistant')];
    const t = msgs.length ? msgs[msgs.length - 1].textContent.replace(/^assistant/, '') : '';
    if (t) seen.add(t);
    if (t === finalText) break;
    await sleep(60);
  }
  const partials = [...seen].filter(t => t !== finalText && finalText.startsWith(t));
  check('reply arrived in pieces (streaming)', partials.length >= 2, partials.length + ' partial states seen');
  check('final text complete', seen.has(finalText));
  check('only one assistant message for the reply', d.querySelectorAll('#ai-log .ai-msg.assistant').length === 1);
  await waitFor(() => !$('ai-send-btn').disabled);

  // 4) a safe tool needs no approval
  await send('what files are here');
  await waitFor(() => $('ai-log').textContent.includes('TOOL SAID'));
  check('safe tool ran with no approval prompt', $('ai-log').textContent.includes('list_dir') && d.querySelectorAll('.approval').length === 0, JSON.stringify($('ai-log').textContent.slice(-200)) + ' approvals=' + d.querySelectorAll('.approval').length);

  // 5) a dangerous tool waits for Allow
  await send('please echo something');
  await waitFor(() => d.querySelector('.approval'));
  const card = d.querySelector('.approval');
  check('approval card appears for a dangerous tool', !!card && card.textContent.includes('run_command'));
  check('command not run before approval', !$('ai-log').textContent.includes('stdout'));
  card.querySelector('button.allow').click();
  await waitFor(() => $('ai-log').textContent.includes('TOOL SAID: {') && $('ai-log').textContent.includes('stdout'));
  check('command ran after Allow', $('ai-log').textContent.includes('hello-from-ai'));
  await waitFor(() => d.querySelectorAll('#ai-approvals .approval').length === 0);
  check('approval card cleared', d.querySelectorAll('#ai-approvals .approval').length === 0);

  // 6) Deny
  await send('please echo again');
  await waitFor(() => d.querySelector('.approval'));
  d.querySelectorAll('.approval button')[1].click();
  await waitFor(() => $('ai-log').textContent.includes('[denied]'));
  await sleep(400);
  const logText = $('ai-log').textContent;
  const lastReply = logText.slice(logText.lastIndexOf('TOOL SAID'));
  check('Deny: logged as denied and the AI was told', logText.includes('[denied]') && lastReply.includes('denied this call') && !lastReply.includes('stdout'));

  // 7) audit panel marks AI calls
  dom.window.eval('loadAudit()');
  await waitFor(() => $('audit-list').textContent.includes('(ai)'));
  check('audit log tags AI calls', $('audit-list').textContent.includes('(ai)'));

  // 8) previous chats: new chat clears, picking the old one restores it
  await sleep(500);
  const chatOptions = [...d.querySelectorAll('#ai-chats option')].filter(o => o.value);
  check('previous chats are listed', chatOptions.length >= 1, chatOptions.length + ' chats');
  $('ai-new-btn').click();
  check('New chat clears the conversation', $('ai-log').textContent === '');
  const target = chatOptions.find(o => o.textContent.startsWith('tell me hello'));
  check('the first chat is in the list with its title', !!target);
  $('ai-chats').value = target.value;
  $('ai-chats').dispatchEvent(new dom.window.Event('change'));
  await waitFor(() => $('ai-log').textContent.includes(finalText));
  check('opening a previous chat restores its messages', $('ai-log').textContent.includes('tell me hello') && $('ai-log').textContent.includes(finalText));

  // 9) chats are stored on the server: a brand new page load still lists them
  const dom4 = await open(BASE + '#token=' + TOKEN);
  await waitFor(() => dom4.window.document.querySelectorAll('#ai-chats option').length > 1);
  check('a fresh page load still lists saved chats', dom4.window.document.querySelectorAll('#ai-chats option').length > 1);

  // 10) delete a chat
  const before = [...d.querySelectorAll('#ai-chats option')].filter(o => o.value).length;
  $('ai-del-btn').click();
  await waitFor(() => [...d.querySelectorAll('#ai-chats option')].filter(o => o.value).length === before - 1);
  check('Delete chat removes it from the list', [...d.querySelectorAll('#ai-chats option')].filter(o => o.value).length === before - 1);

  // 11) no token: asks once, then loads
  let prompted = 0;
  const dom2 = await open(BASE, () => { prompted++; return TOKEN; });
  await waitFor(() => dom2.window.document.querySelectorAll('.tool-row').length >= 15);
  check('no-token visit asks for the token once, then loads', prompted === 1 && dom2.window.document.querySelectorAll('.tool-row').length >= 15, 'prompted=' + prompted);

  // 12) wrong token and cancel: no endless prompting
  let prompts3 = 0;
  const dom3 = await open(BASE + '#token=wrong', () => { prompts3++; return null; });
  await sleep(2000);
  check('wrong token + cancel does not loop forever', prompts3 <= 3 && dom3.window.document.querySelectorAll('.tool-row').length === 0, 'prompts=' + prompts3);

  console.log(failures ? `\n${failures} FAILED` : '\nALL UI CHECKS PASSED');
  process.exit(failures ? 1 : 0);
})();
