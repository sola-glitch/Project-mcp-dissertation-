"""Sessions, credential vault and auth token."""

import auth
import credential_vault
import session_manager


def test_session_save_load_list(isolated_state):
    sid = session_manager.new_session()
    session_manager.append_history(sid, {"tool": "x"})
    state = session_manager.load_session(sid)
    assert state["history"][-1]["tool"] == "x"
    assert any(s["session_id"] == sid for s in session_manager.list_sessions())


def test_missing_session_returns_none(isolated_state):
    assert session_manager.load_session("no-such-session") is None


def test_credential_roundtrip(isolated_state):
    assert credential_vault.get_credential("svc") is None
    credential_vault.save_credential("svc", "alice", "s3cret")
    cred = credential_vault.get_credential("svc")
    assert cred["username"] == "alice" and cred["secret"] == "s3cret"


def test_ensure_credential_creates_once(isolated_state):
    calls = []

    def make(service):
        calls.append(service)
        return "bob", "pw"

    first = credential_vault.ensure_credential("other", create_fn=make)
    second = credential_vault.ensure_credential("other", create_fn=make)
    assert first["username"] == second["username"] == "bob"
    assert len(calls) == 1


def test_token_is_generated_once_and_reused(isolated_state):
    t1 = auth.get_or_create_token()
    t2 = auth.get_or_create_token()
    assert t1 == t2 and len(t1) >= 32
    assert auth.TOKEN_FILE.read_text().strip() == t1


def test_env_token_wins(isolated_state, monkeypatch):
    monkeypatch.setenv("HUB_API_TOKEN", "from-env")
    assert auth.get_or_create_token() == "from-env"
    assert not auth.TOKEN_FILE.exists()


def test_token_matching():
    assert auth.token_matches("abc", "abc")
    assert not auth.token_matches("abd", "abc")
    assert not auth.token_matches(None, "abc")
    assert not auth.token_matches("abc", None)
    assert not auth.token_matches("", "")
