"""
tests/test_spokes.py
-----------------------
Basic smoke tests using FastAPI's TestClient (no need to actually run
uvicorn/network for these). Run with: pytest
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from conftest import spoke_client


def test_filesystem_spoke_manifest():
    from tools.filesystem_server import app
    client = spoke_client(app)
    resp = client.get("/manifest")
    assert resp.status_code == 200
    tools = [t["name"] for t in resp.json()["tools"]]
    assert "navigate" in tools
    assert "list_dir" in tools
    assert "search" in tools


def test_filesystem_spoke_list_dir():
    from tools.filesystem_server import app
    client = spoke_client(app)
    resp = client.post("/invoke", json={"tool": "list_dir", "params": {}})
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_crud_files_spoke_create_read_delete(tmp_path, monkeypatch):
    from tools import crud_files_server
    monkeypatch.setattr(crud_files_server, "ALLOWED_ROOTS", [str(tmp_path)])
    client = spoke_client(crud_files_server.app)

    test_file = str(tmp_path / "hello.txt")

    resp = client.post("/invoke", json={"tool": "create_file", "params": {"path": test_file, "content": "hi"}})
    assert resp.json()["status"] == "ok"

    resp = client.post("/invoke", json={"tool": "read_file", "params": {"path": test_file}})
    assert resp.json()["result"]["content"] == "hi"

    resp = client.post("/invoke", json={"tool": "delete_file", "params": {"path": test_file}})
    assert resp.json()["status"] == "ok"


def test_shell_spoke_run_command():
    from tools.shell_server import app
    client = spoke_client(app)
    resp = client.post("/invoke", json={"tool": "run_command", "params": {"command": "echo hello"}})
    body = resp.json()
    assert body["status"] == "ok"
    assert "hello" in body["result"]["stdout"]


def test_toolmaker_scaffolds_new_spoke(tmp_path, monkeypatch):
    from tools import toolmaker_server
    monkeypatch.setattr(toolmaker_server, "TOOLS_DIR", tmp_path)
    client = spoke_client(toolmaker_server.app)
    resp = client.post("/invoke", json={
        "tool": "create_spoke",
        "params": {"name": "weather", "purpose": "fetch weather data", "port": 8100},
    })
    body = resp.json()
    assert body["status"] == "ok"
    assert (tmp_path / "weather_server.py").exists()
