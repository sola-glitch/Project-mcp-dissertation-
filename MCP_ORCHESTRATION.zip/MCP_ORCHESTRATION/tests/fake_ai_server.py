"""
A stand-in AI provider for the browser test. Speaks the Anthropic Messages API (streaming and not),
answers "files" with a list_dir call, "echo" with a run_command call, anything else with a slow
word-by-word reply so the test can watch text arrive progressively.

    python tests/fake_ai_server.py 9911
"""

import json
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

KEY = "my-own-key"


def reply_for(body):
    last = body["messages"][-1]
    if last["role"] == "user" and isinstance(last["content"], str):
        text = last["content"].lower()
        if "echo" in text:
            return [{"type": "tool_use", "id": "tu_9", "name": "run_command", "input": {"command": "echo hello-from-ai"}}]
        if "files" in text:
            return [{"type": "tool_use", "id": "tu_8", "name": "list_dir", "input": {}}]
        return [{"type": "text", "text": "Hello world, streaming works."}]
    result = last["content"][0]["content"]
    return [{"type": "text", "text": "TOOL SAID: " + result[:120]}]


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authed(self):
        if self.headers.get("x-api-key") != KEY:
            self._json({"error": {"message": "invalid x-api-key"}}, 401)
            return False
        return True

    def do_GET(self):
        if self._authed():
            self._json({"data": [{"id": "fake-model-1"}, {"id": "fake-model-2"}]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["content-length"])))
        if not self._authed():
            return
        blocks = reply_for(body)
        if not body.get("stream"):
            return self._json({"content": blocks})
        self.send_response(200)
        self.send_header("content-type", "text/event-stream")
        self.end_headers()

        def send(event):
            self.wfile.write(f"event: {event['type']}\ndata: {json.dumps(event)}\n\n".encode())
            self.wfile.flush()

        send({"type": "message_start", "message": {}})
        for i, block in enumerate(blocks):
            if block["type"] == "text":
                send({"type": "content_block_start", "index": i, "content_block": {"type": "text", "text": ""}})
                words = block["text"].split(" ")
                for n, word in enumerate(words):
                    send({"type": "content_block_delta", "index": i,
                          "delta": {"type": "text_delta", "text": word + (" " if n < len(words) - 1 else "")}})
                    if block["text"].startswith("Hello world"):
                        time.sleep(0.35)       # slow on purpose (only this reply): lets the test see partial text
            else:
                send({"type": "content_block_start", "index": i,
                      "content_block": {"type": "tool_use", "id": block["id"], "name": block["name"], "input": {}}})
                send({"type": "content_block_delta", "index": i,
                      "delta": {"type": "input_json_delta", "partial_json": json.dumps(block["input"])}})
            send({"type": "content_block_stop", "index": i})
        send({"type": "message_stop"})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1]) if len(sys.argv) > 1 else 9911), Handler).serve_forever()
