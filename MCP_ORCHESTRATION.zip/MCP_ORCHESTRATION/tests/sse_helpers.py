"""Builders for fake Server-Sent-Events responses, shaped like the real providers' streams."""

import json

import httpx


def _anthropic(events):
    return "".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events).encode()


def anthropic_text(*pieces):
    events = [{"type": "message_start", "message": {"role": "assistant"}},
              {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}]
    events += [{"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": p}} for p in pieces]
    events += [{"type": "content_block_stop", "index": 0}, {"type": "message_stop"}]
    return _anthropic(events)


def anthropic_tool(name, json_parts, id="tu_1", lead=None):
    events = [{"type": "message_start", "message": {}}]
    index = 0
    if lead:
        events += [{"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
                   {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": lead}},
                   {"type": "content_block_stop", "index": 0}]
        index = 1
    events += [{"type": "content_block_start", "index": index,
                "content_block": {"type": "tool_use", "id": id, "name": name, "input": {}}}]
    events += [{"type": "content_block_delta", "index": index,
                "delta": {"type": "input_json_delta", "partial_json": part}} for part in json_parts]
    events += [{"type": "content_block_stop", "index": index}, {"type": "message_stop"}]
    return _anthropic(events)


def openai_stream(*chunks):
    return ("".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n").encode()


def openai_text(*pieces):
    return openai_stream(*[{"choices": [{"delta": {"content": p}}]} for p in pieces],
                         {"choices": [{"delta": {}, "finish_reason": "stop"}]})


def openai_tool(name, arg_parts, id="call_1", lead=None):
    chunks = []
    if lead:
        chunks.append({"choices": [{"delta": {"content": lead}}]})
    chunks.append({"choices": [{"delta": {"tool_calls": [
        {"index": 0, "id": id, "type": "function", "function": {"name": name, "arguments": ""}}]}}]})
    chunks += [{"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": part}}]}}]}
               for part in arg_parts]
    chunks.append({"choices": [{"delta": {}, "finish_reason": "tool_calls"}]})
    return openai_stream(*chunks)


def sse_response(body: bytes) -> httpx.Response:
    return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})
