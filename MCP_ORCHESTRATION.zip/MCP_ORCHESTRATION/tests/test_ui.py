"""
Drives the real web UI in a simulated browser (jsdom) against a real running hub.

This test is skipped unless Node.js is installed and you ran, once:
    cd tests/ui && npm install
It starts the whole system (all spokes + the hub) and a fake AI provider, so ports 8000-8009
and 9911 must be free. It takes about 30 seconds.
"""

import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
UI_DIR = Path(__file__).resolve().parent / "ui"
PORTS = list(range(8000, 8010)) + [9911]


def port_busy(port):
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


pytestmark = [
    pytest.mark.skipif(shutil.which("node") is None, reason="Node.js is not installed"),
    pytest.mark.skipif(not (UI_DIR / "node_modules" / "jsdom").exists(),
                       reason="run `cd tests/ui && npm install` once to enable the browser test"),
]


@pytest.fixture
def running_system(tmp_path):
    busy = [p for p in PORTS if port_busy(p)]
    if busy:
        pytest.skip(f"ports already in use: {busy}")
    env = dict(os.environ)
    for name in ("AI_PROVIDER", "AI_API_KEY", "AI_MODEL", "AI_BASE_URL", "GITHUB_TOKEN", "VAULT_KEY"):
        env[name] = ""
    env.update({"HUB_DATA_DIR": str(tmp_path / "data"), "HUB_API_TOKEN": "ui-test-token",
                "SPOKE_SECRET": "ui-test-spoke-secret", "HUB_NO_BROWSER": "1",
                "HUB_ALLOWED_ROOTS": str(tmp_path), "PYTHONUNBUFFERED": "1"})
    fake = subprocess.Popen([sys.executable, str(Path(__file__).parent / "fake_ai_server.py"), "9911"], env=env)
    hub = subprocess.Popen([sys.executable, str(ROOT / "run_all.py")], cwd=ROOT, env=env,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline = time.time() + 60
        while time.time() < deadline:
            try:
                urllib.request.urlopen("http://127.0.0.1:8000/", timeout=1)
                break
            except OSError:
                time.sleep(0.5)
        else:
            pytest.fail("the hub did not start")
        yield
    finally:
        hub.terminate()
        try:
            hub.wait(timeout=15)
        except subprocess.TimeoutExpired:
            hub.kill()
        fake.terminate()
        fake.wait(timeout=5)


def test_web_ui_end_to_end(running_system):
    env = dict(os.environ, UI_BASE="http://127.0.0.1:8000/", UI_TOKEN="ui-test-token",
               UI_FAKE_AI="http://127.0.0.1:9911")
    result = subprocess.run(["node", "ui_test.js"], cwd=UI_DIR, env=env, capture_output=True, text=True, timeout=180)
    assert result.returncode == 0, "browser test failed:\n" + result.stdout + result.stderr
    assert "ALL UI CHECKS PASSED" in result.stdout
