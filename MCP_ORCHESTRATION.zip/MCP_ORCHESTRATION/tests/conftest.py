"""Shared fixtures. Every test runs against temp files, never your real data or settings."""

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Set BEFORE any project module is imported: all state goes to a throwaway folder, and an
# existing .env on your machine cannot leak real keys or settings into the tests.
# (python-dotenv never overrides a variable that is already set, even to an empty string.)
os.environ["HUB_DATA_DIR"] = tempfile.mkdtemp(prefix="hub-tests-")
os.environ["SPOKE_SECRET"] = "test-spoke-secret"
for _name in ("HUB_API_TOKEN", "VAULT_KEY", "GITHUB_TOKEN", "AI_PROVIDER", "AI_API_KEY", "AI_MODEL",
              "AI_BASE_URL", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "HUB_ALLOWED_ROOTS", "CODE_EXEC_SANDBOX"):
    os.environ[_name] = ""

import pytest
from sqlalchemy import create_engine

SPOKE_HEADERS = {"X-Spoke-Key": "test-spoke-secret"}


def spoke_client(app):
    """A test client for a spoke app that already carries the hub's shared secret."""
    from fastapi.testclient import TestClient
    return TestClient(app, headers=SPOKE_HEADERS)


@pytest.fixture
def isolated_state(tmp_path, monkeypatch):
    """Temp SQLite DB, audit log, token and key files for the hub-level modules."""
    import auth
    import chat_store
    import credential_vault
    import crypto
    import hub
    import session_manager

    engine = create_engine(f"sqlite:///{tmp_path / 'test.db'}", future=True)
    session_manager._metadata.create_all(engine)
    credential_vault._metadata.create_all(engine)
    chat_store._metadata.create_all(engine)
    monkeypatch.setattr(session_manager, "engine", engine)
    monkeypatch.setattr(credential_vault, "engine", engine)
    monkeypatch.setattr(hub, "AUDIT_LOG_PATH", tmp_path / "audit.log")
    monkeypatch.setattr(auth, "TOKEN_FILE", tmp_path / ".hub_token")
    monkeypatch.setattr(auth, "SPOKE_SECRET_FILE", tmp_path / ".spoke_secret")
    monkeypatch.setattr(crypto, "KEY_FILE", tmp_path / ".vault_key")
    return tmp_path


@pytest.fixture
def spokes(isolated_state, monkeypatch):
    """Route the hub's HTTP calls to real spoke apps running in-process (no network, no ports).

    Spokes that are not listed here behave like spokes that are switched off.
    """
    import httpx

    from tools import code_exec_server, crud_files_server, filesystem_server, shell_server

    monkeypatch.setattr(filesystem_server, "ALLOWED_ROOTS", [str(isolated_state)])
    monkeypatch.setattr(filesystem_server, "_STATE", {"cwd": str(isolated_state)})
    monkeypatch.setattr(crud_files_server, "ALLOWED_ROOTS", [str(isolated_state)])

    from fastapi.testclient import TestClient
    apps = {
        "http://127.0.0.1:8003": code_exec_server.app,
        "http://127.0.0.1:8007": filesystem_server.app,
        "http://127.0.0.1:8008": crud_files_server.app,
        "http://127.0.0.1:8009": shell_server.app,
    }
    clients = {base: TestClient(app) for base, app in apps.items()}   # no default headers: the hub must send the key

    def split(url):
        for b in clients:
            if url.startswith(b):
                return b, url[len(b):] or "/"
        raise httpx.ConnectError("spoke is switched off")

    def fake_get(url, headers=None, timeout=None, **kw):
        base, path = split(url)
        return clients[base].get(path, headers=headers)

    def fake_post(url, json=None, headers=None, timeout=None, **kw):
        base, path = split(url)
        return clients[base].post(path, json=json, headers=headers)

    import hub as hub_module
    monkeypatch.setattr(hub_module.httpx, "get", fake_get)
    monkeypatch.setattr(hub_module.httpx, "post", fake_post)
    return isolated_state
