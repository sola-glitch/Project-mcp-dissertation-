"""Real tests for the database, GitHub, REST and Cursor spokes (outside services are faked)."""

import pytest
from sqlalchemy import create_engine, text

from conftest import spoke_client


def invoke(client, tool, **params):
    resp = client.post("/invoke", json={"tool": tool, "params": params})
    assert resp.status_code == 200
    return resp.json()


# =============================== database ===============================

@pytest.fixture
def db(tmp_path, monkeypatch):
    from tools import database_server
    engine = create_engine(f"sqlite:///{tmp_path / 'spoke.db'}", future=True)
    database_server.metadata.create_all(engine)
    monkeypatch.setattr(database_server, "engine", engine)
    return spoke_client(database_server.app)


def test_database_has_the_core_tables(db):
    tables = invoke(db, "list_tables")["result"]
    assert "sessions" in tables and "credentials" in tables


def test_database_execute_then_query(db):
    res = invoke(db, "execute", sql="INSERT INTO sessions (session_id, state_json, updated_at) VALUES (:i, :s, 't')",
                 params={"i": "abc", "s": "{}"})
    assert res["status"] == "ok" and res["result"]["rows_affected"] == 1
    rows = invoke(db, "query", sql="SELECT session_id, state_json FROM sessions")["result"]
    assert rows == [{"session_id": "abc", "state_json": "{}"}]


def test_database_query_is_select_only(db):
    for bad in ("DELETE FROM sessions", "drop table sessions", "UPDATE sessions SET state_json='x'",
                "INSERT INTO sessions VALUES ('a','b','c')"):
        res = invoke(db, "query", sql=bad)
        assert res["status"] == "error" and "SELECT" in res["error"], bad


def test_database_query_accepts_select_in_any_case_with_spaces(db):
    assert invoke(db, "query", sql="   SeLeCt 1 AS one")["result"] == [{"one": 1}]


def test_database_query_cannot_smuggle_a_second_statement(db):
    res = invoke(db, "query", sql="SELECT 1; DROP TABLE sessions")
    assert res["status"] == "error"
    assert "sessions" in invoke(db, "list_tables")["result"]          # still there


def test_database_bad_sql_is_a_clean_error(db):
    res = invoke(db, "query", sql="SELECT * FROM no_such_table")
    assert res["status"] == "error"


def test_database_unknown_tool(db):
    assert invoke(db, "nope")["status"] == "error"


# =============================== github ===============================

class FakeIssue:
    def __init__(self, number=7, title="a bug"):
        self.number, self.title = number, title
        self.html_url = f"https://github.com/o/r/issues/{number}"


class FakeRepo:
    def __init__(self, name, log):
        self.full_name, self.log = name, log

    def create_issue(self, title, body):
        self.log.append(("create_issue", self.full_name, title, body))
        return FakeIssue(42, title)

    def get_issues(self, state):
        self.log.append(("get_issues", self.full_name, state))
        return [FakeIssue(1, "first"), FakeIssue(2, "second")]


@pytest.fixture
def gh(monkeypatch):
    from tools import github_server
    log, seen = [], {}

    class FakeUser:
        def get_repos(self):
            return [FakeRepo("me/one", log), FakeRepo("me/two", log)]

    class FakeGithub:
        def __init__(self, auth):
            seen["token"] = auth.token

        def get_user(self):
            return FakeUser()

        def get_repo(self, name):
            return FakeRepo(name, log)

    monkeypatch.setattr(github_server, "Github", FakeGithub)
    client = spoke_client(github_server.app)
    client.log, client.seen = log, seen
    return client


def test_github_without_a_token_explains_what_to_do(gh):
    res = invoke(gh, "list_repos")
    assert res["status"] == "error" and "GITHUB_TOKEN" in res["error"]


def test_github_list_repos_uses_env_token(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "env-token-123")
    res = invoke(gh, "list_repos")
    assert res["result"] == ["me/one", "me/two"]
    assert gh.seen["token"] == "env-token-123"


def test_github_token_argument_overrides_env(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "env-token")
    invoke(gh, "list_repos", token="explicit-token")
    assert gh.seen["token"] == "explicit-token"


def test_github_create_issue(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "t")
    res = invoke(gh, "create_issue", repo="o/r", title="Broken thing", body="details")
    assert res["result"] == {"number": 42, "url": "https://github.com/o/r/issues/42"}
    assert ("create_issue", "o/r", "Broken thing", "details") in gh.log


def test_github_create_issue_body_defaults_to_empty(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "t")
    invoke(gh, "create_issue", repo="o/r", title="No body")
    assert ("create_issue", "o/r", "No body", "") in gh.log


def test_github_list_issues_asks_for_open_ones(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "t")
    res = invoke(gh, "list_issues", repo="o/r")
    assert [i["title"] for i in res["result"]] == ["first", "second"]
    assert ("get_issues", "o/r", "open") in gh.log


def test_github_never_echoes_the_token(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "super-secret-token-value")
    for tool, params in (("list_repos", {}), ("list_issues", {"repo": "o/r"})):
        assert "super-secret-token-value" not in str(invoke(gh, tool, **params))
    assert "super-secret-token-value" not in str(invoke(gh, "list_repos", token=None))


def test_github_missing_required_argument_is_a_clean_error(gh, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "t")
    assert invoke(gh, "create_issue", repo="o/r")["status"] == "error"      # title missing


# =============================== rest_api ===============================

class FakeResponse:
    def __init__(self, status=200, json_data=None, body="", headers=None):
        self.status_code, self._json, self.text = status, json_data, body
        self.headers = headers or {"content-type": "application/json"}

    def json(self):
        if self._json is None:
            raise ValueError("not json")
        return self._json


@pytest.fixture
def rest(monkeypatch):
    from tools import rest_api_server
    calls = []
    reply = {"value": FakeResponse(200, {"hello": "world"})}

    def fake_request(method, url, headers=None, json=None, timeout=None):
        calls.append({"method": method, "url": url, "headers": headers, "json": json, "timeout": timeout})
        if isinstance(reply["value"], Exception):
            raise reply["value"]
        return reply["value"]

    monkeypatch.setattr(rest_api_server.requests, "request", fake_request)
    client = spoke_client(rest_api_server.app)
    client.calls, client.reply = calls, reply
    return client


def test_rest_get_json(rest):
    res = invoke(rest, "http_request", method="get", url="https://example.test/api")["result"]
    assert res["status_code"] == 200 and res["body"] == {"hello": "world"}
    assert rest.calls[0]["method"] == "GET"            # upper-cased
    assert rest.calls[0]["timeout"] == 15              # never waits forever


def test_rest_passes_headers_and_json_body(rest):
    invoke(rest, "http_request", method="POST", url="https://example.test/x",
           headers={"X-Thing": "1"}, json_body={"a": 1})
    call = rest.calls[0]
    assert call["headers"] == {"X-Thing": "1"} and call["json"] == {"a": 1}


def test_rest_non_json_body_is_returned_as_text_and_capped(rest):
    rest.reply["value"] = FakeResponse(200, None, "x" * 20000, {"content-type": "text/plain"})
    body = invoke(rest, "http_request", method="GET", url="https://example.test")["result"]["body"]
    assert isinstance(body, str) and len(body) == 5000


def test_rest_error_status_is_reported_not_raised(rest):
    rest.reply["value"] = FakeResponse(404, {"error": "nope"})
    res = invoke(rest, "http_request", method="GET", url="https://example.test")
    assert res["status"] == "ok" and res["result"]["status_code"] == 404


def test_rest_network_failure_is_a_clean_error(rest):
    import requests
    rest.reply["value"] = requests.ConnectionError("dns failure")
    res = invoke(rest, "http_request", method="GET", url="https://example.test")
    assert res["status"] == "error" and "dns failure" in res["error"]


def test_rest_missing_url_is_a_clean_error(rest):
    assert invoke(rest, "http_request", method="GET")["status"] == "error"


# =============================== cursor ===============================

@pytest.fixture
def cursor(monkeypatch):
    from tools import cursor_server
    launched = []
    monkeypatch.setattr(cursor_server.shutil, "which", lambda name: "/fake/bin/cursor")
    monkeypatch.setattr(cursor_server.subprocess, "Popen", lambda args, **kw: launched.append(args))
    client = spoke_client(cursor_server.app)
    client.launched, client.module = launched, cursor_server
    return client


def test_cursor_open_path(cursor):
    res = invoke(cursor, "open_path", path="/home/me/project")
    assert res["result"] == {"opened": "/home/me/project"}
    assert cursor.launched == [["/fake/bin/cursor", "/home/me/project"]]


def test_cursor_open_diff(cursor):
    invoke(cursor, "open_diff", file_a="/a.txt", file_b="/b.txt")
    assert cursor.launched == [["/fake/bin/cursor", "--diff", "/a.txt", "/b.txt"]]


def test_cursor_missing_cli_explains_what_to_do(cursor, monkeypatch):
    monkeypatch.setattr(cursor.module.shutil, "which", lambda name: None)
    res = invoke(cursor, "open_path", path="/x")
    assert res["status"] == "error" and "Install Cursor" in res["error"]
    assert cursor.launched == []


def test_cursor_refuses_paths_that_look_like_options(cursor):
    for bad in ("--install-extension=evil", "-n", ""):
        res = invoke(cursor, "open_path", path=bad)
        assert res["status"] == "error", bad
    assert invoke(cursor, "open_diff", file_a="--user-data-dir=/tmp/x", file_b="/b")["status"] == "error"
    assert cursor.launched == []                   # nothing was launched


def test_cursor_allows_dot_slash_relative_names(cursor):
    assert invoke(cursor, "open_path", path="./-weird-name")["status"] == "ok"
