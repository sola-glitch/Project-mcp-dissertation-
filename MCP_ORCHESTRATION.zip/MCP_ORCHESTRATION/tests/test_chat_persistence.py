"""Chats survive a restart, are encrypted on disk, and can be reopened, continued and deleted."""

import json

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text

import ai_agent
import chat_store
import crypto
import hub_api
from ai_agent import AIConfig, Chat
from sse_helpers import anthropic_text, anthropic_tool, sse_response

TOKEN = "persist-token"
AUTH = {"Authorization": f"Bearer {TOKEN}"}


@pytest.fixture
def client(spokes, monkeypatch):
    hub_api.app.state.token = TOKEN
    hub_api.hub.discover()
    hub_api.chats.clear()
    monkeypatch.setattr(hub_api, "ai_config", AIConfig(provider="anthropic", api_key="k", model="m"))
    return TestClient(hub_api.app)


def provider(monkeypatch, *responses):
    sent, it = [], iter(responses)

    def handler(req):
        sent.append(json.loads(req.content))
        return next(it)

    monkeypatch.setattr(ai_agent, "_client", lambda: httpx.Client(transport=httpx.MockTransport(handler)))
    return sent


def events(resp):
    return [json.loads(l) for l in resp.text.splitlines() if l.strip()]


def restart():
    """What a server restart does to the in-memory state."""
    hub_api.chats.clear()


# ---------------- store ----------------

def test_chat_roundtrip(isolated_state):
    chat = Chat(messages=[{"role": "user", "content": "hello there"},
                          {"role": "assistant", "content": [{"type": "text", "text": "hi"}]}])
    chat_store.save_chat("c1", chat)
    loaded = chat_store.load_chat("c1")
    assert loaded.messages == chat.messages and loaded.title() == "hello there"


def test_unknown_chat_is_none(isolated_state):
    assert chat_store.load_chat("nope") is None


def test_chats_are_encrypted_on_disk(isolated_state):
    chat = Chat(messages=[{"role": "user", "content": "my secret plan: TOPSECRET-PHRASE"}])
    chat_store.save_chat("c1", chat)
    with chat_store._engine().connect() as conn:
        raw = conn.execute(text("SELECT state FROM ai_chats WHERE chat_id='c1'")).scalar()
    assert crypto.is_encrypted(raw) and "TOPSECRET" not in raw


def test_pending_approval_survives_save_and_load(isolated_state):
    call = ai_agent.ToolCall(id="t1", name="run_command", args={"command": "echo x"})
    chat = Chat(messages=[{"role": "user", "content": "go"}], pending=[call], turn_text="working")
    chat_store.save_chat("c1", chat)
    loaded = chat_store.load_chat("c1")
    assert loaded.awaiting() == [{"id": "t1", "tool": "run_command", "params": {"command": "echo x"}}]


def test_list_is_newest_first_and_titled(isolated_state):
    for i in range(3):
        chat_store.save_chat(f"c{i}", Chat(messages=[{"role": "user", "content": f"question {i}"}]))
    listing = chat_store.list_chats()
    assert [c["title"] for c in listing] == ["question 2", "question 1", "question 0"]


def test_old_chats_are_pruned(isolated_state, monkeypatch):
    monkeypatch.setattr(chat_store, "MAX_CHATS", 3)
    for i in range(6):
        chat_store.save_chat(f"c{i}", Chat(messages=[{"role": "user", "content": f"q{i}"}]))
    assert [c["chat_id"] for c in chat_store.list_chats()] == ["c5", "c4", "c3"]


def test_delete_chat(isolated_state):
    chat_store.save_chat("c1", Chat(messages=[{"role": "user", "content": "x"}]))
    chat_store.delete_chat("c1")
    assert chat_store.load_chat("c1") is None


def test_listing_survives_a_changed_key(isolated_state, monkeypatch):
    chat_store.save_chat("c1", Chat(messages=[{"role": "user", "content": "x"}]))
    monkeypatch.setattr(crypto, "KEY_FILE", isolated_state / "different.key")
    assert "cannot decrypt" in chat_store.list_chats()[0]["title"]


def test_transcript_for_both_provider_formats():
    anthropic = Chat(messages=[
        {"role": "user", "content": "list"},
        {"role": "assistant", "content": [{"type": "text", "text": "Looking."},
                                          {"type": "tool_use", "id": "1", "name": "list_dir", "input": {}}]},
        {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "1", "content": "{}"}]},
        {"role": "assistant", "content": [{"type": "text", "text": "Done."}]},
    ])
    assert anthropic.transcript() == [
        {"role": "user", "text": "list"}, {"role": "assistant", "text": "Looking."},
        {"role": "step", "text": "-> list_dir"}, {"role": "assistant", "text": "Done."}]
    openai = Chat(messages=[
        {"role": "user", "content": "go"},
        {"role": "assistant", "content": "", "tool_calls": [
            {"id": "c", "type": "function", "function": {"name": "run_python", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "c", "content": "{}"},
        {"role": "assistant", "content": "Finished."}])
    assert [t["text"] for t in openai.transcript()] == ["go", "-> run_python", "Finished."]


# ---------------- over HTTP, across a "restart" ----------------

def test_chat_continues_with_its_history_after_a_restart(client, monkeypatch):
    sent = provider(monkeypatch, sse_response(anthropic_text("Nice to meet you, Sam.")),
                    sse_response(anthropic_text("Your name is Sam.")))
    first = events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "My name is Sam."}))
    chat_id = first[0]["chat_id"]

    restart()
    assert chat_id not in hub_api.chats
    second = events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "What is my name?", "chat_id": chat_id}))
    assert second[0]["chat_id"] == chat_id and second[-1]["reply"] == "Your name is Sam."
    sent_messages = json.dumps(sent[1]["messages"])
    assert "My name is Sam." in sent_messages and "Nice to meet you, Sam." in sent_messages   # remembered


def test_list_open_and_delete_over_http(client, monkeypatch):
    provider(monkeypatch, sse_response(anthropic_text("Hello!")))
    chat_id = events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "Say hello"}))[0]["chat_id"]
    restart()

    listing = client.get("/api/ai/chats", headers=AUTH).json()
    assert listing[0]["chat_id"] == chat_id and listing[0]["title"] == "Say hello"
    opened = client.get(f"/api/ai/chats/{chat_id}", headers=AUTH).json()
    assert opened["ok"] and opened["transcript"] == [
        {"role": "user", "text": "Say hello"}, {"role": "assistant", "text": "Hello!"}]
    assert client.delete(f"/api/ai/chats/{chat_id}", headers=AUTH).json() == {"ok": True}
    assert client.get("/api/ai/chats", headers=AUTH).json() == []
    assert client.get(f"/api/ai/chats/{chat_id}", headers=AUTH).json()["ok"] is False


def test_chat_endpoints_need_the_token(client):
    for method, path in (("get", "/api/ai/chats"), ("get", "/api/ai/chats/x"), ("delete", "/api/ai/chats/x")):
        assert getattr(client, method)(path).status_code == 401


def test_approval_waiting_across_a_restart_can_still_be_answered(client, monkeypatch):
    provider(monkeypatch,
             sse_response(anthropic_tool("run_command", ['{"command": "echo after-restart"}'])),
             sse_response(anthropic_text("It ran.")))
    first = events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "run it"}))
    assert first[-1]["type"] == "needs_approval"
    chat_id = first[0]["chat_id"]

    restart()
    opened = client.get(f"/api/ai/chats/{chat_id}", headers=AUTH).json()
    assert opened["pending"][0]["tool"] == "run_command"                  # the UI can show the Allow/Deny card again
    resumed = events(client.post("/api/ai/approve/stream", headers=AUTH,
                                 json={"chat_id": chat_id, "decisions": {"tu_1": True}}))
    assert resumed[1]["type"] == "step" and resumed[1]["status"] == "ok" and resumed[-1]["reply"] == "It ran."


def test_non_streaming_endpoints_also_persist(client, monkeypatch):
    provider(monkeypatch, httpx.Response(200, json={"content": [{"type": "text", "text": "plain reply"}]}))
    res = client.post("/api/ai/chat", headers=AUTH, json={"message": "hi there"}).json()
    restart()
    assert client.get(f"/api/ai/chats/{res['chat_id']}", headers=AUTH).json()["transcript"][-1]["text"] == "plain reply"


def test_a_save_failure_never_loses_the_reply(client, monkeypatch):
    provider(monkeypatch, sse_response(anthropic_text("still here")))

    def broken(*a, **k):
        raise RuntimeError("disk full")

    monkeypatch.setattr(chat_store, "save_chat", broken)
    evs = events(client.post("/api/ai/chat/stream", headers=AUTH, json={"message": "x"}))
    assert evs[-1] == {"type": "done", "reply": "still here"}
