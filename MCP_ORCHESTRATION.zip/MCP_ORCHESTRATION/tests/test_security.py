"""Shared secret between hub and spokes, encrypted vault, encrypted sessions."""

import json
import stat
import sys

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text

import auth
import credential_vault
import crypto
import session_manager


# ---------------- spoke shared secret ----------------

def test_spokes_refuse_calls_without_the_shared_secret():
    from tools.shell_server import app
    client = TestClient(app)
    assert client.get("/manifest").status_code == 401
    assert client.post("/invoke", json={"tool": "run_command", "params": {"command": "echo hi"}}).status_code == 401
    assert client.get("/manifest", headers={"X-Spoke-Key": "wrong"}).status_code == 401


def test_spokes_accept_the_right_secret_and_health_stays_open():
    from tools.shell_server import app
    client = TestClient(app)
    assert client.get("/health").status_code == 200
    ok = client.post("/invoke", headers={"X-Spoke-Key": "test-spoke-secret"},
                     json={"tool": "run_command", "params": {"command": "echo hi"}})
    assert ok.status_code == 200 and "hi" in ok.text


def test_every_spoke_enforces_the_secret():
    from tools import (code_exec_server, crud_files_server, cursor_server, database_server, filesystem_server,
                       github_server, rest_api_server, shell_server, toolmaker_server)
    for mod in (code_exec_server, crud_files_server, cursor_server, database_server, filesystem_server,
                github_server, rest_api_server, shell_server, toolmaker_server):
        assert TestClient(mod.app).get("/manifest").status_code == 401, mod.__name__


def test_hub_sends_the_secret(spokes):
    from hub import Hub
    h = Hub()
    h.discover()
    assert "run_command" in h.catalog          # the in-process spokes demand the key, so this proves it was sent


def test_hub_reports_a_spoke_that_rejects_the_secret(spokes, monkeypatch, capsys):
    import hub as hub_module
    from hub import Hub
    monkeypatch.setattr(hub_module, "_spoke_headers", lambda: {"X-Spoke-Key": "a-different-secret"})
    h = Hub()
    h.discover()
    assert h.catalog == {}
    assert "rejected the shared secret" in capsys.readouterr().out


def test_spoke_secret_file_is_created_once_and_private(isolated_state, monkeypatch):
    monkeypatch.setenv("SPOKE_SECRET", "")
    first = auth.get_or_create_spoke_secret()
    assert first == auth.get_or_create_spoke_secret() and len(first) >= 32
    if sys.platform != "win32":
        assert stat.S_IMODE(auth.SPOKE_SECRET_FILE.stat().st_mode) == 0o600


def test_hub_token_file_is_private(isolated_state):
    auth.get_or_create_token()
    if sys.platform != "win32":
        assert stat.S_IMODE(auth.TOKEN_FILE.stat().st_mode) == 0o600


# ---------------- encrypted vault ----------------

def raw_secret(service):
    with credential_vault.engine.connect() as conn:
        return conn.execute(text("SELECT secret FROM credentials WHERE service=:s"), {"s": service}).scalar()


def test_credentials_are_encrypted_at_rest(isolated_state):
    credential_vault.save_credential("svc", "alice", "hunter2-super-secret")
    stored = raw_secret("svc")
    assert crypto.is_encrypted(stored)
    assert "hunter2" not in stored
    assert credential_vault.get_credential("svc")["secret"] == "hunter2-super-secret"


def test_legacy_base64_credentials_are_read_and_upgraded(isolated_state):
    import base64
    legacy = base64.b64encode(b"old-secret").decode()
    with credential_vault.engine.begin() as conn:
        conn.execute(text("INSERT INTO credentials (service, username, secret, created_at) VALUES ('old','bob',:s,'x')"),
                     {"s": legacy})
    assert credential_vault.get_credential("old")["secret"] == "old-secret"
    assert crypto.is_encrypted(raw_secret("old"))           # upgraded in place
    assert credential_vault.get_credential("old")["secret"] == "old-secret"


def test_wrong_key_gives_a_clear_error_not_garbage(isolated_state, monkeypatch):
    credential_vault.save_credential("svc", "u", "s3cret")
    monkeypatch.setattr(crypto, "KEY_FILE", isolated_state / "other.key")      # a different key
    with pytest.raises(crypto.CryptoError, match="key is wrong or missing"):
        credential_vault.get_credential("svc")


def test_vault_key_from_environment_wins_and_no_file_is_made(isolated_state, monkeypatch):
    from cryptography.fernet import Fernet
    monkeypatch.setenv("VAULT_KEY", Fernet.generate_key().decode())
    credential_vault.save_credential("svc", "u", "s3cret")
    assert not crypto.KEY_FILE.exists()
    assert credential_vault.get_credential("svc")["secret"] == "s3cret"


def test_invalid_vault_key_is_rejected(isolated_state, monkeypatch):
    monkeypatch.setenv("VAULT_KEY", "not-a-real-key")
    with pytest.raises(crypto.CryptoError, match="not a valid Fernet key"):
        crypto.encrypt("x")


def test_key_file_is_private(isolated_state):
    crypto.encrypt("x")
    if sys.platform != "win32":
        assert stat.S_IMODE(crypto.KEY_FILE.stat().st_mode) == 0o600


def test_encrypting_twice_gives_different_output(isolated_state):
    assert crypto.encrypt("same") != crypto.encrypt("same")


# ---------------- encrypted sessions ----------------

def test_session_state_is_encrypted_and_legacy_plain_json_still_loads(isolated_state):
    sid = session_manager.new_session()
    session_manager.append_history(sid, {"tool": "read_file", "result": "TOP-SECRET-FILE-CONTENT"})
    with session_manager.engine.connect() as conn:
        raw = conn.execute(text("SELECT state_json FROM sessions WHERE session_id=:s"), {"s": sid}).scalar()
    assert "TOP-SECRET" not in raw and crypto.is_encrypted(raw)
    assert session_manager.load_session(sid)["history"][0]["result"] == "TOP-SECRET-FILE-CONTENT"

    with session_manager.engine.begin() as conn:       # a row written before encryption existed
        conn.execute(text("INSERT INTO sessions (session_id, state_json, updated_at) VALUES ('legacy', :j, 'x')"),
                     {"j": json.dumps({"history": [], "cwd": "/old"})})
    assert session_manager.load_session("legacy")["cwd"] == "/old"
