"""The AI assistant, tested against a fake provider (no real API key or network needed)."""

import json

import httpx
import pytest

import ai_agent
from ai_agent import Agent, AIConfig, AIError, Chat
from hub import Hub


def use_fake_provider(monkeypatch, handler):
    monkeypatch.setattr(ai_agent, "_client", lambda: httpx.Client(transport=httpx.MockTransport(handler)))


def anthropic_cfg():
    return AIConfig(provider="anthropic", api_key="sk-test", model="some-model")


def openai_cfg():
    return AIConfig(provider="openai", api_key="sk-test", model="some-model")


def make_agent(cfg):
    h = Hub()
    h.discover()
    return Agent(h, cfg)


# ---------------- configuration ----------------

def test_config_problems():
    assert "provider" in AIConfig().problem().lower()
    assert "key" in AIConfig(provider="anthropic", model="m").problem().lower()
    assert "model" in AIConfig(provider="anthropic", api_key="k").problem().lower()
    assert AIConfig(provider="anthropic", api_key="k", model="m").problem() is None


def test_local_openai_compatible_server_needs_no_key():
    cfg = AIConfig(provider="openai", model="llama", base_url="http://localhost:11434/v1")
    assert cfg.problem() is None


def test_public_config_never_contains_the_key():
    pub = anthropic_cfg().public()
    assert "sk-test" not in json.dumps(pub)
    assert pub["has_key"] is True


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("AI_PROVIDER", "openai")
    monkeypatch.setenv("AI_MODEL", "m1")
    monkeypatch.setenv("OPENAI_API_KEY", "k1")
    cfg = AIConfig.from_env()
    assert (cfg.provider, cfg.model, cfg.api_key) == ("openai", "m1", "k1")


def test_unconfigured_agent_refuses(spokes):
    with pytest.raises(AIError, match="not configured"):
        make_agent(AIConfig()).send(Chat(), "hi")


# ---------------- model listing ----------------

def test_list_models_anthropic(monkeypatch):
    seen = {}

    def handler(req):
        seen["key"] = req.headers.get("x-api-key")
        seen["url"] = str(req.url)
        return httpx.Response(200, json={"data": [{"id": "b-model"}, {"id": "a-model"}]})

    use_fake_provider(monkeypatch, handler)
    assert ai_agent.list_models(anthropic_cfg()) == ["a-model", "b-model"]
    assert seen["key"] == "sk-test" and "/v1/models" in seen["url"]


def test_list_models_openai_custom_base_url(monkeypatch):
    seen = {}

    def handler(req):
        seen["url"] = str(req.url)
        seen["auth"] = req.headers.get("authorization")
        return httpx.Response(200, json={"data": [{"id": "x"}]})

    use_fake_provider(monkeypatch, handler)
    cfg = AIConfig(provider="openai", api_key="k", base_url="https://example.test/v1")
    assert ai_agent.list_models(cfg) == ["x"]
    assert seen["url"] == "https://example.test/v1/models" and seen["auth"] == "Bearer k"


def test_bad_key_gives_a_helpful_error(monkeypatch):
    use_fake_provider(monkeypatch, lambda req: httpx.Response(401, json={"error": {"message": "invalid x-api-key"}}))
    with pytest.raises(AIError, match="check your API key"):
        ai_agent.list_models(anthropic_cfg())


# ---------------- Anthropic tool loop ----------------

def anthropic_script(*responses):
    """Serve the given responses in order and record each request body."""
    sent = []
    it = iter(responses)

    def handler(req):
        sent.append(json.loads(req.content))
        return httpx.Response(200, json=next(it))

    return handler, sent


def tool_use(name, args, id="tu_1"):
    return {"content": [{"type": "tool_use", "id": id, "name": name, "input": args}], "stop_reason": "tool_use"}


def text(t):
    return {"content": [{"type": "text", "text": t}], "stop_reason": "end_turn"}


def test_anthropic_safe_tool_runs_without_approval(spokes, monkeypatch):
    handler, sent = anthropic_script(tool_use("list_dir", {}), text("Here are your files."))
    use_fake_provider(monkeypatch, handler)
    result = make_agent(anthropic_cfg()).send(Chat(), "what files are here?")

    assert result["status"] == "done" and result["reply"] == "Here are your files."
    assert result["steps"][0]["tool"] == "list_dir" and result["steps"][0]["status"] == "ok"
    first = sent[0]
    assert first["model"] == "some-model"
    names = [t["name"] for t in first["tools"]]
    assert "list_dir" in names and "run_command" in names
    assert all("input_schema" in t for t in first["tools"])
    followup = sent[1]["messages"][-1]
    assert followup["role"] == "user" and followup["content"][0]["type"] == "tool_result"
    assert followup["content"][0]["tool_use_id"] == "tu_1"


def test_dangerous_tool_waits_for_approval_then_runs(spokes, monkeypatch):
    handler, sent = anthropic_script(
        tool_use("run_command", {"command": "echo approved-run"}), text("Done, it printed approved-run."))
    use_fake_provider(monkeypatch, handler)
    agent, chat = make_agent(anthropic_cfg()), Chat()

    first = agent.send(chat, "run echo")
    assert first["status"] == "needs_approval"
    assert first["pending"][0]["tool"] == "run_command"
    assert first["steps"] == []                       # nothing ran yet
    assert len(sent) == 1                             # model not called again yet

    final = agent.resume(chat, {first["pending"][0]["id"]: True})
    assert final["status"] == "done"
    assert final["steps"][0]["status"] == "ok"
    assert "approved-run" in json.dumps(sent[1]["messages"][-1])


def test_denied_tool_never_runs(spokes, monkeypatch, tmp_path):
    target = tmp_path / "should_not_exist.txt"
    handler, sent = anthropic_script(
        tool_use("create_file", {"path": str(target), "content": "x"}), text("Understood, I did not create it."))
    use_fake_provider(monkeypatch, handler)
    agent, chat = make_agent(anthropic_cfg()), Chat()

    first = agent.send(chat, "create a file")
    final = agent.resume(chat, {first["pending"][0]["id"]: False})
    assert final["steps"][0]["status"] == "denied"
    assert not target.exists()
    assert "denied" in json.dumps(sent[1]["messages"][-1]).lower()


def test_unknown_tool_from_model_is_reported_back(spokes, monkeypatch):
    handler, sent = anthropic_script(tool_use("no_such_tool", {}), text("Sorry."))
    use_fake_provider(monkeypatch, handler)
    result = make_agent(anthropic_cfg()).send(Chat(), "do it")
    assert result["steps"][0]["status"] == "error"
    assert "no tool named" in json.dumps(sent[1]["messages"][-1]).lower()


def test_loop_stops_after_max_rounds(spokes, monkeypatch):
    monkeypatch.setattr(ai_agent, "MAX_ROUNDS", 3)
    use_fake_provider(monkeypatch, lambda req: httpx.Response(200, json=tool_use("list_dir", {})))
    result = make_agent(anthropic_cfg()).send(Chat(), "loop forever")
    assert "Stopped after 3" in result["reply"]


def test_new_message_while_waiting_denies_the_pending_call(spokes, monkeypatch):
    handler, sent = anthropic_script(
        tool_use("run_command", {"command": "echo nope"}), text("Okay, skipped."))
    use_fake_provider(monkeypatch, handler)
    agent, chat = make_agent(anthropic_cfg()), Chat()
    assert agent.send(chat, "run it")["status"] == "needs_approval"
    result = agent.send(chat, "actually never mind")
    assert result["status"] == "done"
    assert any(s["status"] == "denied" for s in result["steps"])


# ---------------- OpenAI-compatible tool loop ----------------

def openai_msg(content=None, tool_calls=None):
    msg = {"role": "assistant", "content": content}
    if tool_calls:
        msg["tool_calls"] = tool_calls
    return {"choices": [{"message": msg}]}


def oa_call(name, args, id="call_1"):
    return {"id": id, "type": "function", "function": {"name": name, "arguments": json.dumps(args)}}


def test_openai_tool_loop_with_approval(spokes, monkeypatch):
    sent, headers = [], {}
    responses = iter([
        openai_msg(tool_calls=[oa_call("run_python", {"code": "print(2+3)"})]),
        openai_msg(content="The answer is 5."),
    ])

    def handler(req):
        headers["auth"] = req.headers.get("authorization")
        sent.append(json.loads(req.content))
        return httpx.Response(200, json=next(responses))

    use_fake_provider(monkeypatch, handler)
    agent, chat = make_agent(openai_cfg()), Chat()

    first = agent.send(chat, "add 2 and 3")
    assert first["status"] == "needs_approval"
    final = agent.resume(chat, {"call_1": True})
    assert final["reply"] == "The answer is 5."
    assert headers["auth"] == "Bearer sk-test"
    assert sent[0]["messages"][0]["role"] == "system"
    assert sent[0]["tools"][0]["type"] == "function"
    tool_msg = sent[1]["messages"][-1]
    assert tool_msg["role"] == "tool" and tool_msg["tool_call_id"] == "call_1" and "5" in tool_msg["content"]


def test_openai_bad_json_arguments_are_reported_not_run(spokes, monkeypatch):
    bad = {"id": "c1", "type": "function", "function": {"name": "run_command", "arguments": "{not json"}}
    responses = iter([openai_msg(tool_calls=[bad]), openai_msg(content="ok")])
    use_fake_provider(monkeypatch, lambda req: httpx.Response(200, json=next(responses)))
    result = make_agent(openai_cfg()).send(Chat(), "go")
    assert result["status"] == "done"
    assert result["steps"][0]["status"] == "error"


def test_ask_blocking_asks_confirm_for_dangerous_calls(spokes, monkeypatch):
    responses = iter([
        openai_msg(tool_calls=[oa_call("run_command", {"command": "echo hi"})]),
        openai_msg(content="finished"),
    ])
    use_fake_provider(monkeypatch, lambda req: httpx.Response(200, json=next(responses)))
    asked = []
    result = ai_agent.ask_blocking(
        make_agent(openai_cfg()), Chat(), "run it", lambda tool, params: asked.append(tool) or True)
    assert asked == ["run_command"]
    assert result["reply"] == "finished" and result["steps"][0]["status"] == "ok"


def test_ai_calls_are_audited_as_ai(spokes, monkeypatch):
    import hub as hub_module
    handler, _ = anthropic_script(tool_use("list_dir", {}), text("done"))
    use_fake_provider(monkeypatch, handler)
    make_agent(anthropic_cfg()).send(Chat(), "list")
    entries = [json.loads(l) for l in hub_module.AUDIT_LOG_PATH.read_text().splitlines()]
    assert entries[-1]["source"] == "ai"


def test_reading_files_and_sql_also_need_approval(spokes, monkeypatch):
    """read_file / query can expose secrets (.env, saved credentials), so the AI must ask first."""
    from hub import APPROVAL_REQUIRED
    assert {"read_file", "query"} <= APPROVAL_REQUIRED
    assert "list_dir" not in APPROVAL_REQUIRED
    handler, _ = anthropic_script(tool_use("read_file", {"path": "/tmp/whatever"}))
    use_fake_provider(monkeypatch, handler)
    result = make_agent(anthropic_cfg()).send(Chat(), "read my secrets")
    assert result["status"] == "needs_approval" and result["pending"][0]["tool"] == "read_file"
