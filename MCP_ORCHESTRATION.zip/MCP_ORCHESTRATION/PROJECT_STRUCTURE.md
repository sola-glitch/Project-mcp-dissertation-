# PROJECT STRUCTURE — MCP Orchestration System

## Layout

```
MCP_ORCHESTRATION/
├── agent.py                  # CLI entry point
├── hub.py                    # central orchestrator (used by both agent.py and hub_api.py)
├── hub_api.py                 # HTTP wrapper around Hub + serves the web UI (token-protected /api)
├── ai_agent.py               # optional AI assistant: bring-your-own provider/model/key, approval gating
├── mcp_server.py             # exposes the hub's tools to MCP clients over stdio
├── auth.py                   # hub API token + hub-to-spoke shared secret (atomic, owner-only files)
├── crypto.py                 # Fernet encryption for credentials, sessions and chats (VAULT_KEY / .vault_key)
├── chat_store.py             # saves AI chats (encrypted) so they survive a restart
├── check_ai.py               # run with YOUR key: tests settings, reply, streaming and tool use
├── config.py                 # loads .env once; data folder (HUB_DATA_DIR) and allowed roots
├── Dockerfile                # locked-down container image
├── docker-compose.yml        # non-root, read-only, no capabilities, one workspace folder, localhost port
├── run_all.py                # one command: starts every spoke (+ web UI)
├── web/
│   └── index.html              # browser control panel (spoke wheel, catalog, AI panel, console, audit log)
├── session_manager.py        # save/resume session state
├── credential_vault.py       # store/create credentials per service
├── connectors.py             # link spokes to each other or external apps
├── requirements.txt
├── .env.example
├── mcp_data.db                # created at runtime (SQLite) — sessions + credentials
├── audit.log                  # created at runtime — one JSON line per hub.call()
├── tools/
│   ├── __init__.py
│   ├── _base.py               # Spoke class: manifest + invoke contract
│   ├── _server_factory.py     # turns a Spoke into a runnable FastAPI app
│   ├── rest_api_server.py     # outbound HTTP requests
│   ├── database_server.py     # SQLite queries against mcp_data.db
│   ├── code_exec_server.py    # sandboxed Python execution
│   ├── github_server.py       # GitHub repos/issues via PyGithub
│   ├── cursor_server.py       # open files/folders in Cursor editor
│   ├── toolmaker_server.py    # scaffolds new spokes on demand
│   ├── filesystem_server.py   # navigate/list/search (read-only)
│   ├── crud_files_server.py   # create/read/update/delete files
│   └── shell_server.py        # bash/cmd/powershell execution
└── tests/
    ├── conftest.py            # temp-file fixtures + in-process spokes
    ├── test_spokes.py
    ├── test_hub.py
    ├── test_state.py          # sessions, credential vault, auth token
    ├── test_hub_api.py        # web API, login token, AI endpoints
    ├── test_security.py       # spoke secret, encrypted vault and sessions
    ├── test_spokes_full.py    # database, GitHub, REST, Cursor spokes
    ├── test_code_exec.py      # code runner limits, cleanup, Docker mode
    ├── test_streaming.py      # streaming replies and check_ai.py
    ├── test_chat_persistence.py
    ├── test_config_and_schema.py
    ├── test_ui.py             # browser test (needs Node + `npm install` in tests/ui)
    ├── fake_ai_server.py, sse_helpers.py, ui/
    ├── test_ai_agent.py       # AI assistant against a fake provider
    └── test_mcp_server.py     # MCP protocol + real stdio round trip
```

## Why hub-and-spoke

Every spoke is an independent FastAPI process that only knows how to do one thing
(hit the filesystem, run SQL, call GitHub, etc). The hub doesn't know *how* any spoke
does its job — it only knows each spoke's **manifest** (what tools it offers) and
calls **`/invoke`** with a tool name and parameters. This means:

- A spoke can be restarted, replaced, or crash without taking down the others.
- New capabilities are added by writing a new spoke, not by editing the hub.
- Each spoke can be given different privileges (e.g. the shell spoke needs far more
  trust than the filesystem spoke), which matters for the security discussion in
  the dissertation.

## The contract every spoke follows

Defined once in `tools/_base.py` and `tools/_server_factory.py`, reused by every
spoke file so they're all interchangeable from the hub's point of view:

- `GET /manifest` → `{name, description, tools: [{name, description, params, input_schema}]}`
  (`input_schema` is a JSON Schema generated from the tool function's type hints)
- `POST /invoke` with `{tool, params}` → `{status: "ok"|"error", result|error}`
- `GET /health` → liveness check

A spoke file itself is just:
```python
spoke = Spoke("my_spoke", "what it does")

@spoke.tool("my_tool", "what this tool does", params={"x": "description"})
def my_tool(x):
    ...

app = make_app(spoke)
```

## hub.py — what it actually does

1. **`discover()`** — pings every spoke in `SPOKE_REGISTRY`'s `/manifest`, builds a
   flat `tool name → spoke` catalog so callers don't need to know which spoke owns
   which tool.
2. **`call(spoke, tool, params)`** — the low-level call: POSTs to that spoke's
   `/invoke`, writes an audit log line, appends to session history if a session is
   active.
3. **`route(tool, params)`** — the high-level call: looks up which spoke owns
   `tool` from the catalog and calls it. Raises `LookupError` if nothing matches,
   which is what triggers the Tool Maker prompt flow.
4. **`offer_to_create_tool(...)`** — called after a `LookupError`, if the user
   confirms, asks the Tool Maker spoke to scaffold a new spoke file.
5. **`get_or_create_credential(...)`** — thin wrapper around `credential_vault.py`.

## Why session state, credentials, and connectors are separate files

They aren't spokes (no HTTP server, no manifest) — they're plain Python modules the
hub imports directly, because they're hub-internal concerns rather than task-facing
capabilities. Keeping them out of `tools/` keeps the spoke directory to "things an
external task can invoke," which is the dissertation's core architectural claim.

## Two spokes with an explicit trust boundary

- **`filesystem_server.py`** is read-only on purpose. Write access lives in
  **`crud_files_server.py`** instead, so a task can be granted "look around"
  without also being granted "change things."
- **`shell_server.py`** is the highest-privilege spoke in the system — it has no
  command allow/denylist by design (denylists are trivially bypassed), so the
  actual control is the audit log plus whatever OS-level account restrictions you
  run the whole hub under. Documented directly in that file's docstring.

## The web UI

`hub_api.py` is a thin FastAPI wrapper around the same `Hub` class `agent.py` uses —
it exposes `/api/status`, `/api/tools`, `/api/call`, `/api/route`, `/api/sessions`,
`/api/maketool`, and `/api/audit`, then mounts `web/index.html` as static files at
`/`. A browser can't import `hub.py` directly, so this is what makes the hub
reachable from a page instead of only from a terminal. Both entry points
(`agent.py` and `hub_api.py`) share the same `mcp_data.db` and `audit.log`, so a
session or a logged call is visible from either one.

`web/index.html` is a single self-contained file (HTML/CSS/JS, no build step) —
its signature element is the spoke wheel: an SVG diagram with the hub at the
center and every registered spoke arranged around it, colored by reachability,
with the connecting line pulsing when that spoke handles a call. See
`USAGE_GUIDE.md` for how to run it.

## What's reconstructed vs. original

`rest_api_server.py`, `database_server.py`, `code_exec_server.py`,
`github_server.py`, `cursor_server.py`, and `toolmaker_server.py` are rebuilt from
the pattern described in the dissertation, not your original source files (those
weren't available). `filesystem_server.py`, `crud_files_server.py`,
`shell_server.py`, `session_manager.py`, `credential_vault.py`, `connectors.py`,
`hub.py`, and `agent.py` are new, built to your spec in this conversation.

## Added: AI assistant, login token, MCP server

- **`ai_agent.py`** runs a tool-using loop against a provider the *user* picks
  (`anthropic`, or `openai` plus an optional base URL for any OpenAI-compatible
  service). No key or model ships with the project; keys entered in the UI are kept
  in memory only. Tools in `hub.APPROVAL_REQUIRED` (commands, code, file reads and
  writes, SQL, outbound HTTP) wait for the user's Allow/Deny before they run, and
  every call is audited with `source: "ai"`.
- **`auth.py` + `hub_api.py`**: every `/api/*` request needs `Authorization: Bearer
  <token>`. Spokes require the shared secret (`X-Spoke-Key`) on `/manifest` and
  `/invoke`; `/health` stays open.
- **`mcp_server.py`** is a standards-based MCP server (JSON-RPC 2.0 over stdio:
  initialize, ping, tools/list, tools/call). It reuses the hub's catalog and the
  JSON schemas, so every spoke tool is available to any MCP client. `--safe` hides
  `hub.DANGEROUS_TOOLS`. Resources, prompts and HTTP transport are not implemented.
- **Streaming + saved chats**: providers expose `stream()` (SSE parsing for both
  APIs); the agent is one event generator used by both the streaming and
  non-streaming paths; `/api/ai/chat/stream` returns newline-delimited JSON.
  Chats are saved encrypted by `chat_store.py` after every turn.
- **Code runner**: `tools/code_exec_server.py` runs snippets in a hardened
  subprocess (clean env, rlimits, process-group kill) or, with
  `CODE_EXEC_SANDBOX=docker`, in a no-network throwaway container.
