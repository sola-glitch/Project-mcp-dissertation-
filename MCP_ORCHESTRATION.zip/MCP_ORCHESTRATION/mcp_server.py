"""
mcp_server.py
---------------
Exposes the hub's tools through the Model Context Protocol (MCP) over stdio,
so any MCP client (Claude Desktop, Cursor, VS Code, the MCP Inspector, ...)
can use every spoke's tools.

This is a standards-based MCP *server* (JSON-RPC 2.0, newline-delimited over
stdin/stdout) implementing: initialize, ping, tools/list and tools/call.

The spokes must already be running (python run_all.py --spokes-only).

Client config example (e.g. claude_desktop_config.json):

    {
      "mcpServers": {
        "orchestration": {
          "command": "python",
          "args": ["/full/path/to/mcp_server.py"]
        }
      }
    }

Options:
    --safe     hide tools that run commands/code, change files or data, or
               make outbound requests (hub.DANGEROUS_TOOLS). Also: MCP_SAFE_MODE=1
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, TextIO

SUPPORTED_VERSIONS = ["2025-06-18", "2025-03-26", "2024-11-05"]
SERVER_INFO = {"name": "mcp-orchestration-hub", "version": "1.0.0"}


def _error(msg_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}


def _result(msg_id: Any, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def list_tools(hub, safe: bool) -> list[dict]:
    from hub import DANGEROUS_TOOLS
    hub.discover()
    tools = []
    for name, info in sorted(hub.catalog.items()):
        dangerous = name in DANGEROUS_TOOLS
        if safe and dangerous:
            continue
        tool = {
            "name": name,
            "description": info["description"],
            "inputSchema": info.get("input_schema") or {"type": "object", "properties": {}},
        }
        if dangerous:
            tool["annotations"] = {"destructiveHint": True}
        tools.append(tool)
    return tools


def handle(msg: Any, hub, safe: bool = False) -> dict | None:
    """Handle one JSON-RPC message. Returns the response, or None for notifications."""
    if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
        return _error(msg.get("id") if isinstance(msg, dict) else None, -32600, "Invalid Request")

    method = msg.get("method")
    msg_id = msg.get("id")
    params = msg.get("params") or {}
    is_notification = "id" not in msg

    if method == "initialize":
        requested = params.get("protocolVersion")
        version = requested if requested in SUPPORTED_VERSIONS else SUPPORTED_VERSIONS[0]
        hub.discover()
        return _result(msg_id, {
            "protocolVersion": version,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": SERVER_INFO,
        })

    if method == "ping":
        return _result(msg_id, {})

    if method == "tools/list":
        return _result(msg_id, {"tools": list_tools(hub, safe)})

    if method == "tools/call":
        from hub import DANGEROUS_TOOLS
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(name, str) or not isinstance(arguments, dict):
            return _error(msg_id, -32602, "Invalid params: need a tool name and an arguments object")
        if not hub.catalog:
            hub.discover()
        if name not in hub.catalog or (safe and name in DANGEROUS_TOOLS):
            return _error(msg_id, -32602, f"Unknown tool: {name}")
        try:
            result = hub.route(name, arguments, source="mcp")
            is_error = isinstance(result, dict) and result.get("status") == "error"
            text = json.dumps(result, default=str)
        except Exception as e:  # spoke unreachable, bad response, ...
            is_error, text = True, f"{type(e).__name__}: {e}"
        return _result(msg_id, {"content": [{"type": "text", "text": text}], "isError": is_error})

    if is_notification:
        return None  # e.g. notifications/initialized, notifications/cancelled
    return _error(msg_id, -32601, f"Method not found: {method}")


def serve(hub, stdin: TextIO, stdout: TextIO, safe: bool = False) -> None:
    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            response = _error(None, -32700, "Parse error")
        else:
            response = handle(msg, hub, safe)
        if response is not None:
            stdout.write(json.dumps(response) + "\n")
            stdout.flush()


def main() -> None:
    import config
    config.load_env()
    safe = "--safe" in sys.argv or os.environ.get("MCP_SAFE_MODE", "").lower() in ("1", "true", "yes")

    # stdout belongs to the protocol. Anything the hub prints goes to stderr.
    protocol_out = sys.stdout
    sys.stdout = sys.stderr

    from hub import Hub
    serve(Hub(), sys.stdin, protocol_out, safe)


if __name__ == "__main__":
    main()
