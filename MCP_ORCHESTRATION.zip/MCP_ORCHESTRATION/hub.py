"""
hub.py
--------
The central hub in the hub-and-spoke architecture. Responsibilities:

  1. Register every spoke at startup (ping /manifest, cache its tool catalog).
  2. Route a requested tool call to whichever spoke owns it.
  3. Log every call to audit.log (this matters most for the shell/CRUD spokes).
  4. Fall back to the Tool Maker spoke when no registered spoke has the
     requested tool, and offer to scaffold one.
  5. Use session_manager.py to save/resume session state, and
     credential_vault.py when a task needs an account/credential.

This file assumes each spoke server (tools/*_server.py) is already
running on its configured port. Start them individually, or write a
small process-manager script if you want one command to launch all of
them — that wasn't part of what you asked me to rebuild yet.
"""

from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path

import httpx

import auth
import config
import session_manager
import credential_vault

AUDIT_LOG_PATH = config.data_dir() / "audit.log"

# Maps spoke name -> base URL. Add a line here whenever toolmaker_server
# scaffolds a new spoke and you've filled in its logic.
SPOKE_REGISTRY: dict[str, str] = {
    "rest_api": "http://127.0.0.1:8001",
    "database": "http://127.0.0.1:8002",
    "code_exec": "http://127.0.0.1:8003",
    "github": "http://127.0.0.1:8004",
    "cursor": "http://127.0.0.1:8005",
    "toolmaker": "http://127.0.0.1:8006",
    "filesystem": "http://127.0.0.1:8007",
    "crud_files": "http://127.0.0.1:8008",
    "shell": "http://127.0.0.1:8009",
}


# Tools that run commands, change files/data, or reach outside the machine.
# The MCP adapter can hide these entirely in safe mode.
DANGEROUS_TOOLS: set[str] = {
    "run_command", "run_python",
    "create_file", "update_file", "delete_file",
    "execute", "create_issue", "create_spoke", "http_request",
}

# Tools that read file contents or database rows. Those can hold secrets (.env files,
# the saved-credentials table), so the AI assistant also needs approval for them.
READS_DATA_TOOLS: set[str] = {"read_file", "query"}

# Everything the AI assistant must ask the user about before running.
APPROVAL_REQUIRED: set[str] = DANGEROUS_TOOLS | READS_DATA_TOOLS


def _spoke_headers() -> dict:
    return {"X-Spoke-Key": auth.get_or_create_spoke_secret()}


class Hub:
    def __init__(self):
        self.catalog: dict[str, dict] = {}  # tool_name -> {"spoke": name, "description": ...}
        self.session_id: str | None = None

    # -- startup / discovery -------------------------------------------------

    def discover(self):
        """Ping every registered spoke's /manifest and build the tool catalog."""
        self.catalog.clear()
        for spoke_name, base_url in SPOKE_REGISTRY.items():
            try:
                resp = httpx.get(f"{base_url}/manifest", headers=_spoke_headers(), timeout=3)
                if resp.status_code == 401:
                    print(f"[hub] WARNING: spoke '{spoke_name}' rejected the shared secret (restart it so it picks up the same SPOKE_SECRET)")
                    continue
                resp.raise_for_status()
                manifest = resp.json()
                for tool in manifest.get("tools", []):
                    self.catalog[tool["name"]] = {
                        "spoke": spoke_name,
                        "description": tool["description"],
                        "input_schema": tool.get("input_schema"),
                    }
            except httpx.HTTPError as e:
                print(f"[hub] WARNING: could not reach spoke '{spoke_name}' at {base_url} ({e})")
        return self.catalog

    # -- session handling -----------------------------------------------------

    def start_session(self, resume: str | None = None):
        if resume:
            state = session_manager.load_session(resume)
            if state is None:
                raise ValueError(f"No session found with id '{resume}'")
            self.session_id = resume
            print(f"[hub] Resumed session {resume}")
        else:
            self.session_id = session_manager.new_session()
            print(f"[hub] Started new session {self.session_id}")
        return self.session_id

    # -- calling a spoke --------------------------------------------------------

    def call(self, spoke_name: str, tool: str, params: dict, source: str | None = None):
        if spoke_name not in SPOKE_REGISTRY:
            raise ValueError(f"Unknown spoke '{spoke_name}'")
        base_url = SPOKE_REGISTRY[spoke_name]
        resp = httpx.post(f"{base_url}/invoke", json={"tool": tool, "params": params}, headers=_spoke_headers(), timeout=30)
        resp.raise_for_status()
        result = resp.json()
        self._audit(spoke_name, tool, params, result, source)
        if self.session_id:
            session_manager.append_history(self.session_id, {
                "spoke": spoke_name, "tool": tool, "params": params, "result": result,
            })
        return result

    def route(self, tool: str, params: dict, source: str | None = None):
        """Look up which spoke owns `tool` and call it. Raises if unknown."""
        if tool not in self.catalog:
            raise LookupError(
                f"No spoke has a tool named '{tool}'. Call hub.offer_to_create_tool(...) "
                "to scaffold one via the Tool Maker spoke."
            )
        spoke_name = self.catalog[tool]["spoke"]
        return self.call(spoke_name, tool, params, source=source)

    def offer_to_create_tool(self, name: str, purpose: str, port: int, confirmed: bool):
        """
        Call this when route() raises LookupError. `confirmed` should reflect
        the user's answer to "no tool available for this — create one?".
        """
        if not confirmed:
            return {"status": "declined"}
        result = self.call("toolmaker", "create_spoke", {"name": name, "purpose": purpose, "port": port})
        print(f"[hub] Scaffolded new spoke: {result}")
        print("[hub] Remember to fill in its TODOs, then add it to SPOKE_REGISTRY and restart the hub.")
        return result

    # -- credentials ------------------------------------------------------------

    def get_or_create_credential(self, service: str, create_fn=None):
        return credential_vault.ensure_credential(service, create_fn=create_fn)

    # -- audit log ----------------------------------------------------------------

    def _audit(self, spoke_name: str, tool: str, params: dict, result: dict, source: str | None = None):
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "session": self.session_id,
            "spoke": spoke_name,
            "tool": tool,
            "params": params,
            "status": result.get("status"),
        }
        if source:
            entry["source"] = source  # e.g. "ai" or "mcp" when not a direct human call
        with AUDIT_LOG_PATH.open("a") as f:
            f.write(json.dumps(entry) + "\n")


if __name__ == "__main__":
    hub = Hub()
    hub.discover()
    print(f"[hub] Discovered {len(hub.catalog)} tools across {len(SPOKE_REGISTRY)} registered spokes.")
