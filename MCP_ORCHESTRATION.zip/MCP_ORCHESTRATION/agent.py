"""
agent.py
----------
The command-line entry point for the whole system. Run this to start
a session (or resume an old one), then issue commands.

Usage:
    python agent.py

Commands once running:
    sessions                 - list saved sessions
    resume <session_id>      - resume a specific session
    new                      - start a fresh session
    tools                    - list every tool the hub discovered
    call <spoke> <tool> <json_params>
                              - directly invoke a spoke's tool
    cd <path>                - shortcut for filesystem_spoke.navigate
    ls [path]                - shortcut for filesystem_spoke.list_dir
    run <shell command>      - shortcut for shell_spoke.run_command
    ask <message>            - talk to the AI assistant (needs your own provider,
                               model and API key in .env - see .env.example)
    exit                     - quit
"""

import json
import shlex
import sys

import ai_agent
import config
from hub import Hub

config.load_env()


def _prompt_yes_no(question: str) -> bool:
    answer = input(f"{question} [y/N] ").strip().lower()
    return answer in ("y", "yes")


def main():
    hub = Hub()
    hub.discover()
    print(f"[agent] Discovered {len(hub.catalog)} tools.")

    sessions = __import__("session_manager").list_sessions()
    if sessions:
        print("[agent] Existing sessions found:")
        for s in sessions[:5]:
            print(f"    {s['session_id']}  (updated {s['updated_at']})")
        if _prompt_yes_no("Resume the most recent session?"):
            hub.start_session(resume=sessions[0]["session_id"])
        else:
            hub.start_session()
    else:
        hub.start_session()

    print("[agent] Ready. Type 'exit' to quit.\n")
    chat = ai_agent.Chat()

    while True:
        try:
            raw = input("agent> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not raw:
            continue

        if raw == "ask" or raw.startswith("ask "):
            question = raw[3:].strip()
            if not question:
                print("[agent] Usage: ask <message>")
                continue
            try:
                result = ai_agent.ask_blocking(
                    ai_agent.Agent(hub, ai_agent.AIConfig.from_env()), chat, question,
                    lambda tool, params: _prompt_yes_no(f"[agent] The AI wants to run {tool} {json.dumps(params)}. Allow?"),
                )
                for step in result["steps"]:
                    print(f"  -> {step['tool']} [{step['status']}]")
                print(result["reply"])
            except ai_agent.AIError as e:
                print(f"[agent] {e}")
            continue

        try:
            parts = shlex.split(raw)
        except ValueError as e:
            print(f"[agent] Could not parse that line: {e}")
            continue
        cmd, args = parts[0], parts[1:]

        try:
            if cmd == "exit":
                break

            elif cmd == "sessions":
                for s in __import__("session_manager").list_sessions():
                    print(f"  {s['session_id']}  (updated {s['updated_at']})")

            elif cmd == "resume":
                hub.start_session(resume=args[0])

            elif cmd == "new":
                hub.start_session()

            elif cmd == "tools":
                for name, info in sorted(hub.catalog.items()):
                    print(f"  {name:20s} [{info['spoke']}]  {info['description']}")

            elif cmd == "call":
                spoke_name, tool = args[0], args[1]
                params = json.loads(args[2]) if len(args) > 2 else {}
                result = hub.call(spoke_name, tool, params)
                print(json.dumps(result, indent=2))

            elif cmd == "cd":
                result = hub.route("navigate", {"path": args[0]})
                print(json.dumps(result, indent=2))

            elif cmd == "ls":
                path = args[0] if args else None
                result = hub.route("list_dir", {"path": path} if path else {})
                print(json.dumps(result, indent=2))

            elif cmd == "run":
                command = " ".join(args)
                result = hub.route("run_command", {"command": command})
                print(json.dumps(result, indent=2))

            elif cmd == "maketool":
                # maketool <name> <port> <purpose...>
                name, port = args[0], int(args[1])
                purpose = " ".join(args[2:])
                if _prompt_yes_no(f"No existing tool for '{purpose}'. Create a new spoke for this?"):
                    result = hub.offer_to_create_tool(name, purpose, port, confirmed=True)
                    print(json.dumps(result, indent=2))
                else:
                    print("[agent] Skipped.")

            else:
                print(f"[agent] Unknown command: {cmd}")

        except LookupError as e:
            # Raised by hub.route() when no spoke has the requested tool.
            print(f"[agent] {e}")
            if _prompt_yes_no("Would you like me to scaffold a new tool for this?"):
                print("[agent] Use: maketool <name> <port> <purpose>")

        except Exception as e:
            print(f"[agent] Error: {type(e).__name__}: {e}")


if __name__ == "__main__":
    sys.exit(main())
