# USAGE GUIDE — MCP Orchestration System

How to install, run, and actually use the hub-and-spoke system.

## What this system actually does

It is a control panel for running tasks from one place. Nine small helper programs (spokes) each do one job (shell commands, files, Python code, database, web requests, GitHub, and more). A central hub routes each request to the right spoke, logs it, and saves your session so you can resume later. You drive it from a web page, a terminal, an optional AI assistant, or any MCP client.

The hub works with no AI at all: you choose the tool and give it the input. The optional AI assistant can choose and run tools for you using **your own model and API key**.

## You choose your own model and API key (optional)

No keys, accounts or default model are included. For the AI assistant, pick a provider (Anthropic, OpenAI, or any OpenAI-compatible service via a Base URL), paste your own key and choose your model, either in the web UI's AI panel or in `.env` (`AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL`), then run `python check_ai.py` to confirm it works. For the GitHub spoke, create your own GitHub token and put it in `.env` as `GITHUB_TOKEN`. Keep keys in `.env` only, never commit or share them, and remember that usage and cost on your keys is your responsibility. See README.md section 6 for details.

## Logins and secrets

Three secrets are created automatically on first run and kept owner-only: the hub access token (`.hub_token`, for the web UI/API), the spoke shared secret (`.spoke_secret`, so only the hub can use the spokes) and the vault key (`.vault_key`, which encrypts saved credentials, sessions and chats). `python run_all.py` opens the browser already signed in; if you open the page yourself, paste the hub token when asked. Back up your vault key. See README.md.

## 1. Setup

```bash
cd MCP_ORCHESTRATION
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # fill in GITHUB_TOKEN if you'll use the github spoke
```

## 2. Start the spokes

**Easiest:** run `python run_all.py` — it starts every spoke below plus the web UI in one go. The manual way is below.

Each spoke is its own process on its own port. Open one terminal per spoke (or write a
process-manager script later — not included yet):

```bash
uvicorn tools.rest_api_server:app     --port 8001
uvicorn tools.database_server:app     --port 8002
uvicorn tools.code_exec_server:app    --port 8003
uvicorn tools.github_server:app       --port 8004
uvicorn tools.cursor_server:app       --port 8005
uvicorn tools.toolmaker_server:app    --port 8006
uvicorn tools.filesystem_server:app   --port 8007
uvicorn tools.crud_files_server:app   --port 8008
uvicorn tools.shell_server:app        --port 8009
```

You only need to start the spokes a given session actually uses — the hub just logs a
warning for any spoke it can't reach at startup, it won't crash.

## 3a. Or use the web UI instead of the CLI

There's now a browser control panel that talks to the hub over HTTP, so you don't
have to use the terminal for everyday calls. It lives at [`web/index.html`](web/index.html)
and is served by [`hub_api.py`](hub_api.py).

```bash
uvicorn hub_api:app --port 8000
```

Then open **http://127.0.0.1:8000** in a browser (paste the access token from `.hub_token` when asked; `run_all.py` does this for you). You'll see:

- **Spoke Wheel** — a live diagram of the hub with every registered spoke around it.
  A spoke lights up teal when reachable, red/dim when it isn't, and the line to it
  pulses gold for a moment whenever you call one of its tools.
- **Tool Catalog** — every tool the hub discovered, grouped by spoke, searchable.
  Click a tool to load it into the console below.
- **Console** — pick a tool (or type a spoke/tool/params combo directly) and hit
  Run. Results print below.
- **Audit Log** — a live tail of `audit.log`, refreshing automatically.

Hit **Refresh** any time after starting more spoke servers — it re-runs discovery
without needing to reload the page.

The web UI and the CLI (`agent.py`) both drive the same underlying `hub.py`, so a
session started in one is visible from the other (they share `mcp_data.db`).

## 3b. Or use the terminal agent

```bash
python agent.py
```

On startup it discovers every reachable spoke's tools, then asks if you want to resume
your most recent session or start fresh.

## 4. Commands

| Command | What it does |
|---|---|
| `sessions` | List all saved sessions with their last-updated time |
| `resume <session_id>` | Resume a specific past session |
| `new` | Start a brand-new session |
| `tools` | List every tool the hub discovered, grouped by spoke |
| `call <spoke> <tool> <json_params>` | Directly invoke any spoke's tool |
| `cd <path>` | Shortcut for filesystem navigate |
| `ls [path]` | Shortcut for filesystem list_dir |
| `run <command>` | Shortcut for shell run_command |
| `maketool <name> <port> <purpose...>` | Scaffold a new spoke via Tool Maker |
| `exit` | Quit |

### Examples

```
agent> ls
agent> cd Documents/projects
agent> call crud_files create_file {"path": "notes.txt", "content": "hello"}
agent> call database query {"sql": "SELECT * FROM sessions"}
agent> run echo hello world
```

### When no tool exists for what you want

If you call `route()` (or use a shortcut) for a tool the hub doesn't know about, it
raises and the agent asks if you'd like to scaffold one:

```
agent> call weather get_forecast {"city": "Bamenda"}
[agent] No spoke has a tool named 'get_forecast'. ...
Would you like me to scaffold a new tool for this? [y/N] y
[agent] Use: maketool <name> <port> <purpose>
agent> maketool weather 8100 fetch weather forecasts
```

This creates `tools/weather_server.py` with a working skeleton (manifest + one
example tool). You then:
1. Fill in the TODOs in the new file with real logic.
2. Add `"weather": "http://127.0.0.1:8100"` to `SPOKE_REGISTRY` in `hub.py`.
3. Start it: `uvicorn tools.weather_server:app --port 8100`.
4. Restart the agent so it re-discovers the new spoke.

## 5. Credentials

When a task needs an account/API token for some service, use
`hub.get_or_create_credential(service, create_fn=...)`:

- If a credential for that service is already saved, it's returned immediately.
- If not, and you pass a `create_fn` (a function that creates the account and returns
  `(username, secret)`), the hub calls it, saves the result, and returns it.
- If no `create_fn` is given and nothing is saved, it raises so you can prompt the
  user for what to do.

**Read the security note at the top of `credential_vault.py` before relying on this
for anything beyond local development** — secrets are only base64-obfuscated, not
encrypted.

## 6. Connectors

`connectors.py` handles linking a task to something outside the spoke system:

```python
from connectors import open_in_browser, open_in_vscode, pipe

open_in_browser("https://github.com")
open_in_vscode("/home/you/projects/my_repo")

# feed one spoke's output into another spoke's tool
pipe(hub, "filesystem", "search", {"query": "*.py"}, "crud_files", "read_file", "path")
```

## 7. Running tests

```bash
pytest tests/ -v
```

## 8. The audit log

Every call routed through `hub.call()` is appended as a JSON line to `audit.log` —
timestamp, session, spoke, tool, params, and status. This is the main control on the
shell and CRUD spokes: nothing runs through the hub without a record of it.

## 4. AI assistant and MCP server

- **AI assistant:** configure it in the web UI's AI panel (or `.env`), then chat in the panel or use `ask <message>` in `agent.py`. Commands, code, file reads/writes and SQL always ask for your approval first.
- **MCP server:** run `python run_all.py --spokes-only`, then point any MCP client at `python /full/path/to/mcp_server.py` (add `--safe` to hide risky tools).

Full instructions are in README.md sections 6 and 7.
