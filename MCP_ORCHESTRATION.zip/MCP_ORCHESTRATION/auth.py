"""
auth.py
---------
Two secrets, both created automatically on first run and kept owner-only:

1. The hub API access token. Anything that can reach the hub's web port could
   otherwise run shell commands, so every /api/* request must carry
       Authorization: Bearer <token>
   Source, in order: HUB_API_TOKEN (env / .env), then the .hub_token file.

2. The spoke shared secret. Every spoke requires it (X-Spoke-Key header) on
   /manifest and /invoke, so other programs on your machine cannot call the
   shell or file spokes directly on their ports. Only the hub knows it.
   Source, in order: SPOKE_SECRET (env / .env), then the .spoke_secret file.

The web UI is opened by run_all.py already carrying the hub token; if you open
it yourself it will ask you to paste the token once.
"""

from __future__ import annotations

import hmac
import os
import secrets
import time
from pathlib import Path

import config

TOKEN_FILE = config.data_dir() / ".hub_token"
SPOKE_SECRET_FILE = config.data_dir() / ".spoke_secret"


def _read_or_create(path: Path) -> str:
    """Atomically create the file with a fresh secret, or read the one already there.
    Safe when several processes (all the spokes) start at the same moment."""
    for _ in range(50):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            existing = path.read_text().strip()
            if existing:
                return existing
            time.sleep(0.1)
            continue
        value = secrets.token_urlsafe(32)
        with os.fdopen(fd, "w") as f:
            f.write(value)
        return value
    raise RuntimeError(f"Could not read or create {path}")


def get_or_create_token() -> str:
    env_token = os.environ.get("HUB_API_TOKEN", "").strip()
    return env_token or _read_or_create(TOKEN_FILE)


def get_or_create_spoke_secret() -> str:
    env_secret = os.environ.get("SPOKE_SECRET", "").strip()
    return env_secret or _read_or_create(SPOKE_SECRET_FILE)


def token_matches(provided: str | None, expected: str | None) -> bool:
    if not provided or not expected:
        return False
    return hmac.compare_digest(provided.encode(), expected.encode())
