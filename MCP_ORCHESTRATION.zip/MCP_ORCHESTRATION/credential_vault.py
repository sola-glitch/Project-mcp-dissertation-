"""
credential_vault.py
----------------------
Stores credentials a task needs (e.g. an API token for a service) so
the hub can either use an existing one or create+save a new one.

Secrets are encrypted with Fernet (see crypto.py) before they are written to
the 'credentials' table. Older entries saved with the previous base64 scheme
are still readable and are re-encrypted the first time they are read.
The key comes from VAULT_KEY or a .vault_key file, never from the database.
"""

from __future__ import annotations

import base64
import binascii
from datetime import datetime, timezone
from pathlib import Path
from sqlalchemy import create_engine, text, MetaData, Table, Column, String, Text

import config
import crypto

DB_PATH = config.data_dir() / "mcp_data.db"
engine = create_engine(f"sqlite:///{DB_PATH}", future=True)

# Created here too (not just in tools/database_server.py) so this module
# works standalone regardless of which spokes have been started/imported.
_metadata = MetaData()
_credentials_table = Table(
    "credentials", _metadata,
    Column("service", String, primary_key=True),
    Column("username", String),
    Column("secret", Text),
    Column("created_at", String),
)
_metadata.create_all(engine)


def _decode_legacy(blob: str) -> str:
    """Entries from before encryption were plain base64."""
    try:
        return base64.b64decode(blob.encode(), validate=True).decode()
    except (binascii.Error, UnicodeDecodeError) as e:
        raise crypto.CryptoError("Stored credential is in an unknown format.") from e


def get_credential(service: str) -> dict | None:
    """Look up a stored credential. Returns None if the hub needs to prompt for/create one."""
    with engine.connect() as conn:
        row = conn.execute(
            text("SELECT username, secret FROM credentials WHERE service = :s"),
            {"s": service},
        ).fetchone()
    if not row:
        return None
    if crypto.is_encrypted(row[1]):
        secret = crypto.decrypt(row[1])
    else:  # legacy base64 entry: read it, then upgrade it to real encryption
        secret = _decode_legacy(row[1])
        save_credential(service, row[0], secret)
    return {"service": service, "username": row[0], "secret": secret}


def save_credential(service: str, username: str, secret: str) -> None:
    now = datetime.now(timezone.utc).isoformat()
    with engine.begin() as conn:
        conn.execute(
            text("""
                INSERT INTO credentials (service, username, secret, created_at)
                VALUES (:svc, :user, :secret, :now)
                ON CONFLICT(service) DO UPDATE SET username=:user, secret=:secret
            """),
            {"svc": service, "user": username, "secret": crypto.encrypt(secret), "now": now},
        )


def ensure_credential(service: str, create_fn=None) -> dict:
    """
    The hub's main entry point: if a credential for `service` exists, return it.
    If not, and a create_fn(service) -> (username, secret) was provided, call it,
    save the result, and return it — this is the "creates the account and saves
    the details" path. If no create_fn is given, raises so the caller can prompt
    the user instead.
    """
    existing = get_credential(service)
    if existing:
        return existing
    if create_fn is None:
        raise LookupError(f"No credential for '{service}' and no create_fn provided — prompt the user.")
    username, secret = create_fn(service)
    save_credential(service, username, secret)
    return {"service": service, "username": username, "secret": secret}
