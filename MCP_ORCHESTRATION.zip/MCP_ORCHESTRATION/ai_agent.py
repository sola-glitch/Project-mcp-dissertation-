"""
ai_agent.py
-------------
An optional AI assistant that can use the hub's tools. It is provider-agnostic
and "bring your own key": nothing here is tied to one vendor, and no key or
model name ships with the project.

Supported providers (chosen by the user):
    anthropic  - Anthropic Messages API
    openai     - any OpenAI-compatible Chat Completions API. Set a base URL to
                 use another service (Gemini, Groq, OpenRouter, a local Ollama
                 or LM Studio server, ...).

Configuration comes from .env (AI_PROVIDER, AI_API_KEY, AI_MODEL, AI_BASE_URL)
or from the web UI's AI panel. Keys entered in the UI live in memory only.

Safety: tools listed in hub.APPROVAL_REQUIRED (shell, run code, read/write/delete
files, SQL, outbound HTTP, ...) are never run until the user approves
that specific call. Every call the assistant makes is written to audit.log
with source "ai".
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Iterator

import httpx

from hub import APPROVAL_REQUIRED, Hub

NO_RESPONSE = "(no response)"
MAX_ROUNDS = 8            # max model <-> tool round trips per user message
MAX_TOOL_RESULT_CHARS = 8000
REQUEST_TIMEOUT = 120

DEFAULT_BASE_URLS = {
    "anthropic": "https://api.anthropic.com",
    "openai": "https://api.openai.com/v1",
}

SYSTEM_PROMPT = (
    "You are an assistant connected to a local tool hub. Use the provided tools "
    "to carry out the user's request on their machine. Prefer read-only tools "
    "first. Some tools (running commands or code, reading, writing or deleting "
    "files, SQL, outbound HTTP) need the user's approval before they run; if a "
    "call is denied, do not retry it, explain what you could not do instead. "
    "Keep answers short and report what the tools actually returned."
)


class AIError(Exception):
    """A problem talking to the AI provider (bad key, bad model, network...)."""


def _client() -> httpx.Client:
    """Factory for the HTTP client (tests replace this with a mock transport)."""
    return httpx.Client(timeout=REQUEST_TIMEOUT)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class AIConfig:
    provider: str = ""      # "anthropic" | "openai"
    api_key: str = ""
    model: str = ""
    base_url: str = ""

    @classmethod
    def from_env(cls) -> "AIConfig":
        provider = os.environ.get("AI_PROVIDER", "").strip().lower()
        key = os.environ.get("AI_API_KEY", "").strip()
        if not key and provider == "anthropic":
            key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        if not key and provider == "openai":
            key = os.environ.get("OPENAI_API_KEY", "").strip()
        return cls(
            provider=provider,
            api_key=key,
            model=os.environ.get("AI_MODEL", "").strip(),
            base_url=os.environ.get("AI_BASE_URL", "").strip(),
        )

    def effective_base_url(self) -> str:
        return (self.base_url or DEFAULT_BASE_URLS.get(self.provider, "")).rstrip("/")

    def problem(self, need_model: bool = True) -> str | None:
        """Human-readable description of what is missing, or None if usable."""
        if self.provider not in DEFAULT_BASE_URLS:
            return "Choose a provider (anthropic or openai)."
        local_server = self.provider == "openai" and bool(self.base_url)
        if not self.api_key and not local_server:
            return "Add your own API key for this provider."
        if need_model and not self.model:
            return "Choose a model."
        return None

    def public(self) -> dict:
        """Safe to send to the browser: never includes the key itself."""
        return {
            "provider": self.provider,
            "model": self.model,
            "base_url": self.base_url,
            "has_key": bool(self.api_key),
            "configured": self.problem() is None,
        }


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------

@dataclass
class ToolCall:
    id: str
    name: str
    args: dict
    error: str | None = None   # set when the model sent unparseable arguments


@dataclass
class Turn:
    message: dict               # assistant message in the provider's own format
    text: str
    tool_calls: list[ToolCall]


def _raise_for_provider_error(resp: httpx.Response) -> None:
    if resp.status_code < 400:
        return
    detail = ""
    try:
        body = resp.json()
        err = body.get("error", body)
        detail = err.get("message", "") if isinstance(err, dict) else str(err)
    except Exception:
        detail = resp.text[:200]
    hint = ""
    if resp.status_code in (401, 403):
        hint = " (check your API key)"
    elif resp.status_code == 404:
        hint = " (check the model name and base URL)"
    raise AIError(f"Provider returned {resp.status_code}{hint}: {detail}".strip())


def _sse_events(resp: httpx.Response) -> Iterator[dict]:
    """Yield the JSON payload of each `data:` line of a Server-Sent-Events response."""
    for line in resp.iter_lines():
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            yield json.loads(payload)
        except json.JSONDecodeError:
            continue


def _open_stream(client: httpx.Client, url: str, headers: dict, body: dict):
    """Context manager for a streaming POST that turns provider errors into AIError."""
    class _Ctx:
        def __enter__(self_inner):
            try:
                self_inner.cm = client.stream("POST", url, headers=headers, json=body)
                self_inner.resp = self_inner.cm.__enter__()
            except httpx.HTTPError as e:
                raise AIError(f"Could not reach the provider: {type(e).__name__}") from e
            if self_inner.resp.status_code >= 400:
                self_inner.resp.read()
                try:
                    _raise_for_provider_error(self_inner.resp)
                finally:
                    self_inner.cm.__exit__(None, None, None)
            return self_inner.resp

        def __exit__(self_inner, *exc):
            return self_inner.cm.__exit__(*exc)
    return _Ctx()


def _parse_tool_args(raw: str) -> tuple[dict, str | None]:
    try:
        args = json.loads(raw or "{}")
    except json.JSONDecodeError:
        return {}, "Arguments were not valid JSON."
    if not isinstance(args, dict):
        return {}, "Arguments must be a JSON object."
    return args, None


def _openai_turn(text: str, raw_calls: list[tuple[str, str, str]]) -> Turn:
    """Build a Turn from (id, name, arguments-json-string) triples."""
    calls: list[ToolCall] = []
    stored = []
    for call_id, name, raw in raw_calls:
        call_id = call_id or f"call_{uuid.uuid4().hex[:12]}"
        args, err = _parse_tool_args(raw)
        calls.append(ToolCall(id=call_id, name=name, args=args, error=err))
        stored.append({"id": call_id, "type": "function", "function": {"name": name, "arguments": raw or "{}"}})
    assistant: dict[str, Any] = {"role": "assistant", "content": text or ""}
    if stored:
        assistant["tool_calls"] = stored
    return Turn(assistant, (text or "").strip(), calls)


class AnthropicProvider:
    def __init__(self, cfg: AIConfig):
        self.cfg = cfg

    def _headers(self) -> dict:
        return {
            "x-api-key": self.cfg.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

    def list_models(self) -> list[str]:
        with _client() as c:
            resp = c.get(f"{self.cfg.effective_base_url()}/v1/models", headers=self._headers(), params={"limit": 100})
        _raise_for_provider_error(resp)
        return sorted(m["id"] for m in resp.json().get("data", []))

    def complete(self, system: str, messages: list[dict], tools: list[dict]) -> Turn:
        body: dict[str, Any] = {
            "model": self.cfg.model,
            "max_tokens": 4096,
            "system": system,
            "messages": messages,
        }
        if tools:
            body["tools"] = [
                {"name": t["name"], "description": t["description"], "input_schema": t["schema"]} for t in tools
            ]
        with _client() as c:
            try:
                resp = c.post(f"{self.cfg.effective_base_url()}/v1/messages", headers=self._headers(), json=body)
            except httpx.HTTPError as e:
                raise AIError(f"Could not reach the provider: {type(e).__name__}") from e
        _raise_for_provider_error(resp)
        data = resp.json()

        blocks, text_parts, calls = [], [], []
        for b in data.get("content", []):
            if b.get("type") == "text":
                blocks.append({"type": "text", "text": b.get("text", "")})
                text_parts.append(b.get("text", ""))
            elif b.get("type") == "tool_use":
                blocks.append({"type": "tool_use", "id": b["id"], "name": b["name"], "input": b.get("input", {})})
                calls.append(ToolCall(id=b["id"], name=b["name"], args=b.get("input") or {}))
        return Turn({"role": "assistant", "content": blocks or [{"type": "text", "text": NO_RESPONSE}]}, "\n".join(text_parts).strip(), calls)

    def stream(self, system: str, messages: list[dict], tools: list[dict]) -> Iterator[tuple[str, Any]]:
        """Yield ("text", delta) as it arrives, then ("turn", Turn)."""
        body: dict[str, Any] = {"model": self.cfg.model, "max_tokens": 4096, "system": system,
                                "messages": messages, "stream": True}
        if tools:
            body["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["schema"]} for t in tools]
        blocks: dict[int, dict] = {}
        with _client() as c, _open_stream(c, f"{self.cfg.effective_base_url()}/v1/messages", self._headers(), body) as resp:
            try:
                for ev in _sse_events(resp):
                    kind = ev.get("type")
                    if kind == "content_block_start":
                        cb = ev.get("content_block", {})
                        blocks[ev["index"]] = {"type": cb.get("type"), "text": cb.get("text", ""),
                                               "id": cb.get("id"), "name": cb.get("name"), "json": ""}
                        if cb.get("text"):
                            yield ("text", cb["text"])
                    elif kind == "content_block_delta":
                        delta, block = ev.get("delta", {}), blocks.get(ev.get("index"))
                        if block is None:
                            continue
                        if delta.get("type") == "text_delta":
                            block["text"] += delta.get("text", "")
                            yield ("text", delta.get("text", ""))
                        elif delta.get("type") == "input_json_delta":
                            block["json"] += delta.get("partial_json", "")
                    elif kind == "error":
                        raise AIError("Provider error: " + str(ev.get("error", {}).get("message", "stream error")))
            except httpx.HTTPError as e:
                raise AIError(f"The connection to the provider dropped: {type(e).__name__}") from e

        content, texts, calls = [], [], []
        for _, b in sorted(blocks.items()):
            if b["type"] == "text" and b["text"]:
                content.append({"type": "text", "text": b["text"]})
                texts.append(b["text"])
            elif b["type"] == "tool_use":
                args, err = _parse_tool_args(b["json"])
                content.append({"type": "tool_use", "id": b["id"], "name": b["name"], "input": args})
                calls.append(ToolCall(id=b["id"], name=b["name"], args=args, error=err))
        yield ("turn", Turn({"role": "assistant", "content": content or [{"type": "text", "text": NO_RESPONSE}]},
                            "\n".join(texts).strip(), calls))

    def tool_result_messages(self, results: list[tuple[ToolCall, str, bool]]) -> list[dict]:
        content = []
        for call, text, is_error in results:
            block = {"type": "tool_result", "tool_use_id": call.id, "content": text}
            if is_error:
                block["is_error"] = True
            content.append(block)
        return [{"role": "user", "content": content}]


class OpenAIProvider:
    def __init__(self, cfg: AIConfig):
        self.cfg = cfg

    def _headers(self) -> dict:
        h = {"content-type": "application/json"}
        if self.cfg.api_key:
            h["authorization"] = f"Bearer {self.cfg.api_key}"
        return h

    def list_models(self) -> list[str]:
        with _client() as c:
            resp = c.get(f"{self.cfg.effective_base_url()}/models", headers=self._headers())
        _raise_for_provider_error(resp)
        return sorted(m["id"] for m in resp.json().get("data", []))

    def complete(self, system: str, messages: list[dict], tools: list[dict]) -> Turn:
        body: dict[str, Any] = {
            "model": self.cfg.model,
            "messages": [{"role": "system", "content": system}] + messages,
        }
        if tools:
            body["tools"] = [
                {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["schema"]}}
                for t in tools
            ]
        with _client() as c:
            try:
                resp = c.post(f"{self.cfg.effective_base_url()}/chat/completions", headers=self._headers(), json=body)
            except httpx.HTTPError as e:
                raise AIError(f"Could not reach the provider: {type(e).__name__}") from e
        _raise_for_provider_error(resp)
        data = resp.json()
        try:
            msg = data["choices"][0]["message"]
        except (KeyError, IndexError):
            raise AIError("Provider returned an unexpected response.")

        raw = [(tc.get("id") or "", tc.get("function", {}).get("name", ""), tc.get("function", {}).get("arguments") or "{}")
               for tc in msg.get("tool_calls") or []]
        return _openai_turn(msg.get("content") or "", raw)

    def stream(self, system: str, messages: list[dict], tools: list[dict]) -> Iterator[tuple[str, Any]]:
        """Yield ("text", delta) as it arrives, then ("turn", Turn)."""
        body: dict[str, Any] = {"model": self.cfg.model, "stream": True,
                                "messages": [{"role": "system", "content": system}] + messages}
        if tools:
            body["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                               "parameters": t["schema"]}} for t in tools]
        text = ""
        slots: dict[int, dict] = {}
        with _client() as c, _open_stream(c, f"{self.cfg.effective_base_url()}/chat/completions", self._headers(), body) as resp:
            try:
                for ev in _sse_events(resp):
                    for choice in ev.get("choices") or []:
                        delta = choice.get("delta") or {}
                        if delta.get("content"):
                            text += delta["content"]
                            yield ("text", delta["content"])
                        for tc in delta.get("tool_calls") or []:
                            slot = slots.setdefault(tc.get("index", 0), {"id": "", "name": "", "args": ""})
                            if tc.get("id"):
                                slot["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name") and not slot["name"]:
                                slot["name"] = fn["name"]
                            if fn.get("arguments"):
                                slot["args"] += fn["arguments"]
            except httpx.HTTPError as e:
                raise AIError(f"The connection to the provider dropped: {type(e).__name__}") from e
        yield ("turn", _openai_turn(text, [(v["id"], v["name"], v["args"]) for _, v in sorted(slots.items())]))

    def tool_result_messages(self, results: list[tuple[ToolCall, str, bool]]) -> list[dict]:
        return [{"role": "tool", "tool_call_id": call.id, "content": text} for call, text, _ in results]


def make_provider(cfg: AIConfig):
    if cfg.provider == "anthropic":
        return AnthropicProvider(cfg)
    if cfg.provider == "openai":
        return OpenAIProvider(cfg)
    raise AIError("Choose a provider (anthropic or openai).")


def list_models(cfg: AIConfig) -> list[str]:
    problem = cfg.problem(need_model=False)
    if problem:
        raise AIError(problem)
    try:
        return make_provider(cfg).list_models()
    except httpx.HTTPError as e:
        raise AIError(f"Could not reach the provider: {type(e).__name__}") from e


# ---------------------------------------------------------------------------
# The agent loop
# ---------------------------------------------------------------------------

@dataclass
class Chat:
    messages: list[dict] = field(default_factory=list)
    pending: list[ToolCall] | None = None        # tool calls from the last model turn
    results: dict[str, tuple[str, bool]] = field(default_factory=dict)
    decisions: dict[str, bool] = field(default_factory=dict)  # approval per call id
    steps: list[dict] = field(default_factory=list)           # new since last yielded
    turn_text: str = ""

    # -- saving / loading (chats survive a restart; see chat_store.py) --------
    def to_dict(self) -> dict:
        return {
            "messages": self.messages,
            "pending": None if self.pending is None else [asdict(c) for c in self.pending],
            "results": {k: [v[0], v[1]] for k, v in self.results.items()},
            "decisions": self.decisions,
            "turn_text": self.turn_text,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Chat":
        pending = data.get("pending")
        return cls(
            messages=data.get("messages", []),
            pending=None if pending is None else [ToolCall(**c) for c in pending],
            results={k: (v[0], bool(v[1])) for k, v in data.get("results", {}).items()},
            decisions={k: bool(v) for k, v in data.get("decisions", {}).items()},
            turn_text=data.get("turn_text", ""),
        )

    def title(self) -> str:
        for m in self.messages:
            if m.get("role") == "user" and isinstance(m.get("content"), str):
                return m["content"].strip().replace("\n", " ")[:60] or "(empty)"
        return "New chat"

    def transcript(self) -> list[dict]:
        """What to show when a saved chat is reopened: user text, assistant text, tool steps."""
        out: list[dict] = []
        for m in self.messages:
            role, content = m.get("role"), m.get("content")
            if role == "user" and isinstance(content, str):
                out.append({"role": "user", "text": content})
            elif role == "assistant":
                if isinstance(content, str):
                    if content.strip():
                        out.append({"role": "assistant", "text": content})
                    for tc in m.get("tool_calls") or []:
                        out.append({"role": "step", "text": "-> " + tc["function"]["name"]})
                else:
                    for block in content or []:
                        if block.get("type") == "text" and block.get("text", "").strip() \
                                and block["text"] != NO_RESPONSE:
                            out.append({"role": "assistant", "text": block["text"]})
                        elif block.get("type") == "tool_use":
                            out.append({"role": "step", "text": "-> " + block["name"]})
        return out

    def awaiting(self) -> list[dict]:
        """Calls still waiting for the user's Allow/Deny."""
        return [
            {"id": c.id, "tool": c.name, "params": c.args}
            for c in (self.pending or [])
            if c.id not in self.results and c.name in APPROVAL_REQUIRED and c.id not in self.decisions and not c.error
        ]


class Agent:
    def __init__(self, hub: Hub, cfg: AIConfig):
        self.hub = hub
        self.cfg = cfg

    # -- public API -----------------------------------------------------------

    def send(self, chat: Chat, text: str) -> dict:
        return self._collect(self._start(chat, text, stream=False))

    def resume(self, chat: Chat, decisions: dict[str, bool]) -> dict:
        return self._collect(self._resume(chat, decisions, stream=False))

    def send_stream(self, chat: Chat, text: str) -> Iterator[dict]:
        """Like send(), but yields events as they happen: text deltas, steps, then
        a final {"type": "done"} or {"type": "needs_approval"}."""
        return self._start(chat, text, stream=True)

    def resume_stream(self, chat: Chat, decisions: dict[str, bool]) -> Iterator[dict]:
        return self._resume(chat, decisions, stream=True)

    # -- entry points as generators ------------------------------------------------

    def _start(self, chat: Chat, text: str, stream: bool) -> Iterator[dict]:
        problem = self.cfg.problem()
        if problem:
            raise AIError(f"AI is not configured: {problem}")
        if chat.pending:  # a new message while waiting for approval: deny what was pending
            for c in chat.pending:
                chat.decisions.setdefault(c.id, False)
            self._resolve_pending(chat)
            yield from self._drain_steps(chat)
        chat.messages.append({"role": "user", "content": text})
        yield from self._events(chat, stream)

    def _resume(self, chat: Chat, decisions: dict[str, bool], stream: bool) -> Iterator[dict]:
        if not chat.pending:
            raise AIError("Nothing is waiting for approval.")
        chat.decisions.update({k: bool(v) for k, v in decisions.items()})
        yield from self._events(chat, stream)

    @staticmethod
    def _collect(events: Iterator[dict]) -> dict:
        steps, final = [], None
        for ev in events:
            if ev["type"] == "step":
                steps.append({k: v for k, v in ev.items() if k != "type"})
            elif ev["type"] in ("done", "needs_approval"):
                final = ev
        out = {k: v for k, v in final.items() if k != "type"}
        return {"status": final["type"], "steps": steps, **out}

    @staticmethod
    def _drain_steps(chat: Chat) -> Iterator[dict]:
        for step in chat.steps:
            yield {"type": "step", **step}
        chat.steps = []

    # -- internals --------------------------------------------------------------

    def _tool_specs(self) -> list[dict]:
        if not self.hub.catalog:
            self.hub.discover()
        specs = []
        for name, info in sorted(self.hub.catalog.items()):
            desc = info["description"]
            if name in APPROVAL_REQUIRED:
                desc += " (Needs the user's approval before it runs.)"
            specs.append({
                "name": name,
                "description": desc,
                "schema": info.get("input_schema") or {"type": "object", "properties": {}},
            })
        return specs

    def _execute(self, call: ToolCall) -> tuple[str, bool]:
        if call.error:
            return f"Invalid tool call: {call.error}", True
        try:
            result = self.hub.route(call.name, call.args, source="ai")
        except LookupError:
            return f"No tool named '{call.name}' is available.", True
        except Exception as e:
            return f"{type(e).__name__}: {e}", True
        is_error = isinstance(result, dict) and result.get("status") == "error"
        text = json.dumps(result, default=str)
        if len(text) > MAX_TOOL_RESULT_CHARS:
            text = text[:MAX_TOOL_RESULT_CHARS] + " ...[truncated]"
        return text, is_error

    def _log(self, chat: Chat, call: ToolCall, status: str, text: str) -> None:
        chat.steps.append({"tool": call.name, "params": call.args, "status": status, "preview": text[:300]})

    def _resolve_pending(self, chat: Chat) -> list[ToolCall]:
        """Run/deny what can be decided. Returns calls still waiting for approval."""
        waiting: list[ToolCall] = []
        for call in chat.pending or []:
            if call.id in chat.results:
                continue
            if call.name in APPROVAL_REQUIRED and not call.error:
                decision = chat.decisions.get(call.id)
                if decision is None:
                    waiting.append(call)
                    continue
                if decision is False:
                    chat.results[call.id] = ("The user denied this call. Do not retry it.", True)
                    self._log(chat, call, "denied", "denied by user")
                    continue
            text, is_error = self._execute(call)
            chat.results[call.id] = (text, is_error)
            self._log(chat, call, "error" if is_error else "ok", text)
        if not waiting and chat.pending:
            ordered = [(c, *chat.results[c.id]) for c in chat.pending]
            chat.messages.extend(make_provider(self.cfg).tool_result_messages(ordered))
            chat.pending, chat.results, chat.decisions = None, {}, {}
        return waiting

    def _model_turn(self, provider, chat: Chat, stream: bool) -> Iterator[Any]:
        """Run one model call. Yields text events (streaming only); the last item is the Turn."""
        specs = self._tool_specs()
        try:
            if stream:
                for kind, value in provider.stream(SYSTEM_PROMPT, chat.messages, specs):
                    if kind == "text":
                        yield {"type": "text", "delta": value}
                    else:
                        yield value
            else:
                yield provider.complete(SYSTEM_PROMPT, chat.messages, specs)
        except AIError:
            last = chat.messages[-1] if chat.messages else {}
            if last.get("role") == "user" and isinstance(last.get("content"), str):
                chat.messages.pop()   # nothing ran yet: drop the message so a retry doesn't duplicate it
            raise

    def _events(self, chat: Chat, stream: bool) -> Iterator[dict]:
        provider = make_provider(self.cfg)
        for _ in range(MAX_ROUNDS):
            if chat.pending is None:
                turn = None
                for item in self._model_turn(provider, chat, stream):
                    if isinstance(item, Turn):
                        turn = item
                    else:
                        yield item
                chat.messages.append(turn.message)
                if not turn.tool_calls:
                    yield {"type": "done", "reply": turn.text}
                    return
                chat.pending, chat.results, chat.turn_text = turn.tool_calls, {}, turn.text
            waiting = self._resolve_pending(chat)
            yield from self._drain_steps(chat)
            if waiting:
                yield {"type": "needs_approval", "text": chat.turn_text,
                       "pending": [{"id": c.id, "tool": c.name, "params": c.args} for c in waiting]}
                return
        yield {"type": "done", "reply": f"Stopped after {MAX_ROUNDS} tool rounds without a final answer."}


def ask_blocking(agent: Agent, chat: Chat, text: str, confirm: Callable[[str, dict], bool]) -> dict:
    """Terminal helper: send a message and ask `confirm(tool, params)` for each dangerous call."""
    result = agent.send(chat, text)
    steps = list(result["steps"])
    while result["status"] == "needs_approval":
        decisions = {p["id"]: confirm(p["tool"], p["params"]) for p in result["pending"]}
        result = agent.resume(chat, decisions)
        steps += result["steps"]
    result["steps"] = steps
    return result
