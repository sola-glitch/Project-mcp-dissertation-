"""
connectors.py
----------------
Links a task to something outside the spoke system: opening a browser
tab, opening a folder in VS Code, or handing off a task's output as
input to another spoke. This is the layer that makes multi-step,
multi-app workflows possible instead of every spoke being an island.
"""

from __future__ import annotations

import shutil
import subprocess
import webbrowser


def open_in_browser(url: str) -> dict:
    """Open a URL in the default browser (e.g. Chrome)."""
    webbrowser.open(url)
    return {"opened": url}


def open_in_vscode(path: str) -> dict:
    """Open a file or folder in VS Code via its `code` CLI."""
    cli = shutil.which("code")
    if not cli:
        raise RuntimeError("'code' CLI not found on PATH. In VS Code: Cmd/Ctrl+Shift+P -> 'Shell Command: Install code command'.")
    subprocess.Popen([cli, path])
    return {"opened_in_vscode": path}


def pipe(hub, from_spoke: str, from_tool: str, from_params: dict, to_spoke: str, to_tool: str, to_param_name: str, extra_params: dict | None = None):
    """
    Run one spoke's tool and feed its result into another spoke's tool as
    a named parameter — e.g. take filesystem_spoke.search results and
    hand them to crud_files_spoke.read_file one at a time, or take
    rest_api_spoke.http_request's body and hand it to database_spoke.execute.

    `hub` is the running Hub instance (see hub.py) so this can reuse its
    existing spoke-routing logic rather than duplicating HTTP calls here.
    """
    upstream_result = hub.call(from_spoke, from_tool, from_params)
    downstream_params = {to_param_name: upstream_result, **(extra_params or {})}
    return hub.call(to_spoke, to_tool, downstream_params)
