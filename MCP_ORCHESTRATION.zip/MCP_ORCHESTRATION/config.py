"""
config.py
-----------
Loads the project's .env file once so every entry point (run_all.py,
hub_api.py, agent.py, mcp_server.py) sees the same settings, and says where
the hub keeps its data.

HUB_DATA_DIR  where mcp_data.db, audit.log and the secret files live
              (default: the project folder). Used by the Docker setup so data
              survives container restarts.
"""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
_loaded = False


def load_env() -> None:
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        from dotenv import load_dotenv
        load_dotenv(ROOT / ".env")
    except ImportError:
        pass


def data_dir() -> Path:
    load_env()
    configured = os.environ.get("HUB_DATA_DIR", "").strip()
    path = Path(configured).expanduser() if configured else ROOT
    path.mkdir(parents=True, exist_ok=True)
    return path


def allowed_roots() -> list:
    """Folders the file spokes may touch. HUB_ALLOWED_ROOTS (separated by os.pathsep) or your home folder."""
    load_env()
    configured = os.environ.get("HUB_ALLOWED_ROOTS", "").strip()
    if configured:
        return [str(Path(p).expanduser()) for p in configured.split(os.pathsep) if p.strip()]
    return [str(Path.home())]
