"""
code_exec_server.py
---------------------
Runs a snippet of Python away from the hub's own process. Two modes:

  process (default)   A hardened subprocess:
                        - runs in its own empty temp folder, with `python -I`
                          (isolated mode: no user site-packages, no PYTHON* env vars)
                        - gets a CLEAN environment: your API keys, tokens and
                          secrets are NOT passed to it
                        - CPU time, memory and file-size limits (Linux/macOS)
                        - wall-clock timeout; its whole process group is killed
                        - output is written to size-limited files and cut to the last 5000 chars
                      It can still read any file you can read and use the network.
                      This stops accidents and casual abuse. It is NOT a security boundary.

  docker              Set CODE_EXEC_SANDBOX=docker. Each snippet runs in a throwaway
                      container: no network, read-only filesystem, no capabilities,
                      non-root, 256 MB RAM, 1 CPU, 64 processes. This is real isolation.
                      Needs Docker installed and the image pulled once:
                          docker pull python:3.12-slim
                      (set CODE_EXEC_DOCKER_IMAGE to use another image).
                      If Docker is selected but missing, the call fails; it never
                      quietly falls back to the weaker mode.

Run standalone:  uvicorn tools.code_exec_server:app --port 8003
"""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import uuid
from pathlib import Path

from tools._base import Spoke
from tools._server_factory import make_app

spoke = Spoke("code_exec_spoke", "Run a Python snippet in an isolated subprocess (or Docker container).")

TIMEOUT_SECONDS = 10
MAX_OUTPUT_CHARS = 5000
CPU_SECONDS = 10
MEMORY_LIMIT_MB = 512
MAX_FILE_MB = 10
DOCKER_START_GRACE_SECONDS = 20

# Runs inside the child process: applies resource limits, then runs the user's file.
# Done here (not with preexec_fn) because preexec_fn is unsafe in a multi-threaded server.
_BOOTSTRAP = """
import runpy, sys
try:
    import resource
    for name, value in (("RLIMIT_CPU", %(cpu)d), ("RLIMIT_AS", %(mem)d), ("RLIMIT_FSIZE", %(fsize)d), ("RLIMIT_CORE", 0)):
        try:
            resource.setrlimit(getattr(resource, name), (value, value))
        except (ValueError, OSError, AttributeError):
            pass
except ImportError:
    pass
script = sys.argv[1]
sys.argv = [script]
runpy.run_path(script, run_name="__main__")
"""


def _clean_env(workdir: str) -> dict:
    env = {
        "PATH": os.environ.get("PATH", ""),
        "HOME": workdir,
        "TMPDIR": workdir,
        "PYTHONIOENCODING": "utf-8",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
    }
    if os.name == "nt":
        env.update({"SYSTEMROOT": os.environ.get("SYSTEMROOT", ""), "TEMP": workdir, "TMP": workdir})
    return env


def _kill_group(proc: subprocess.Popen) -> None:
    try:
        if os.name == "posix":
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError, OSError):
        pass


def _tail(path: Path) -> str:
    data = path.read_bytes()[-MAX_OUTPUT_CHARS * 4:]
    return data.decode("utf-8", errors="replace")[-MAX_OUTPUT_CHARS:]


def _run_process(code: str) -> dict:
    with tempfile.TemporaryDirectory(prefix="sandbox-work-") as work, \
         tempfile.TemporaryDirectory(prefix="sandbox-out-") as outdir:
        script = Path(work) / "snippet.py"
        script.write_text(code, encoding="utf-8")
        out_path, err_path = Path(outdir) / "stdout", Path(outdir) / "stderr"
        bootstrap = _BOOTSTRAP % {
            "cpu": CPU_SECONDS, "mem": MEMORY_LIMIT_MB * 1024 * 1024, "fsize": MAX_FILE_MB * 1024 * 1024,
        }
        timed_out = False
        with open(out_path, "wb") as out, open(err_path, "wb") as err:
            proc = subprocess.Popen(
                [sys.executable, "-I", "-c", bootstrap, str(script)],
                cwd=work, env=_clean_env(work),
                stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                start_new_session=(os.name == "posix"),
            )
            try:
                proc.wait(timeout=TIMEOUT_SECONDS)
            except subprocess.TimeoutExpired:
                timed_out = True
            finally:
                _kill_group(proc)      # also cleans up anything the snippet left running
            proc.wait()
        stderr = _tail(err_path)
        if timed_out:
            stderr = (stderr + f"\nTimed out after {TIMEOUT_SECONDS}s").strip()
        return {
            "stdout": _tail(out_path),
            "stderr": stderr,
            "exit_code": -1 if timed_out else proc.returncode,
            "sandbox": "process",
        }


class _TailReader(threading.Thread):
    """Reads a pipe to the end but only keeps the last chunk, so huge output can't fill memory."""

    def __init__(self, stream):
        super().__init__(daemon=True)
        self.stream, self.tail = stream, b""

    def run(self):
        while True:
            chunk = self.stream.read(4096)
            if not chunk:
                return
            self.tail = (self.tail + chunk)[-MAX_OUTPUT_CHARS * 4:]

    def text(self) -> str:
        return self.tail.decode("utf-8", errors="replace")[-MAX_OUTPUT_CHARS:]


def _docker_command(docker: str, name: str, image: str) -> list:
    return [
        docker, "run", "--rm", "-i", "--name", name,
        "--network", "none",
        "--memory", "256m", "--memory-swap", "256m", "--cpus", "1", "--pids-limit", "64",
        "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=16m",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--user", "65534:65534",
        image, "python", "-I", "-",
    ]


def _run_docker(code: str) -> dict:
    docker = shutil.which("docker")
    if not docker:
        return {"stdout": "", "stderr": "CODE_EXEC_SANDBOX=docker but the 'docker' command was not found. "
                "Install Docker, or unset CODE_EXEC_SANDBOX to use the weaker process mode.",
                "exit_code": -1, "sandbox": "docker"}
    image = os.environ.get("CODE_EXEC_DOCKER_IMAGE", "python:3.12-slim")
    name = f"hub-sandbox-{uuid.uuid4().hex[:12]}"
    proc = subprocess.Popen(_docker_command(docker, name, image), stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    readers = [_TailReader(proc.stdout), _TailReader(proc.stderr)]
    for r in readers:
        r.start()
    timed_out = False
    try:
        proc.stdin.write(code.encode("utf-8"))
        proc.stdin.close()
    except (BrokenPipeError, OSError):
        pass
    try:
        proc.wait(timeout=TIMEOUT_SECONDS + DOCKER_START_GRACE_SECONDS)
    except subprocess.TimeoutExpired:
        timed_out = True
        subprocess.run([docker, "kill", name], capture_output=True)
        proc.kill()
        proc.wait()
    for r in readers:
        r.join(timeout=2)
    stderr = readers[1].text()
    if timed_out:
        stderr = (stderr + f"\nTimed out after {TIMEOUT_SECONDS + DOCKER_START_GRACE_SECONDS}s "
                  "(is the image pulled? docker pull " + image + ")").strip()
    return {"stdout": readers[0].text(), "stderr": stderr, "exit_code": -1 if timed_out else proc.returncode,
            "sandbox": "docker"}


@spoke.tool("run_python", "Execute a Python code string and return stdout/stderr.", params={"code": "Python source to run"})
def run_python(code: str):
    mode = (os.environ.get("CODE_EXEC_SANDBOX", "") or "process").strip().lower()
    if mode == "docker":
        return _run_docker(code)
    if mode == "process":
        return _run_process(code)
    return {"stdout": "", "stderr": f"Unknown CODE_EXEC_SANDBOX '{mode}'. Use 'process' or 'docker'.",
            "exit_code": -1, "sandbox": mode}


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8003)
