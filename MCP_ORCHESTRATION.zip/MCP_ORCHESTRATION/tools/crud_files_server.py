"""
crud_files_server.py
-----------------------
Write operations on files, separated from filesystem_server.py so the
hub can grant read-access without also granting write-access to a task.

Run standalone:  uvicorn tools.crud_files_server:app --port 8008
"""

from pathlib import Path
from tools._base import Spoke
from tools._server_factory import make_app

import config

ALLOWED_ROOTS = config.allowed_roots()  # HUB_ALLOWED_ROOTS, or your home folder

spoke = Spoke("crud_files_spoke", "Create, read, update, and delete files within allowed roots.")


def _resolve(path_str: str) -> Path:
    resolved = Path(path_str).resolve()
    for root in ALLOWED_ROOTS:
        try:
            resolved.relative_to(Path(root).resolve())
            return resolved
        except ValueError:
            continue
    raise PermissionError(f"'{resolved}' is outside allowed roots {ALLOWED_ROOTS}")


@spoke.tool("create_file", "Create a new file with given content (fails if it already exists).", params={"path": "target path", "content": "file content"})
def create_file(path: str, content: str = ""):
    target = _resolve(path)
    if target.exists():
        raise FileExistsError(f"{target} already exists — use update_file instead.")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
    return {"created": str(target), "bytes": len(content)}


@spoke.tool("read_file", "Read a file's contents.", params={"path": "target path"})
def read_file(path: str):
    target = _resolve(path)
    if not target.is_file():
        raise FileNotFoundError(str(target))
    return {"path": str(target), "content": target.read_text(errors="replace")}


@spoke.tool("update_file", "Overwrite or append to an existing file.", params={"path": "target path", "content": "new content", "mode": "'overwrite' or 'append'"})
def update_file(path: str, content: str, mode: str = "overwrite"):
    target = _resolve(path)
    if not target.exists():
        raise FileNotFoundError(f"{target} doesn't exist — use create_file instead.")
    if mode == "append":
        with target.open("a") as f:
            f.write(content)
    else:
        target.write_text(content)
    return {"updated": str(target), "mode": mode}


@spoke.tool("delete_file", "Delete a file.", params={"path": "target path"})
def delete_file(path: str):
    target = _resolve(path)
    if not target.is_file():
        raise FileNotFoundError(str(target))
    target.unlink()
    return {"deleted": str(target)}


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8008)
