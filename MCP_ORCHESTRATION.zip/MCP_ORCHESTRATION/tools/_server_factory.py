"""
_server_factory.py
------------------
Turns a Spoke object into a runnable FastAPI app with the standard
/manifest and /invoke routes. Every file in tools/ builds a Spoke,
then calls make_app(spoke) to get something uvicorn can run.

/manifest and /invoke require the spoke shared secret (X-Spoke-Key header,
see auth.py), so only the hub can use a spoke. /health stays open so
launchers can check that a spoke is up.
"""

from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from tools._base import Spoke, InvokeRequest, InvokeResponse, Manifest

import auth


def require_spoke_key(x_spoke_key: Optional[str] = Header(default=None)) -> None:
    if not auth.token_matches(x_spoke_key, auth.get_or_create_spoke_secret()):
        raise HTTPException(status_code=401, detail="Missing or invalid spoke key")


def make_app(spoke: Spoke) -> FastAPI:
    app = FastAPI(title=spoke.name, description=spoke.description)

    @app.get("/manifest", response_model=Manifest, dependencies=[Depends(require_spoke_key)])
    def manifest():
        return spoke.manifest()

    @app.post("/invoke", response_model=InvokeResponse, dependencies=[Depends(require_spoke_key)])
    def invoke(req: InvokeRequest):
        return spoke.invoke(req.tool, req.params)

    @app.get("/health")
    def health():
        return {"status": "ok", "spoke": spoke.name}

    return app
