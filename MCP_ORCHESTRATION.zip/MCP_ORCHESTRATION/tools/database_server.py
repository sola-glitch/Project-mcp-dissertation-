"""
database_server.py
--------------------
RECONSTRUCTED — rebuilds the SQLite database spoke described in your
dissertation. Uses SQLAlchemy Core against mcp_data.db so the hub can
store/query structured data (this is also where Session Manager and
Credential Vault persist their state, in the 'sessions' and
'credentials' tables created here).

Run standalone:  uvicorn tools.database_server:app --port 8002
"""

from __future__ import annotations

from pathlib import Path
from sqlalchemy import create_engine, text, MetaData, Table, Column, String, Integer, Text
from tools._base import Spoke
from tools._server_factory import make_app

import config

DB_PATH = config.data_dir() / "mcp_data.db"
engine = create_engine(f"sqlite:///{DB_PATH}", future=True)
metadata = MetaData()

# Core tables the rest of the system relies on.
sessions_table = Table(
    "sessions", metadata,
    Column("session_id", String, primary_key=True),
    Column("state_json", Text),
    Column("updated_at", String),
)
credentials_table = Table(
    "credentials", metadata,
    Column("service", String, primary_key=True),
    Column("username", String),
    Column("secret", Text),  # stored encrypted (see crypto.py / credential_vault.py)
    Column("created_at", String),
)
metadata.create_all(engine)

spoke = Spoke("database_spoke", "Run queries against the local SQLite store (mcp_data.db).")


@spoke.tool("query", "Run a read-only SELECT and return rows.", params={"sql": "SELECT statement"})
def query(sql: str):
    if not sql.strip().lower().startswith("select"):
        raise ValueError("Only SELECT statements are allowed through 'query'. Use 'execute' for writes.")
    with engine.connect() as conn:
        result = conn.execute(text(sql))
        return [dict(row._mapping) for row in result]


@spoke.tool("execute", "Run an INSERT/UPDATE/DELETE statement.", params={"sql": "SQL statement", "params": "optional bind params dict"})
def execute(sql: str, params: dict | None = None):
    with engine.begin() as conn:
        result = conn.execute(text(sql), params or {})
        return {"rows_affected": result.rowcount}


@spoke.tool("list_tables", "List all tables in the database.")
def list_tables():
    with engine.connect() as conn:
        result = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))
        return [row[0] for row in result]


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8002)
