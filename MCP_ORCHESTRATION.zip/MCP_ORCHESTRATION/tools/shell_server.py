"""
shell_server.py
------------------
Runs shell commands (bash/cmd/powershell depending on OS) so the hub
can do system-level tasks that don't fit the code-exec sandbox (which
is Python-only). This is the highest-privilege spoke in the whole
system — treat it accordingly:

  - Every call is timeboxed and its exit code/output is returned, never
    left running in the background.
  - There is no built-in allow/deny list of commands here because a
    denylist is trivially bypassed; if you want to restrict this spoke,
    do it at the OS/user-account level the whole process runs under
    (a dedicated low-privilege service account), not in this file.
  - Every invocation should be written to audit.log via hub.py before
    being dispatched here, so there's a record of what ran and when —
    that's the control that actually matters for this spoke.

Run standalone:  uvicorn tools.shell_server:app --port 8009
"""

from __future__ import annotations

import platform
import subprocess
from tools._base import Spoke
from tools._server_factory import make_app

spoke = Spoke("shell_spoke", "Execute a shell command (bash/cmd/powershell) and return its output.")

TIMEOUT_SECONDS = 30


@spoke.tool(
    "run_command",
    "Run a shell command and return stdout/stderr/exit_code.",
    params={"command": "the command line to run", "cwd": "optional working directory", "shell": "'auto'|'bash'|'cmd'|'powershell'"},
)
def run_command(command: str, cwd: str | None = None, shell: str = "auto"):
    chosen = shell
    if chosen == "auto":
        chosen = "powershell" if platform.system() == "Windows" else "bash"

    if chosen == "powershell":
        argv = ["powershell", "-NoProfile", "-Command", command]
    elif chosen == "cmd":
        argv = ["cmd", "/c", command]
    else:
        argv = ["bash", "-c", command]

    try:
        proc = subprocess.run(
            argv, cwd=cwd, capture_output=True, text=True, timeout=TIMEOUT_SECONDS,
        )
        return {"stdout": proc.stdout[-5000:], "stderr": proc.stderr[-5000:], "exit_code": proc.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": f"Timed out after {TIMEOUT_SECONDS}s", "exit_code": -1}


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8009)
