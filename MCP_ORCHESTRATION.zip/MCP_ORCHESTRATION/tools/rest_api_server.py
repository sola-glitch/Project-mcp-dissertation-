"""
rest_api_server.py
-------------------
RECONSTRUCTED — I don't have your original file, so this rebuilds the
REST API spoke from the pattern described in your dissertation (a spoke
that lets the hub make outbound HTTP calls on behalf of a task).
Swap this out for your real file if you still have it.

Run standalone:  uvicorn tools.rest_api_server:app --port 8001
"""

from __future__ import annotations

import requests
from tools._base import Spoke
from tools._server_factory import make_app

spoke = Spoke("rest_api_spoke", "Make outbound HTTP requests on behalf of a task.")


@spoke.tool(
    "http_request",
    "Perform an HTTP request and return status/headers/body.",
    params={"method": "GET|POST|PUT|PATCH|DELETE", "url": "target URL",
            "headers": "optional dict of headers", "json_body": "optional JSON body"},
)
def http_request(method: str, url: str, headers: dict | None = None, json_body: dict | None = None):
    resp = requests.request(method.upper(), url, headers=headers or {}, json=json_body, timeout=15)
    return {
        "status_code": resp.status_code,
        "headers": dict(resp.headers),
        "body": _safe_body(resp),
    }


def _safe_body(resp: requests.Response):
    try:
        return resp.json()
    except ValueError:
        return resp.text[:5000]  # cap raw text to avoid huge payloads


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)
