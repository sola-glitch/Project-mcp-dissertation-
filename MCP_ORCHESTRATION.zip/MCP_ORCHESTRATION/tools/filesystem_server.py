"""
filesystem_server.py
----------------------
Read-only navigation/search spoke. Deliberately excludes write
operations — those live in crud_files_server.py so the hub can grant
"look around" without also granting "change things".

Run standalone:  uvicorn tools.filesystem_server:app --port 8007
"""

from __future__ import annotations

import os
import fnmatch
from pathlib import Path
from tools._base import Spoke
from tools._server_factory import make_app

import config

ALLOWED_ROOTS = config.allowed_roots()  # HUB_ALLOWED_ROOTS, or your home folder
_STATE = {"cwd": ALLOWED_ROOTS[0]}

spoke = Spoke("filesystem_spoke", "Navigate, list, and search the local filesystem (read-only).")


def _resolve(path_str: str) -> Path:
    p = Path(path_str)
    if not p.is_absolute():
        p = Path(_STATE["cwd"]) / p
    resolved = p.resolve()
    for root in ALLOWED_ROOTS:
        try:
            resolved.relative_to(Path(root).resolve())
            return resolved
        except ValueError:
            continue
    raise PermissionError(f"'{resolved}' is outside allowed roots {ALLOWED_ROOTS}")


@spoke.tool("navigate", "Change current working directory.", params={"path": "target directory"})
def navigate(path: str):
    target = _resolve(path)
    if not target.is_dir():
        raise NotADirectoryError(str(target))
    _STATE["cwd"] = str(target)
    return {"cwd": _STATE["cwd"]}


@spoke.tool("list_dir", "List contents of a directory (defaults to cwd).", params={"path": "optional directory"})
def list_dir(path: str | None = None):
    target = _resolve(path) if path else Path(_STATE["cwd"])
    return {
        "path": str(target),
        "entries": [{"name": e.name, "is_dir": e.is_dir()} for e in os.scandir(target)],
    }


@spoke.tool("search", "Recursively search for files by name pattern.", params={"query": "glob pattern e.g. *.py", "root": "optional root dir"})
def search(query: str, root: str | None = None):
    search_root = _resolve(root) if root else Path(_STATE["cwd"])
    matches = []
    for dirpath, _, filenames in os.walk(search_root):
        for fname in filenames:
            if fnmatch.fnmatch(fname.lower(), query.lower()):
                matches.append(str(Path(dirpath) / fname))
                if len(matches) >= 200:
                    return {"matches": matches, "truncated": True}
    return {"matches": matches, "truncated": False}


@spoke.tool("info", "Get metadata about a file or folder.", params={"path": "target path"})
def info(path: str):
    target = _resolve(path)
    if not target.exists():
        return {"exists": False}
    stat = target.stat()
    return {
        "exists": True,
        "is_dir": target.is_dir(),
        "is_file": target.is_file(),
        "size_bytes": stat.st_size if target.is_file() else None,
        "modified": stat.st_mtime,
    }


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8007)
