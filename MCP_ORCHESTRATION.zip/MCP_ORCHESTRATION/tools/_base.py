"""
_base.py
--------
Shared contract every spoke in tools/ follows so the hub can talk to all
of them the same way, regardless of what each spoke actually does.

Every spoke exposes:
    GET  /manifest   -> {name, description, tools: [{name, description, params}]}
    POST /invoke      -> {tool: str, params: dict}  ->  {status, result | error}

This mirrors what hub.py expects when it registers a spoke at startup.
"""

from __future__ import annotations
import inspect
from typing import Any, Callable, Dict, List, Optional
from pydantic import BaseModel


_JSON_TYPES = {"str": "string", "int": "integer", "float": "number", "bool": "boolean", "dict": "object", "list": "array"}


def _json_type(annotation: Any) -> str:
    """Map a Python annotation (possibly a string like 'str | None') to a JSON Schema type."""
    text = annotation if isinstance(annotation, str) else getattr(annotation, "__name__", str(annotation))
    for part in text.split("|"):
        base = part.strip().split("[")[0].lower()
        if base in ("none", "nonetype", ""):
            continue
        return _JSON_TYPES.get(base, "string")
    return "string"


def build_input_schema(fn: Callable[..., Any], params: Dict[str, str]) -> Dict[str, Any]:
    """Build a JSON Schema for a tool from its function signature + human param descriptions."""
    properties: Dict[str, Any] = {}
    required: List[str] = []
    for name, p in inspect.signature(fn).parameters.items():
        if p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD):
            continue
        prop: Dict[str, Any] = {"type": _json_type(p.annotation)}
        if params.get(name):
            prop["description"] = params[name]
        properties[name] = prop
        if p.default is inspect.Parameter.empty:
            required.append(name)
    schema: Dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema


class ToolSpec(BaseModel):
    name: str
    description: str
    params: Dict[str, str] = {}  # param_name -> human description
    input_schema: Optional[Dict[str, Any]] = None  # JSON Schema, used by the AI assistant and MCP adapter


class Manifest(BaseModel):
    name: str
    description: str
    tools: List[ToolSpec]


class InvokeRequest(BaseModel):
    tool: str
    params: Dict[str, Any] = {}


class InvokeResponse(BaseModel):
    status: str  # "ok" | "error"
    result: Optional[Any] = None
    error: Optional[str] = None


class Spoke:
    """
    Minimal registry a spoke server uses to declare its tools and route
    /invoke calls to the right Python function.
    """

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self._tools: Dict[str, ToolSpec] = {}
        self._handlers: Dict[str, Callable[..., Any]] = {}

    def tool(self, name: str, description: str, params: Optional[Dict[str, str]] = None):
        """Decorator to register a function as an invokable tool."""
        def wrapper(fn: Callable[..., Any]):
            self._tools[name] = ToolSpec(
                name=name, description=description, params=params or {},
                input_schema=build_input_schema(fn, params or {}),
            )
            self._handlers[name] = fn
            return fn
        return wrapper

    def manifest(self) -> Manifest:
        return Manifest(name=self.name, description=self.description, tools=list(self._tools.values()))

    def invoke(self, tool: str, params: Dict[str, Any]) -> InvokeResponse:
        if tool not in self._handlers:
            return InvokeResponse(status="error", error=f"Unknown tool '{tool}' on spoke '{self.name}'")
        try:
            result = self._handlers[tool](**params)
            return InvokeResponse(status="ok", result=result)
        except TypeError as e:
            return InvokeResponse(status="error", error=f"Bad params for '{tool}': {e}")
        except Exception as e:
            return InvokeResponse(status="error", error=f"{type(e).__name__}: {e}")
