"""
toolmaker_server.py
---------------------
The meta-spoke: when the hub can't find a tool for a task, it prompts
the user ("no tool available for X, create one?"), and if the answer
is yes, calls this spoke to scaffold a brand-new spoke file under
tools/, following the same Spoke/_server_factory pattern as every
other spoke — then the hub registers it and continues the task.

This only *scaffolds* a new spoke (creates the file with a working
skeleton). It does not write the tool's actual business logic for you —
that still needs a human (or a follow-up coding pass) to fill in,
since letting a spoke auto-write and auto-run arbitrary new code with
no review is the kind of unbounded capability that deserves its own
risk discussion in the dissertation, not a silent default.

Run standalone:  uvicorn tools.toolmaker_server:app --port 8006
"""

import re
from pathlib import Path
from tools._base import Spoke
from tools._server_factory import make_app

TOOLS_DIR = Path(__file__).resolve().parent

TEMPLATE = '''"""
{filename}
{underline}
Auto-scaffolded by toolmaker_server.py on request: "{purpose}"
Fill in the TODOs below, then register the new port in hub.py's
SPOKE_REGISTRY.

Run standalone:  uvicorn tools.{module_name}:app --port {port}
"""

from tools._base import Spoke
from tools._server_factory import make_app

spoke = Spoke("{spoke_name}", "{purpose}")


@spoke.tool("example_tool", "TODO: describe what this tool does.", params={{"input": "TODO describe param"}})
def example_tool(input: str):
    # TODO: implement the actual behavior for: {purpose}
    return {{"received": input}}


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port={port})
'''

spoke = Spoke("toolmaker_spoke", "Scaffold new spoke servers when no existing tool covers a task.")


@spoke.tool(
    "create_spoke",
    "Scaffold a new spoke file under tools/ for a described purpose.",
    params={"name": "short_snake_case_name for the spoke", "purpose": "one-line description of what it should do",
            "port": "port number to assign (int)"},
)
def create_spoke(name: str, purpose: str, port: int):
    safe_name = re.sub(r"[^a-z0-9_]", "", name.lower().replace(" ", "_"))
    if not safe_name:
        raise ValueError("Could not derive a safe module name from the given name.")

    module_name = f"{safe_name}_server"
    filename = f"{module_name}.py"
    target = TOOLS_DIR / filename

    if target.exists():
        raise FileExistsError(f"{filename} already exists — pick a different name or edit it directly.")

    contents = TEMPLATE.format(
        filename=filename,
        underline="-" * len(filename),
        purpose=purpose,
        module_name=module_name,
        spoke_name=f"{safe_name}_spoke",
        port=port,
    )
    target.write_text(contents)

    return {
        "created": str(target),
        "next_steps": [
            f"Fill in the TODOs in {filename}",
            f"Add '{safe_name}': 'http://127.0.0.1:{port}' to SPOKE_REGISTRY in hub.py",
            f"Run: uvicorn tools.{module_name}:app --port {port}",
        ],
    }


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8006)
