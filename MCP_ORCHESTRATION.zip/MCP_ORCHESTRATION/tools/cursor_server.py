"""
cursor_server.py
------------------
RECONSTRUCTED — Cursor (the AI code editor) doesn't expose a documented
public HTTP API, so this spoke wraps the `cursor` CLI it ships with
(same idea as VS Code's `code` CLI) to open files/folders/diffs from
the hub. If your original implementation talked to something else,
swap this out.

Run standalone:  uvicorn tools.cursor_server:app --port 8005
"""

import shutil
import subprocess
from tools._base import Spoke
from tools._server_factory import make_app

spoke = Spoke("cursor_spoke", "Open files/folders in the Cursor editor via its CLI.")


def _cursor_cli() -> str:
    path = shutil.which("cursor")
    if not path:
        raise RuntimeError("'cursor' CLI not found on PATH. Install Cursor and enable its shell command.")
    return path


def _safe_path(path: str) -> str:
    """A 'path' that starts with '-' would be read by the CLI as an option (e.g. --install-extension)."""
    if not path or path.startswith("-"):
        raise ValueError(f"Refusing path {path!r}: paths must not start with '-'. Use ./ for a relative path.")
    return path


@spoke.tool("open_path", "Open a file or folder in Cursor.", params={"path": "file or folder path"})
def open_path(path: str):
    path = _safe_path(path)
    cli = _cursor_cli()
    subprocess.Popen([cli, path])
    return {"opened": path}


@spoke.tool("open_diff", "Open a diff view between two files in Cursor.", params={"file_a": "path A", "file_b": "path B"})
def open_diff(file_a: str, file_b: str):
    file_a, file_b = _safe_path(file_a), _safe_path(file_b)
    cli = _cursor_cli()
    subprocess.Popen([cli, "--diff", file_a, file_b])
    return {"diffing": [file_a, file_b]}


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8005)
