"""
github_server.py
------------------
RECONSTRUCTED — rebuilds the GitHub spoke using PyGithub. Reads the
token from GITHUB_TOKEN in the environment (.env) by default, but a
task can also pass one in explicitly via the Credential Vault lookup
in hub.py.

Run standalone:  uvicorn tools.github_server:app --port 8004
"""

from __future__ import annotations

import os
from pathlib import Path
from dotenv import load_dotenv
from github import Github, Auth
from tools._base import Spoke
from tools._server_factory import make_app

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

spoke = Spoke("github_spoke", "Read/write GitHub repos, issues, and PRs.")


def _client(token: str | None = None) -> Github:
    tok = token or os.environ.get("GITHUB_TOKEN")
    if not tok:
        raise ValueError("No GitHub token available (set GITHUB_TOKEN in .env or pass one in).")
    return Github(auth=Auth.Token(tok))


@spoke.tool("list_repos", "List repos for the authenticated user.", params={"token": "optional override token"})
def list_repos(token: str | None = None):
    g = _client(token)
    return [r.full_name for r in g.get_user().get_repos()]


@spoke.tool(
    "create_issue", "Create an issue on a repo.",
    params={"repo": "owner/name", "title": "issue title", "body": "issue body", "token": "optional override token"},
)
def create_issue(repo: str, title: str, body: str = "", token: str | None = None):
    g = _client(token)
    r = g.get_repo(repo)
    issue = r.create_issue(title=title, body=body)
    return {"number": issue.number, "url": issue.html_url}


@spoke.tool("list_issues", "List open issues on a repo.", params={"repo": "owner/name", "token": "optional override token"})
def list_issues(repo: str, token: str | None = None):
    g = _client(token)
    r = g.get_repo(repo)
    return [{"number": i.number, "title": i.title, "url": i.html_url} for i in r.get_issues(state="open")]


app = make_app(spoke)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8004)
