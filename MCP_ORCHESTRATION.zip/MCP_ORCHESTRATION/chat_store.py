"""
chat_store.py
---------------
Saves AI assistant chats so they survive a restart. Each chat is encrypted
(see crypto.py) before it is written to the 'ai_chats' table in mcp_data.db,
because chats can contain file contents and command output.

The oldest chats are dropped beyond MAX_CHATS.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from sqlalchemy import Column, MetaData, String, Table, Text, text

import crypto
import session_manager
from ai_agent import Chat

MAX_CHATS = 50

_metadata = MetaData()
_chats_table = Table(
    "ai_chats", _metadata,
    Column("chat_id", String, primary_key=True),
    Column("state", Text),
    Column("updated_at", String),
)
_metadata.create_all(session_manager.engine)


def _engine():
    return session_manager.engine      # looked up at call time so tests can swap it


def save_chat(chat_id: str, chat: Chat) -> None:
    payload = crypto.encrypt(json.dumps({"title": chat.title(), "chat": chat.to_dict()}))
    now = datetime.now(timezone.utc).isoformat()
    with _engine().begin() as conn:
        conn.execute(text(
            "INSERT INTO ai_chats (chat_id, state, updated_at) VALUES (:id, :s, :t) "
            "ON CONFLICT(chat_id) DO UPDATE SET state=:s, updated_at=:t"), {"id": chat_id, "s": payload, "t": now})
        conn.execute(text(
            "DELETE FROM ai_chats WHERE chat_id NOT IN "
            "(SELECT chat_id FROM ai_chats ORDER BY updated_at DESC LIMIT :n)"), {"n": MAX_CHATS})


def load_chat(chat_id: str) -> Chat | None:
    with _engine().connect() as conn:
        row = conn.execute(text("SELECT state FROM ai_chats WHERE chat_id=:id"), {"id": chat_id}).fetchone()
    if not row:
        return None
    return Chat.from_dict(json.loads(crypto.decrypt(row[0]))["chat"])


def list_chats(limit: int = MAX_CHATS) -> list[dict]:
    with _engine().connect() as conn:
        rows = conn.execute(text("SELECT chat_id, state, updated_at FROM ai_chats ORDER BY updated_at DESC LIMIT :n"),
                            {"n": limit}).fetchall()
    out = []
    for chat_id, state, updated_at in rows:
        try:
            title = json.loads(crypto.decrypt(state))["title"]
        except crypto.CryptoError:
            title = "(cannot decrypt: key changed)"
        out.append({"chat_id": chat_id, "title": title, "updated_at": updated_at})
    return out


def delete_chat(chat_id: str) -> None:
    with _engine().begin() as conn:
        conn.execute(text("DELETE FROM ai_chats WHERE chat_id=:id"), {"id": chat_id})
